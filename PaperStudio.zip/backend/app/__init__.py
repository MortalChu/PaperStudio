"""AI paper writer backend."""
