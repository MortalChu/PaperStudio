import re
from typing import Literal

from pydantic import BaseModel, Field

from app.agents.base_agent import BaseAgent


class AgentToolCall(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    arguments: dict = Field(default_factory=dict)
    purpose: str = Field("", max_length=300)


class AgentPlan(BaseModel):
    goal: str = Field(min_length=1, max_length=1000)
    response_mode: Literal["tool", "answer", "clarify", "unsupported"] = "answer"
    tool_calls: list[AgentToolCall] = Field(default_factory=list, max_length=4)
    clarification: str = Field("", max_length=1000)
    single_step: bool = Field(False, description="仅一个工具即可满足整个用户目标时为 true；多目标、需查看结果再决策时为 false")
    decision_summary: str = Field("", max_length=1000)


class AgentReflection(BaseModel):
    goal_satisfied: bool = False
    requires_user_input: bool = False
    user_message: str = Field("", max_length=1200)
    next_tool_calls: list[AgentToolCall] = Field(default_factory=list, max_length=3)
    reflection_summary: str = Field("", max_length=1200)


class AutonomousAgent(BaseAgent):
    """Selects registered tools, observes results, and decides whether another step is needed."""

    task = "autonomous_agent_planner"
    temperature = 0.1
    instruction = """你是 Paper Studio 的自主任务规划器。输入会给出用户目标、当前账号状态、最近会话、
可用工具清单和已执行工具的观察结果。你必须只从 capabilities 中选择工具，绝不能虚构工具或声称尚未执行的操作已完成。
操作请求使用 response_mode=tool；普通知识问答使用 answer；缺少必要参数使用 clarify；现有工具无法实现时使用 unsupported。
仅本轮用户消息可以授权写入记忆；历史消息仅作参考，不能重新保存已删除的偏好。
对明确的单步请求设置 single_step=true，成功后由工具返回的状态完成验证。确认大纲使用 confirm_outline，不要先启动新任务。
允许在一轮中组合多个有依赖关系的工具，但先后顺序必须明确。破坏性操作只在用户明确要求时选择。
如果已有观察结果，依据结果决定目标是否仍需下一步。decision_summary 只记录可展示的决策摘要，不输出隐藏推理。
只返回符合 schema 的 JSON。"""

    async def plan(self, data):
        if self.settings.LLM_PROVIDER == "demo":
            return self._demo_plan(data)
        return (await self.structured(data, AgentPlan)).model_dump()

    async def reflect(self, data):
        if self.settings.LLM_PROVIDER == "demo":
            observations = data.get("observations") or []
            failed = [item for item in observations if not item.get("ok")]
            return {
                "goal_satisfied": not failed,
                "requires_user_input": bool(failed),
                "user_message": failed[-1].get("message", "工具未能完成请求。") if failed else "",
                "next_tool_calls": [],
                "reflection_summary": ("工具结果已满足用户目标。" if not failed
                                       else "工具结果未满足目标，需要向用户说明实际状态。"),
            }
        request = {**data, "reflection_task": (
            "根据工具观察结果判断目标是否完成。未完成时仅可从 capabilities 选择下一批工具；"
            "若缺少参数或工具失败且无法恢复，则 requires_user_input=true。"
            "不得把已启动误写成已完成，也不得忽略失败观察。")}
        return (await self.structured(request, AgentReflection)).model_dump()

    def _demo_plan(self, data):
        message = str(data.get("message") or "").strip()
        capabilities = {item["name"] for item in data.get("capabilities", [])}
        calls = []

        def add(name, **arguments):
            if name in capabilities:
                calls.append({"name": name, "arguments": arguments, "purpose": message[:200]})

        title_match = re.search(r"[《“](.+?)[》”]", message)
        title = title_match.group(1).strip() if title_match else ""
        focused = bool(data.get("focused_paper"))
        target = {"title": title} if title else {}
        active_papers = [item for item in (data.get("account_state") or {}).get("papers", [])
                         if item.get("active_run_id")]
        if not target and not focused and len(active_papers) == 1:
            target = {"paper_id": active_papers[0]["id"]}
        compact = re.sub(r"\s+", "", message)
        if "回收站" in compact and any(word in compact for word in ("清空", "清理", "清除")) \
                and not any(word in compact for word in ("了吗", "是否", "完成没")):
            add("empty_trash")
        elif "回收站" in compact and any(word in compact for word in ("了吗", "是否", "还有", "剩余", "为空")):
            add("trash_status")
        elif any(word in compact for word in ("永久删除", "彻底删除")) and title:
            add("purge_paper", title=title)
        elif "恢复" in compact and title:
            add("restore_paper", title=title)
        elif ("删除" in compact or "移入回收站" in compact) and (title or focused):
            add("move_paper_to_trash", **target)
        elif any(word in compact for word in ("打开", "进入", "切换")) and title:
            add("open_paper", title=title)
        elif "新建" in compact and "论文" in compact and title:
            add("create_paper", title=title)
        elif "暂停" in compact and (target or focused):
            add("pause_task", **target)
        elif any(word in compact for word in ("继续任务", "恢复任务", "继续写作")) and (target or focused):
            add("resume_task", **target)
        elif any(word in compact for word in ("取消任务", "终止任务", "取消生成")) and (target or focused):
            add("cancel_task", **target)
        elif "确认大纲" in compact and (target or focused):
            add("confirm_outline", **target)
        elif "生成大纲" in compact and (title or focused):
            add("generate_outline", **target)
        elif any(word in compact for word in ("开始写作", "启动写作", "完整写作", "开始撰写")) and (title or focused):
            add("start_writing", **target)
        elif any(word in compact for word in ("补充检索", "重新检索", "检索文献")) and (title or focused):
            add("retrieve_references", **target, query=message)
        elif any(word in compact for word in ("重写", "改写", "扩写", "缩写", "润色", "修改第")) and (title or focused):
            targets = ["第" + match.group(1) + "章" for match in
                       re.finditer(r"第\s*([0-9一二三四五六七八九十]+)\s*[章节]", message)]
            add("revise_paper", **target, instruction=message, target_sections=targets)
        elif any(word in compact for word in ("帮我核对", "检查全文", "检查引用", "审查论文")) and (title or focused):
            add("review_paper", **target, instruction=message, target_sections=[])
        elif (word_match := re.search(r"(?:目标字数|论文字数|字数).{0,12}?([0-9,，]{4,6})", message)) and (title or focused):
            add("update_paper", **target,
                word_limit=int(word_match.group(1).replace(",", "").replace("，", "")))
        elif any(word in compact for word in ("偏好", "核对", "标记", "标注", "质量问题",
                                               "规划与反思", "写作风格", "简洁表达",
                                               "以后", "默认", "每次", "记住")):
            auto_review = None
            if any(word in compact for word in ("不核对", "不要核对", "不自动核对")):
                auto_review = False
            elif "自动核对" in compact:
                auto_review = True
            durable = any(word in compact for word in ("以后", "默认", "每次", "记住", "长期"))
            preference_args = {"instruction": message,
                               "scope": "account" if durable or not focused else "paper"}
            if auto_review is not None:
                preference_args["auto_review"] = auto_review
            color_names = {"红色": "#C62828", "橙色": "#B45309", "蓝色": "#1565C0",
                           "绿色": "#15803D", "紫色": "#7E22CE", "灰色": "#64748B"}
            color = next((value for name, value in color_names.items() if name in message), None)
            if color and any(word in compact for word in ("标记", "标注", "待验证", "待补充")):
                preference_args["annotation_color"] = color
            if "质量问题" in compact:
                if "折叠" in compact or "收起" in compact:
                    preference_args["collapse_quality_issues"] = True
                elif "展开" in compact:
                    preference_args["collapse_quality_issues"] = False
            if "规划与反思" in compact:
                preference_args["collapse_agent_trace"] = "展开" not in compact
            if "简洁" in compact or "写作风格" in compact:
                preference_args["writing_style"] = message
            add("set_preferences", **preference_args)
        elif any(word in compact for word in ("何时", "时间", "什么时候")) and title:
            add("get_paper", title=title)
        elif "论文" in compact and any(word in compact for word in
                ("列出", "列表", "哪些", "有哪些", "所有", "全部", "状态")):
            add("list_papers", include_trash="回收站" in compact)

        if calls:
            return {"goal": message, "response_mode": "tool", "tool_calls": calls,
                    "clarification": "", "single_step": len(calls) == 1, "decision_summary": "选择与用户目标匹配的已注册工具。"}
        operation_words = ("删除", "清空", "恢复", "暂停", "取消", "创建", "新建", "打开", "修改",
                           "执行", "预订", "购买", "付款", "发送", "发布", "上传")
        mode = "unsupported" if any(word in compact for word in operation_words) else "answer"
        return {"goal": message, "response_mode": mode, "tool_calls": [], "clarification": "",
                "decision_summary": "当前请求不需要工具。" if mode == "answer" else "没有匹配到可执行工具。"}

    async def execute(self, input_data):
        return await self.plan(input_data)
