from app.agents.autonomous_agent import AutonomousAgent


class ConversationAgent(AutonomousAgent):
    """Backward-compatible name for extensions that imported the former one-step planner."""

    task = "conversation_autonomous_agent"

    async def execute(self, input_data):
        return await self.plan(input_data)
