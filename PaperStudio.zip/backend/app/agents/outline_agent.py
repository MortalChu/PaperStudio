from app.agents.base_agent import BaseAgent
from app.schemas.paper import Outline


class OutlineAgent(BaseAgent):
    task = "outline"
    instruction = ("依据 references 中的文献片段设计学术论文大纲，遵循论文类型、目标字数及用户要求。"
        "同时遵循 writing_style、persistent_instructions 和 preference_memory 中用户通过对话提出的结构与写作要求。"
        "用现有文献支撑研究背景与综述，尚无数据的实验或结论只能列为待研究内容，不得写成已验证成果。"
        "每节有标题、要点和字数，可包含子节。只输出符合 schema 的 JSON。")

    async def execute(self, input_data):
        result = await self.structured(input_data, Outline)
        return {"outline": result.model_dump(), "outline_dict": result.model_dump()}
