from typing import Literal

from pydantic import BaseModel, Field

from app.agents.base_agent import BaseAgent


AgentAction = Literal[
    "recommend_topic", "confirm_topic", "retrieve", "generate_outline", "confirm_outline", "confirm_review",
    "write_sections", "polish", "reflect", "finish",
]


class PlannerDecision(BaseModel):
    action: AgentAction
    rationale: str = Field(min_length=2, max_length=500)
    retrieval_query: str = Field("", max_length=1000)


class PlannerAgent(BaseAgent):
    task = "planner"
    temperature = 0.0
    instruction = """你是论文写作智能体的规划器。根据目标、当前状态、最近行动和反思报告，
同时把 preferences 中从用户对话提炼出的自然语言要求作为本论文目标的一部分，
从 available_actions 中选择唯一的下一步行动。需要补充证据时选择 retrieve 并给出具体检索式；
已有完整草稿时优先评审而不是盲目结束。只返回符合 schema 的 JSON，不输出隐藏推理过程，
rationale 只写简短、可审计的行动理由。"""

    async def execute(self, input_data):
        if self.settings.LLM_PROVIDER == "demo":
            return {"action": input_data["recommended_action"],
                    "rationale": "离线演示规划器根据当前状态选择下一项可执行行动。",
                    "retrieval_query": input_data.get("suggested_query", ""), "guardrail_applied": False}
        decision = await self.structured(input_data, PlannerDecision)
        allowed = input_data["available_actions"]
        if decision.action not in allowed:
            return {"action": allowed[0], "rationale": "模型选择超出当前允许范围，已由状态约束修正。",
                    "retrieval_query": decision.retrieval_query, "guardrail_applied": True}
        return {**decision.model_dump(), "guardrail_applied": False}
