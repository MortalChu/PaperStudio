from app.agents.base_agent import BaseAgent
from app.utils.helpers import citation_numbers


class PolishAgent(BaseAgent):
    task = "polish"
    instruction = """润色中文学术正文。依据 focus 优化语言、逻辑或格式，保持原意、所有数值、引用编号和待验证标记。
遵循 writing_style、persistent_instructions 和 preference_memory 中用户通过对话提出的语言与格式偏好。
禁止增加事实、实验结果、文献或引用。只返回完整的润色后正文，不附修改说明，不增加章节标题。"""

    async def execute(self, input_data):
        original = input_data["content"]
        result = await self.text(input_data)
        if not result.strip():
            raise ValueError("润色结果为空，已保留原文")
        if citation_numbers(result) != citation_numbers(original):
            raise ValueError("润色改变了引用编号，已保留原文")
        return {"polished": result, "original_length": len(original), "polished_length": len(result)}
