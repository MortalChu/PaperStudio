from pydantic import BaseModel, Field

from app.agents.base_agent import BaseAgent


class RetrievalQueryPlan(BaseModel):
    queries: list[str] = Field(min_length=1, max_length=5)
    concepts: list[str] = Field(default_factory=list, max_length=12)


class QueryRewriteAgent(BaseAgent):
    task = "retrieval_query"
    temperature = 0.0
    instruction = """把论文检索需求改写为互补的学术检索式。保留原始主题，同时覆盖核心方法、对象和评价维度；
不得引入用户没有提及的研究结论。queries 去重并保持简洁，只返回符合 schema 的 JSON。"""

    async def execute(self, input_data):
        if self.settings.LLM_PROVIDER == "demo":
            query = input_data["query"].strip()
            title = input_data.get("title", "").strip()
            queries = list(dict.fromkeys(value for value in (query, title) if value))
            return {"queries": queries[:self.settings.RETRIEVAL_MAX_QUERIES], "concepts": []}
        return (await self.structured(input_data, RetrievalQueryPlan)).model_dump()
