import logging

from app.agents.query_rewrite_agent import QueryRewriteAgent
from app.utils.helpers import format_reference


class ReferenceAgent:
    """Retrieval and deterministic citations keep bibliography metadata out of LLM invention."""
    def __init__(self, retriever, settings=None):
        self.retriever = retriever
        self.settings = settings or retriever.vector_store.settings
        self.query_agent = QueryRewriteAgent(self.settings)

    async def execute(self, input_data):
        original_query = input_data["query"].strip()
        query_plan = {"queries": [original_query], "concepts": [], "mode": "original"}
        if self.settings.RETRIEVAL_QUERY_EXPANSION:
            try:
                planned = await self.query_agent.execute({"query": original_query,
                    "title": input_data.get("title", ""), "reflection": input_data.get("reflection", {})})
                queries = [original_query, *planned["queries"]]
                query_plan = {**planned,
                    "queries": list(dict.fromkeys(q.strip() for q in queries if q.strip()))[:self.settings.RETRIEVAL_MAX_QUERIES],
                    "mode": "agent_expansion"}
                if self.retriever.metrics:
                    self.retriever.metrics.record("query_expansion", status="completed",
                                                  query_count=len(query_plan["queries"]))
            except Exception as exc:
                # 检索改写属于召回增强；失败时显式记录降级，原始查询仍可执行。
                logging.getLogger(__name__).warning(
                    "Query expansion failed; using the original query. error_type=%s", type(exc).__name__)
                query_plan["mode"] = "original_after_expansion_error"
                if self.retriever.metrics:
                    self.retriever.metrics.record("query_expansion", status="fallback_original",
                                                  error_type=type(exc).__name__)
        hits = await self.retriever.search_many(query_plan["queries"], top_k=input_data.get("top_k", 8))
        existing = input_data.get("existing_references") or []
        unique = {ref["id"]: dict(ref) for ref in existing}
        next_number = max((ref.get("citation_number", 0) for ref in existing), default=0) + 1
        for hit in hits:
            if hit["id"] in unique:
                old_excerpt = unique[hit["id"]].get("excerpt", "")
                addition = f"[PDF 页 {hit['page'] or '未知'}]\n" + hit["excerpt"]
                if addition not in old_excerpt:
                    unique[hit["id"]]["excerpt"] = (old_excerpt + "\n" + addition).strip()
                unique[hit["id"]]["score"] = max(unique[hit["id"]].get("score", 0), hit["score"])
            else:
                unique[hit["id"]] = {k: hit[k] for k in ("id", "title", "authors", "journal", "year", "volume", "issue", "pages", "doi", "url", "page", "score")}
                unique[hit["id"]]["excerpt"] = f"[PDF 页 {hit['page'] or '未知'}]\n" + hit["excerpt"]
                unique[hit["id"]]["citation_number"] = next_number
                unique[hit["id"]]["retrieval_method"] = hit.get("retrieval_method", "hybrid_rrf")
                next_number += 1
        references = list(unique.values())
        return {"references": references, "formatted": "\n\n".join(
            format_reference(ref, ref["citation_number"], input_data.get("format", "gbt"))
            for ref in references), "query_plan": query_plan, "new_reference_count": len(references) - len(existing)}
