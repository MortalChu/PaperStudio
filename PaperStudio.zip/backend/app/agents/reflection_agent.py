from typing import Literal

from pydantic import BaseModel, Field

from app.agents.base_agent import BaseAgent


class ReflectionResult(BaseModel):
    decision: Literal["finish", "retrieve_more", "revise"]
    summary: str = Field(min_length=2, max_length=1000)
    issues: list[str] = Field(default_factory=list, max_length=20)
    evidence_gaps: list[str] = Field(default_factory=list, max_length=12)
    target_sections: list[str] = Field(default_factory=list, max_length=20)
    retrieval_query: str = Field("", max_length=1000)
    revision_instructions: list[str] = Field(default_factory=list, max_length=20)


class ReflectionAgent(BaseAgent):
    task = "reflection"
    temperature = 0.0
    instruction = """你是论文写作智能体的评审器。检查章节是否覆盖大纲要点、论述是否由给定文献支撑、
引用编号是否可溯源、章节是否连贯，以及是否虚构实验或结论。资料不足时选择 retrieve_more，
内容可以依据现有证据修正时选择 revise，达到当前材料能够支持的初稿标准时选择 finish。
同时依据 preferences 中用户通过对话提出的核对重点与论文要求执行评审，但不能降低证据真实性约束。
target_sections 填章节 key 或标题；不要把缺少真实实验数据本身视为可以编造内容的理由。
只返回符合 schema 的 JSON，不输出隐藏推理过程。"""

    async def execute(self, input_data):
        if self.settings.LLM_PROVIDER == "demo":
            issues = input_data.get("deterministic_issues", [])
            gaps = input_data.get("deterministic_evidence_gaps", [])
            return {"decision": "revise" if issues else "retrieve_more" if gaps else "finish",
                    "summary": "离线评审器依据结构、字数、引用和证据覆盖完成检查。",
                    "issues": issues, "evidence_gaps": gaps,
                    "target_sections": input_data.get("suggested_target_sections", []),
                    "retrieval_query": input_data.get("suggested_query", ""),
                    "revision_instructions": issues}
        return (await self.structured(input_data, ReflectionResult)).model_dump()
