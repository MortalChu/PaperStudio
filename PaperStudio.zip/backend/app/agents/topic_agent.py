from pydantic import BaseModel, Field
from app.agents.base_agent import BaseAgent


class TopicSuggestion(BaseModel):
    title: str = Field(min_length=5, max_length=500)
    value: str
    innovation: str
    feasibility: str


class TopicSuggestions(BaseModel):
    topics: list[TopicSuggestion] = Field(min_length=3, max_length=5)


class TopicAgent(BaseAgent):
    task = "topic"
    instruction = ("根据研究领域、关键词和 references 中检索到的文献推荐 3-5 个可研究的选题，说明价值、创新假设与可行性。"
        "优先选择已有文献能支持的方向；无文献时标明为待调研建议，不声称是当前热点或已证实的研究空白。只输出符合 schema 的 JSON。")

    async def execute(self, input_data):
        return (await self.structured(input_data, TopicSuggestions)).model_dump()
