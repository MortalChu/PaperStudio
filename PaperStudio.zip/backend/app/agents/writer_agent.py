from app.agents.base_agent import BaseAgent


class WriterAgent(BaseAgent):
    task = "writer"
    instruction = """你是学术写作专家。按标题、全文大纲、章节要点、目标字数及用户材料撰写中文正文。
同时遵循 user_instruction、writing_style、persistent_instructions 和 preference_memory；它们用于本次定向修改及用户写作偏好，
但不得覆盖引用真实性、禁止虚构和仅使用所给文献等约束。
只返回本章正文，不重复本章标题。保持全篇术语一致；子章节内容不在父章重复。
仅引用提供的文献片段，严格使用其 citation_number，如 [2]，不得自行重新编号或编造文献。
不得虚构实验、统计数值、研究结果或已完成的工作。缺乏证据的内容标记【待验证】或【待补充文献】。
如未提供数据，结果章节应写分析计划及待补充项，不得假称实验已完成。"""

    async def execute(self, input_data):
        return {"content": await self.text(input_data)}
