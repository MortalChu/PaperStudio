import asyncio
from time import perf_counter
from uuid import uuid4
from app.services.agent_telemetry import begin_turn, mark, record_turn

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import Response, StreamingResponse
from sqlalchemy import func, select

from app.agents.conversation_response_agent import ConversationResponseAgent
from app.agents.autonomous_agent import AutonomousAgent
from app.api.auth import get_current_user
from app.database import get_db
from app.models.paper import AgentMessage, GlobalAgentMessage, GlobalAgentSession
from app.models.user import User, utcnow
from app.schemas.paper import (AgentChatRequest, AgentChatResponse, AgentMessageResponse,
                               AgentPreferencesUpdate, GlobalAgentTurnRequest)
from app.services.agent_service import (merge_preferences, normalize_preferences, effective_preferences,
    load_effective_preferences, memory_entries, preference_storage)
from app.services.agent_runtime import AutonomousAgentLoop
from app.services.global_agent_tools import GlobalAgentTools
from app.services.paper_service import owned_paper
from app.utils.helpers import failure_diagnostic, sse


router = APIRouter()


@router.post("/turns/{turn_id}/display")
async def display_receipt(turn_id: str, request: Request, user=Depends(get_current_user)):
    state = request.app.state.agent_turns.get(turn_id)
    if not state or state["user_id"] != user.id:
        raise HTTPException(404, "对话任务不存在")
    payload = await request.json()
    phase = payload.get("phase")
    if phase not in ("first_visible", "drained"):
        raise HTTPException(422, "显示阶段无效")
    received = state.setdefault("display_receipts", [])
    if phase not in received:
        received.append(phase)
        request.app.state.metrics.record("agent_display", turn_id=turn_id, user_id=user.id,
            phase=phase, elapsed_ms=round((perf_counter()-state["accepted_at"])*1000, 2))
    return {"recorded": True}


@router.get("/memories")
async def list_memories(db=Depends(get_db), user=Depends(get_current_user)):
    from app.models.paper import Paper
    result = [{**e, "scope": "account", "paper_id": None, "paper_title": "账号长期记忆"}
              for e in memory_entries(user.preferences)]
    papers = (await db.scalars(select(Paper).where(Paper.author_id == user.id))).all()
    for paper in papers:
        result.extend({**e, "scope": "paper", "paper_id": paper.id, "paper_title": paper.title}
                      for e in memory_entries(paper.agent_preferences))
    return sorted(result, key=lambda e: e.get("updated_at") or "", reverse=True)


@router.delete("/memories/{memory_id}", status_code=204)
async def delete_memory(memory_id: str, paper_id: int | None = None,
                        db=Depends(get_db), user=Depends(get_current_user)):
    from app.models.paper import Paper
    owner = user
    field = "preferences"
    if paper_id is not None:
        owner = await db.get(Paper, paper_id)
        if not owner or owner.author_id != user.id:
            raise HTTPException(404, "记忆不存在")
        field = "agent_preferences"
    entries = memory_entries(getattr(owner, field))
    if not any(e["id"] == memory_id for e in entries):
        raise HTTPException(404, "记忆不存在或已删除")
    setattr(owner, field, preference_storage([e for e in entries if e["id"] != memory_id]))
    await db.commit()
    return Response(status_code=204)



def _register_task(app, task):
    app.state.agent_chat_tasks.add(task)
    def release(done):
        app.state.agent_chat_tasks.discard(done)
        if not done.cancelled():
            done.exception()
    task.add_done_callback(release)


@router.post("/paper/{paper_id}/turns", status_code=202)
async def submit_turn(paper_id: int, data: AgentChatRequest, request: Request,
                      db=Depends(get_db), user=Depends(get_current_user)):
    owner_id = user.id
    await owned_paper(db, paper_id, owner_id)
    user_message = AgentMessage(paper_id=paper_id, user_id=owner_id, role="user",
        content=data.message, status="interpreting", action="none", details={})
    assistant_message = AgentMessage(paper_id=paper_id, user_id=owner_id, role="assistant",
        content="Agent 正在分析目标与可用能力…", status="streaming", action="respond", details={})
    db.add_all([user_message, assistant_message])
    await db.commit()
    await db.refresh(user_message)
    await db.refresh(assistant_message)
    turn_id = str(uuid4())
    state = {"id": turn_id, "accepted_at": perf_counter(), "user_id": owner_id, "paper_id": paper_id,
             "prompt": data.message, "content": "", "status": "interpreting",
             "run_id": None, "error": "", "assistant_message_id": assistant_message.id,
             "phase": "Agent 正在分析目标与可用能力…"}
    request.app.state.agent_turns[turn_id] = state

    user_message_id, assistant_id = user_message.id, assistant_message.id

    async def run_turn():
        telemetry = begin_turn()
        result = None
        response_text = ""
        try:
            async with request.app.state.database.sessions() as session:
                stored_user = await session.get(User, owner_id)
                focused = await owned_paper(session, paper_id, owner_id)
                history = (await session.scalars(select(AgentMessage).where(
                    AgentMessage.paper_id == paper_id, AgentMessage.user_id == owner_id,
                    AgentMessage.id < user_message_id, AgentMessage.action != "ask_review")
                    .order_by(AgentMessage.id.desc()).limit(12))).all()
                toolset = GlobalAgentTools(request, session, stored_user)
                toolset.current_message = data.message
                context = {"message": data.message, "focused_paper": await toolset.focused_state(focused),
                    "preferences": effective_preferences(stored_user.preferences, focused.agent_preferences),
                    "recent_conversation": [{"role": item.role, "content": item.content}
                                            for item in reversed(history)]}

                def progress(stage, label):
                    state.update(status="acting", phase=label, trace_stage=stage)
                    if stage == "tool":
                        mark(telemetry, "first_tool_ms")

                registry = toolset.registry().with_defaults(paper_id=paper_id)
                result = await AutonomousAgentLoop(
                    AutonomousAgent(request.app.state.settings), registry).run(context, progress=progress)
                state.update(status="streaming", phase="正在根据工具结果生成回复",
                             trace=result["trace"], observations=result["observations"])
                async for token in ConversationResponseAgent(request.app.state.settings).stream_reply(
                        {**context, "agent_result": result}):
                    if token:
                        mark(telemetry, "first_content_ms")
                    response_text += token
                    state["content"] = response_text
                successful = [item for item in result["observations"] if item.get("ok")]
                operation_names = [item.get("output", {}).get("operation") for item in successful]
                operation_map = {"move_paper_to_trash": "delete", "generate_outline": "outline",
                    "start_writing": "start", "pause_task": "pause", "resume_task": "resume",
                    "cancel_task": "cancel", "retrieve_references": "retrieve",
                    "revise_paper": "revise", "review_paper": "review", "update_paper": "update",
                    "set_preferences": "none"}
                raw_operation = next((name for name in reversed(operation_names) if name), None)
                operation = operation_map.get(raw_operation, raw_operation or "none")
                output = next((item.get("output", {}) for item in reversed(successful)
                               if item.get("output")), {})
                run_id = output.get("run_id")
                stored_user_message = await session.get(AgentMessage, user_message_id)
                stored_assistant = await session.get(AgentMessage, assistant_id)
                if stored_user_message:
                    stored_user_message.status = "completed"
                    stored_user_message.action = operation
                    stored_user_message.details = {"agent_trace": result["trace"]}
                    stored_user_message.completed_at = utcnow()
                if stored_assistant:
                    stored_assistant.content = response_text.strip()
                    stored_assistant.status = "completed"
                    stored_assistant.action = operation
                    stored_assistant.details = {"agent_trace": result["trace"],
                                                "observations": result["observations"]}
                    stored_assistant.completed_at = utcnow()
                await session.commit()
                if request.app.state.metrics:
                    request.app.state.metrics.record("autonomous_agent_turn", user_id=owner_id,
                        paper_id=paper_id, tool_calls=len(result["observations"]),
                        successful_tools=len(successful), operation=operation,
                        reflection_cycles=sum(1 for item in result["trace"] if item.get("stage") == "reflect"))
                state.update(content=response_text.strip(), status="completed", run_id=run_id,
                             operation=operation)
        except asyncio.CancelledError:
            state.update(status="interrupted", error="后端已停止")
            raise
        except Exception as exc:
            diagnostic = failure_diagnostic(exc, request.app.state.settings, step="agent_chat")
            state.update(status="failed", error=diagnostic["message"], diagnostic_id=diagnostic["diagnostic_id"])
            async with request.app.state.database.sessions() as session:
                stored_user_message = await session.get(AgentMessage, user_message_id)
                stored_assistant = await session.get(AgentMessage, assistant_id)
                if stored_user_message:
                    stored_user_message.status = "failed"
                    stored_user_message.completed_at = utcnow()
                if stored_assistant:
                    stored_assistant.content = "本轮执行失败：" + diagnostic["message"]
                    stored_assistant.status = "failed"
                    stored_assistant.completed_at = utcnow()
                await session.commit()

        finally:
            record_turn(request, telemetry, state, result)

    _register_task(request.app, asyncio.create_task(run_turn()))
    return {"turn_id": turn_id, "status": state["status"]}


@router.get("/paper/{paper_id}/turns/{turn_id}")
async def turn_status(paper_id: int, turn_id: str, request: Request,
                      db=Depends(get_db), user=Depends(get_current_user)):
    state = request.app.state.agent_turns.get(turn_id)
    if not state or state["paper_id"] != paper_id or state["user_id"] != user.id:
        raise HTTPException(404, "对话任务不存在或后端已经重启")
    return state


@router.get("/global/sessions")
async def global_sessions(db=Depends(get_db), user=Depends(get_current_user)):
    records = (await db.scalars(select(GlobalAgentSession).where(
        GlobalAgentSession.user_id == user.id)
        .order_by(GlobalAgentSession.updated_at.desc(), GlobalAgentSession.id.desc()))).all()
    result = []
    for item in records:
        count = await db.scalar(select(func.count(GlobalAgentMessage.id)).where(
            GlobalAgentMessage.session_id == item.id))
        latest = await db.scalar(select(GlobalAgentMessage.content).where(
            GlobalAgentMessage.session_id == item.id,
            GlobalAgentMessage.role == "user").order_by(GlobalAgentMessage.id.desc()).limit(1))
        if count:
            result.append({"id": item.id, "title": item.title, "message_count": count,
                           "last_user_message": latest or "", "created_at": item.created_at,
                           "updated_at": item.updated_at})
    return result


@router.get("/global/capabilities")
async def global_capabilities(request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    return GlobalAgentTools(request, db, user).registry().manifest()


@router.get("/global/messages")
async def global_messages(session_id: int = Query(ge=1), limit: int = Query(200, ge=1, le=300),
                          db=Depends(get_db), user=Depends(get_current_user)):
    conversation = await db.get(GlobalAgentSession, session_id)
    if not conversation or conversation.user_id != user.id:
        raise HTTPException(404, "历史会话不存在")
    records = (await db.scalars(select(GlobalAgentMessage).where(
        GlobalAgentMessage.user_id == user.id,
        GlobalAgentMessage.session_id == session_id)
        .order_by(GlobalAgentMessage.id.desc()).limit(limit))).all()
    return [{"id": item.id, "role": item.role, "content": item.content, "status": item.status,
             "action": item.action, "details": item.details, "created_at": item.created_at,
             "completed_at": item.completed_at} for item in reversed(records)]


@router.delete("/global/sessions/{session_id}", status_code=204)
async def delete_global_session(session_id: int, request: Request,
                                db=Depends(get_db), user=Depends(get_current_user)):
    conversation = await db.get(GlobalAgentSession, session_id)
    if not conversation or conversation.user_id != user.id:
        raise HTTPException(404, "历史会话不存在")
    running = any(state.get("user_id") == user.id and state.get("session_id") == session_id
                  and state.get("status") not in ("completed", "failed", "interrupted")
                  for state in request.app.state.agent_turns.values())
    if running:
        raise HTTPException(409, "该会话仍在生成回复，请等待本轮结束后再删除")
    # Legacy databases may not have an effective ON DELETE cascade for this column.
    messages = (await db.scalars(select(GlobalAgentMessage).where(
        GlobalAgentMessage.user_id == user.id,
        GlobalAgentMessage.session_id == session_id))).all()
    for message in messages:
        await db.delete(message)
    await db.delete(conversation)
    await db.commit()
    return Response(status_code=204)


@router.post("/global/turns", status_code=202)
async def submit_global_turn(data: GlobalAgentTurnRequest, request: Request,
                             db=Depends(get_db), user=Depends(get_current_user)):
    owner_id = user.id
    now = utcnow()
    if data.session_id:
        conversation = await db.get(GlobalAgentSession, data.session_id)
        if not conversation or conversation.user_id != owner_id:
            raise HTTPException(404, "历史会话不存在")
    else:
        title = data.message.replace("\n", " ").strip()[:80] or "新会话"
        conversation = GlobalAgentSession(user_id=owner_id, title=title,
                                          created_at=now, updated_at=now)
        db.add(conversation)
        await db.flush()
    conversation.updated_at = now
    user_message = GlobalAgentMessage(session_id=conversation.id, user_id=owner_id,
        role="user", content=data.message,
        status="completed", action="none", details={}, completed_at=now)
    assistant_message = GlobalAgentMessage(session_id=conversation.id, user_id=owner_id, role="assistant",
        content="Agent 正在理解你的要求…", status="streaming", action="respond", details={})
    db.add_all([user_message, assistant_message])
    await db.commit()
    await db.refresh(assistant_message)
    turn_id = str(uuid4())
    state = {"id": turn_id, "accepted_at": perf_counter(), "user_id": owner_id, "paper_id": None, "prompt": data.message,
             "content": "", "status": "interpreting", "paper_target_id": None,
             "assistant_message_id": assistant_message.id, "session_id": conversation.id, "error": ""}
    request.app.state.agent_turns[turn_id] = state

    session_id, user_message_id, assistant_id = conversation.id, user_message.id, assistant_message.id

    async def run_global_turn():
        telemetry = begin_turn()
        agent_result = None
        response_text = ""
        operation = "none"
        target_id = None
        try:
            async with request.app.state.database.sessions() as session:
                stored_user = await session.get(User, owner_id)
                history = (await session.scalars(select(GlobalAgentMessage).where(
                    GlobalAgentMessage.session_id == session_id,
                    GlobalAgentMessage.id < user_message_id)
                    .order_by(GlobalAgentMessage.id.desc()).limit(12))).all()
                toolset = GlobalAgentTools(request, session, stored_user)
                toolset.current_message = data.message
                active = await toolset.papers(False)
                recycled = await toolset.papers(True)
                context = {
                    "message": data.message.strip(),
                    "account_state": {
                        "papers": [toolset.summary(item) for item in active],
                        "trash_count": len(recycled),
                    },
                    "preferences": normalize_preferences(stored_user.preferences),
                    "recent_conversation": [{"role": item.role, "content": item.content}
                                            for item in reversed(history)],
                }

                def progress(stage, label):
                    state.update(status="acting", phase=label, trace_stage=stage)
                    if stage == "tool":
                        mark(telemetry, "first_tool_ms")

                runner = AutonomousAgentLoop(
                    AutonomousAgent(request.app.state.settings), toolset.registry())
                agent_result = await runner.run(context, progress=progress)
                state.update(trace=agent_result["trace"], observations=agent_result["observations"])

                successful = [item for item in agent_result["observations"] if item.get("ok")]
                operations = [item.get("output", {}).get("operation") for item in successful]
                operation_map = {"list_papers": "list", "get_paper": "paper_time",
                    "open_paper": "select", "create_paper": "create",
                    "move_paper_to_trash": "delete", "restore_paper": "restore",
                    "purge_paper": "purge_paper", "empty_trash": "purge_trash"}
                operation = operation_map.get(next((name for name in reversed(operations) if name), None),
                                              next((name for name in reversed(operations) if name), "none"))
                navigated = next((item.get("output", {}) for item in reversed(successful)
                                  if item.get("output", {}).get("navigate")), {})
                target_id = navigated.get("paper_id")

                state.update(status="streaming", phase="正在根据工具结果生成回复", content="")
                response_input = {**context, "agent_result": agent_result}
                async for token in ConversationResponseAgent(
                        request.app.state.settings).stream_reply(response_input):
                    if token:
                        mark(telemetry, "first_content_ms")
                    response_text += token
                    state["content"] = response_text
                if not response_text.strip():
                    response_text = "本轮没有生成有效回复，也没有声称任何操作已经执行。"
                stored = await session.get(GlobalAgentMessage, assistant_id)
                if stored:
                    stored.content = response_text
                    stored.status = "completed"
                    stored.action = operation
                    stored.details = {"paper_id": target_id, "agent_trace": agent_result["trace"],
                                      "observations": agent_result["observations"],
                                      "response_mode": agent_result["plan"].get("response_mode")}
                    stored.completed_at = utcnow()
                stored_conversation = await session.get(GlobalAgentSession, session_id)
                if stored_conversation:
                    stored_conversation.updated_at = utcnow()
                await session.commit()
                if request.app.state.metrics:
                    request.app.state.metrics.record(
                        "autonomous_agent_turn", user_id=owner_id, session_id=session_id,
                        response_mode=agent_result["plan"].get("response_mode"),
                        tool_calls=len(agent_result["observations"]),
                        successful_tools=sum(1 for item in agent_result["observations"] if item.get("ok")),
                        failed_tools=sum(1 for item in agent_result["observations"] if not item.get("ok")),
                        reflection_cycles=sum(1 for item in agent_result["trace"] if item.get("stage") == "reflect"),
                        operation=operation)
            state.update(content=response_text, status="completed", operation=operation,
                         paper_target_id=target_id)
        except asyncio.CancelledError:
            state.update(status="interrupted", error="后端已停止")
            raise
        except Exception as exc:
            diagnostic = failure_diagnostic(exc, request.app.state.settings, step="global_agent_chat")
            state.update(status="failed", error=diagnostic["message"], diagnostic_id=diagnostic["diagnostic_id"])
            async with request.app.state.database.sessions() as session:
                stored = await session.get(GlobalAgentMessage, assistant_id)
                if stored:
                    stored.content = "本轮执行失败：" + diagnostic["message"]
                    stored.status = "failed"
                    stored.completed_at = utcnow()
                    await session.commit()

        finally:
            record_turn(request, telemetry, state, agent_result)

    _register_task(request.app, asyncio.create_task(run_global_turn()))
    return {"turn_id": turn_id, "session_id": session_id, "status": state["status"]}


@router.get("/global/turns/{turn_id}")
async def global_turn_status(turn_id: str, request: Request, user=Depends(get_current_user)):
    state = request.app.state.agent_turns.get(turn_id)
    if not state or state["user_id"] != user.id or state["paper_id"] is not None:
        raise HTTPException(404, "对话任务不存在或后端已经重启")
    return state


@router.get("/{paper_id}/messages", response_model=list[AgentMessageResponse])
async def messages(paper_id: int, limit: int = Query(100, ge=1, le=300),
                   db=Depends(get_db), user=Depends(get_current_user)):
    await owned_paper(db, paper_id, user.id)
    records = (await db.scalars(select(AgentMessage).where(
        AgentMessage.paper_id == paper_id, AgentMessage.user_id == user.id,
        AgentMessage.action != "ask_review")
        .order_by(AgentMessage.id.desc()).limit(limit))).all()
    return list(reversed(records))


@router.get("/{paper_id}/preferences")
async def preferences(paper_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    paper = await owned_paper(db, paper_id, user.id)
    return effective_preferences(user.preferences, paper.agent_preferences)


@router.put("/{paper_id}/preferences")
async def update_preferences(paper_id: int, data: AgentPreferencesUpdate,
                             db=Depends(get_db), user=Depends(get_current_user)):
    paper = await owned_paper(db, paper_id, user.id)
    changes = data.model_dump(exclude_unset=True)
    paper.agent_preferences = merge_preferences(paper.agent_preferences, changes)
    await db.commit()
    return effective_preferences(user.preferences, paper.agent_preferences)


@router.post("/{paper_id}/chat", response_model=AgentChatResponse)
async def chat(paper_id: int, data: AgentChatRequest, request: Request,
               db=Depends(get_db), user=Depends(get_current_user)):
    """Compatibility endpoint backed by the same autonomous loop as the live turn API."""
    focused = await owned_paper(db, paper_id, user.id)
    history = (await db.scalars(select(AgentMessage).where(
        AgentMessage.paper_id == paper_id, AgentMessage.user_id == user.id,
        AgentMessage.action != "ask_review").order_by(AgentMessage.id.desc()).limit(12))).all()
    user_message = AgentMessage(paper_id=paper_id, user_id=user.id, role="user",
        content=data.message, status="interpreting", action="none", details={})
    db.add(user_message)
    await db.commit()
    await db.refresh(user_message)
    toolset = GlobalAgentTools(request, db, user)
    toolset.current_message = data.message
    context = {"message": data.message, "focused_paper": await toolset.focused_state(focused),
        "preferences": effective_preferences(user.preferences, focused.agent_preferences),
        "recent_conversation": [{"role": item.role, "content": item.content}
                                for item in reversed(history)]}
    result = await AutonomousAgentLoop(AutonomousAgent(request.app.state.settings),
        toolset.registry().with_defaults(paper_id=paper_id)).run(context)
    response = await ConversationResponseAgent(request.app.state.settings).execute(
        {**context, "agent_result": result})
    response_text = response["content"].strip()
    successful = [item for item in result["observations"] if item.get("ok")]
    operation_names = [item.get("output", {}).get("operation") for item in successful]
    operation_map = {"move_paper_to_trash": "delete", "generate_outline": "outline",
        "start_writing": "start", "pause_task": "pause", "resume_task": "resume",
        "cancel_task": "cancel", "retrieve_references": "retrieve",
        "revise_paper": "revise", "review_paper": "review", "update_paper": "update",
        "set_preferences": "none"}
    raw_operation = next((name for name in reversed(operation_names) if name), None)
    operation = operation_map.get(raw_operation, raw_operation or "none")
    output = next((item.get("output", {}) for item in reversed(successful)
                   if item.get("output")), {})
    persistent_user_message = await db.get(AgentMessage, user_message.id)
    persistent_user_message.status = "completed"
    persistent_user_message.action = operation
    persistent_user_message.details = {"agent_trace": result["trace"]}
    persistent_user_message.completed_at = utcnow()
    assistant_message = AgentMessage(paper_id=paper_id, user_id=user.id, role="assistant",
        content=response_text, status="completed", action=operation,
        details={"agent_trace": result["trace"], "observations": result["observations"]},
        completed_at=utcnow())
    db.add(assistant_message)
    await db.commit()
    await db.refresh(assistant_message)
    focused = await owned_paper(db, paper_id, user.id) if operation != "delete" else focused
    return {"user_message": persistent_user_message, "assistant_message": assistant_message,
            "preferences": effective_preferences(user.preferences, focused.agent_preferences),
            "operation": operation, "run_id": output.get("run_id"), "queued": False}


@router.post("/{paper_id}/chat/stream")
async def stream_chat(paper_id: int, data: AgentChatRequest, request: Request,
                      db=Depends(get_db), user=Depends(get_current_user)):
    submitted = await submit_turn(paper_id, data, request, db, user)
    turn_id = submitted["turn_id"]
    async def event_stream():
        yield sse("accepted", {"kind": "accepted", "message": "用户消息已接收"})
        sent = 0
        phase = ""
        while True:
            state = request.app.state.agent_turns.get(turn_id)
            if not state:
                yield sse("error", {"kind": "error", "message": "对话状态已丢失。"})
                return
            if state.get("phase") and state["phase"] != phase:
                phase = state["phase"]
                yield sse("phase", {"kind": "phase", "message": phase})
            content = state.get("content", "")
            if len(content) > sent:
                yield sse("token", {"kind": "token", "text": content[sent:]})
                sent = len(content)
            if state.get("status") == "completed":
                yield sse("done", {"kind": "done", "operation": state.get("operation", "none"),
                    "run_id": state.get("run_id"), "queued": False})
                return
            if state.get("status") in ("failed", "interrupted"):
                yield sse("error", {"kind": "error", "message": state.get("error") or "本轮执行未完成",
                    "diagnostic_id": state.get("diagnostic_id")})
                return
            await asyncio.sleep(.05)

    return StreamingResponse(event_stream(), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
