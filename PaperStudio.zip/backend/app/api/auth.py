import asyncio
from datetime import datetime, timedelta, timezone
import jwt
from pwdlib import PasswordHash
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy import select, or_
from sqlalchemy.exc import IntegrityError
from app.database import get_db
from app.models.user import User, utcnow
from app.schemas.user import UserCreate, UserResponse, LoginRequest, UserPreferencesUpdate
from app.services.agent_service import DEFAULT_AGENT_PREFERENCES, merge_preferences, normalize_preferences

router = APIRouter()
password_hash = PasswordHash.recommended()
oauth2 = OAuth2PasswordBearer(tokenUrl="/api/auth/token", auto_error=False)


def auth_error(message, code):
    return HTTPException(401, message, headers={"WWW-Authenticate": "Bearer", "X-Auth-Error": code})


async def get_current_user(request: Request, token=Depends(oauth2), db=Depends(get_db)):
    if not token:
        raise auth_error("请先登录；没有账号时请先创建账号", "login_required")
    try:
        claims = jwt.decode(token, request.app.state.settings.SECRET_KEY, algorithms=["HS256"],
                            options={"require": ["exp", "sub"]})
        user = await db.get(User, int(claims["sub"]))
    except jwt.ExpiredSignatureError:
        raise auth_error("登录已过期，请重新登录", "session_expired")
    except (jwt.InvalidTokenError, ValueError, TypeError):
        raise auth_error("登录凭证无效，请重新登录", "session_invalid")
    if not user or not user.is_active:
        raise auth_error("账号不存在或不可用，请重新登录或创建账号", "account_unavailable")
    return user


@router.post("/register", response_model=UserResponse, status_code=201)
async def register(data: UserCreate, db=Depends(get_db)):
    if await db.scalar(select(User).where(or_(User.username == data.username, User.email == str(data.email)))):
        raise HTTPException(409, "用户名或邮箱已存在")
    user = User(username=data.username, email=str(data.email), preferences=DEFAULT_AGENT_PREFERENCES,
                hashed_password=await asyncio.to_thread(password_hash.hash, data.password))
    db.add(user)
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(409, "用户名或邮箱已存在")
    return user


async def issue_token(request, db, username, password):
    user = await db.scalar(select(User).where(User.username == username))
    if not user or not user.is_active or not await asyncio.to_thread(password_hash.verify, password, user.hashed_password):
        raise auth_error("用户名或密码错误；尚未注册时请先创建账号", "credentials_invalid")
    cfg = request.app.state.settings
    token = jwt.encode({"sub": str(user.id), "exp": datetime.now(timezone.utc) +
                        timedelta(minutes=cfg.ACCESS_TOKEN_EXPIRE_MINUTES)}, cfg.SECRET_KEY, algorithm="HS256")
    user.last_login = utcnow()
    await db.commit()
    payload = UserResponse.model_validate(user).model_dump()
    payload["preferences"] = normalize_preferences(user.preferences)
    return {"access_token": token, "token_type": "bearer", "user": payload}


@router.post("/login")
async def login(data: LoginRequest, request: Request, db=Depends(get_db)):
    return await issue_token(request, db, data.username, data.password)


@router.post("/token")
async def token(request: Request, form: OAuth2PasswordRequestForm = Depends(), db=Depends(get_db)):
    return await issue_token(request, db, form.username, form.password)


@router.get("/me", response_model=UserResponse)
async def me(user=Depends(get_current_user)):
    return {**UserResponse.model_validate(user).model_dump(), "preferences": normalize_preferences(user.preferences)}


@router.get("/preferences")
async def get_preferences(user=Depends(get_current_user)):
    return normalize_preferences(user.preferences)


@router.put("/preferences")
async def update_preferences(data: UserPreferencesUpdate, db=Depends(get_db), user=Depends(get_current_user)):
    user.preferences = merge_preferences(user.preferences, data.model_dump(exclude_unset=True))
    await db.commit()
    return user.preferences
