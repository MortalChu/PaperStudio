from uuid import uuid4
from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response, StreamingResponse
from app.api.auth import get_current_user
from app.database import get_db
from app.models.chapter import Chapter
from app.schemas.chapter import ChapterCreate, ChapterUpdate, ChapterResponse, PolishRequest
from app.services.chapter_service import owned_chapter, writing_input
from app.services.paper_service import owned_paper, ensure_editable, save_version, rebuild_paper, refresh_references
from app.agents.writer_agent import WriterAgent
from app.agents.polish_agent import PolishAgent
from app.utils.helpers import sse, failure_diagnostic

router = APIRouter()


@router.get("/", response_model=list[ChapterResponse])
async def list_chapters(paper_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    return (await owned_paper(db, paper_id, user.id)).chapters


@router.post("/", response_model=ChapterResponse, status_code=201)
async def create(data: ChapterCreate, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        paper = await owned_paper(db, data.paper_id, user.id)
        ensure_editable(paper)
        if data.parent_id:
            parent, _ = await owned_chapter(db, data.parent_id, user.id)
            if parent.paper_id != paper.id:
                raise ValueError("父章节必须属于同一论文")
        await save_version(db, paper, "新增章节前自动备份")
        chapter = Chapter(**data.model_dump(), section_key="manual-" + uuid4().hex[:12])
        db.add(chapter)
        await rebuild_paper(db, paper)
        await db.commit()
        return chapter


@router.get("/{chapter_id}", response_model=ChapterResponse)
async def detail(chapter_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    chapter, _ = await owned_chapter(db, chapter_id, user.id)
    return chapter


@router.put("/{chapter_id}", response_model=ChapterResponse)
async def edit(chapter_id: int, data: ChapterUpdate, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        chapter, paper = await owned_chapter(db, chapter_id, user.id)
        ensure_editable(paper)
        await save_version(db, paper, f"编辑章节：{chapter.title}")
        for key, value in data.model_dump(exclude_unset=True, exclude_none=True).items():
            setattr(chapter, key, value)
        await rebuild_paper(db, paper)
        await db.commit()
        return chapter


@router.delete("/{chapter_id}", status_code=204)
async def remove(chapter_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        chapter, paper = await owned_chapter(db, chapter_id, user.id)
        ensure_editable(paper)
        await save_version(db, paper, f"删除章节：{chapter.title}")
        await db.delete(chapter)
        await rebuild_paper(db, paper)
        await db.commit()
    return Response(status_code=204)


async def chapter_references(request, db, paper):
    if not (paper.quality_report or {}).get("references"):
        references = await refresh_references(db, paper, request.app.state.retriever, strict=True)
        paper.quality_report = {**(paper.quality_report or {}), "references": references}


@router.post("/{chapter_id}/generate", response_model=ChapterResponse)
async def generate(chapter_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        chapter, paper = await owned_chapter(db, chapter_id, user.id)
        ensure_editable(paper)
        await chapter_references(request, db, paper)
        result = await WriterAgent(request.app.state.settings).execute(writing_input(chapter, paper))
        await save_version(db, paper, f"生成章节前：{chapter.title}")
        chapter.content = result["content"]
        await rebuild_paper(db, paper)
        await db.commit()
        return chapter


@router.post("/{chapter_id}/polish", response_model=ChapterResponse)
async def polish(chapter_id: int, data: PolishRequest, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        chapter, paper = await owned_chapter(db, chapter_id, user.id)
        ensure_editable(paper)
        if not chapter.content.strip():
            raise ValueError("请先撰写章节正文")
        result = await PolishAgent(request.app.state.settings).execute({"content": chapter.content, "focus": data.focus})
        await save_version(db, paper, f"润色前：{chapter.title}")
        chapter.content = result["polished"]
        await rebuild_paper(db, paper)
        await db.commit()
        return chapter


@router.post("/{chapter_id}/stream-generate")
async def stream_generate(chapter_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    chapter, paper = await owned_chapter(db, chapter_id, user.id)
    ensure_editable(paper)

    async def stream():
        # Acquire a fresh session inside the response lifetime, then re-check ownership and run status.
        async with request.app.state.edit_lock, request.app.state.database.sessions() as session:
            current, manuscript = await owned_chapter(session, chapter_id, user.id)
            ensure_editable(manuscript)
            manuscript_id = manuscript.id
            try:
                await chapter_references(request, session, manuscript)
                content = ""
                async for text in WriterAgent(request.app.state.settings).stream_execute(writing_input(current, manuscript)):
                    content += text
                    yield sse("token", {"text": text})
                if not content.strip():
                    raise ValueError("章节正文为空")
                await save_version(session, manuscript, f"流式生成前：{current.title}")
                current.content = content
                await rebuild_paper(session, manuscript)
                await session.commit()
                yield sse("done", {"chapter_id": current.id})
            except Exception as exc:
                await session.rollback()
                diagnostic = failure_diagnostic(exc, request.app.state.settings,
                    step="write_section", paper_id=manuscript_id)
                yield sse("error", {"message": "章节生成失败：" + diagnostic["message"] +
                    "；诊断编号：" + diagnostic["diagnostic_id"], "diagnostic": diagnostic})

    return StreamingResponse(stream(), media_type="text/event-stream")
