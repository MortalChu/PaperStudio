from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import Response, StreamingResponse
from sqlalchemy import select
from app.database import get_db
from app.api.auth import get_current_user
from app.models.paper import Paper, PaperVersion, PaperRun
from app.schemas.paper import (PaperCreate, PaperUpdate, PaperResponse, PaperDetail, TopicRequest,
                               GenerateRequest, ResumeRequest, VersionRequest, WordLimitUpdate,
                               OutlineSaveRequest)
from app.services.paper_service import (owned_paper, ensure_editable, save_version, sync_outline,
                                        restore_version, rebuild_paper, refresh_references,
                                        rescale_outline_word_counts, owned_paper_including_deleted,
                                        ensure_outline_editable)
from app.agents.topic_agent import TopicAgent
from app.agents.outline_agent import OutlineAgent
from app.models.user import utcnow
from app.services.agent_service import merge_preferences, normalize_preferences, effective_preferences, load_effective_preferences

router = APIRouter()


@router.post("/topics")
async def topics(data: TopicRequest, request: Request, user=Depends(get_current_user)):
    sources = await request.app.state.retriever.search(data.field + " " + data.keywords, top_k=8)
    return await TopicAgent(request.app.state.settings).execute({**data.model_dump(), "references": sources})


@router.post("/", response_model=PaperResponse, status_code=201)
async def create(data: PaperCreate, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        preferences = {}
        # 自动核对由每篇论文的对话显式开启，不从账号或旧任务静默继承。
        preferences["auto_review"] = False
        paper = Paper(**data.model_dump(), author_id=user.id,
                      agent_preferences=preferences)
        db.add(paper)
        await db.commit()
        await refresh_references(db, paper, request.app.state.retriever)
        await db.commit()
        return paper


@router.get("/", response_model=list[PaperResponse])
async def list_papers(skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200),
                      status: str | None = None, db=Depends(get_db), user=Depends(get_current_user)):
    statement = select(Paper).where(Paper.author_id == user.id, Paper.deleted_at.is_(None))
    if status:
        statement = statement.where(Paper.status == status)
    return (await db.scalars(statement.order_by(Paper.updated_at.desc()).offset(skip).limit(limit))).all()


@router.get("/trash", response_model=list[PaperResponse])
async def trash(skip: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=200),
                db=Depends(get_db), user=Depends(get_current_user)):
    statement = select(Paper).where(Paper.author_id == user.id, Paper.deleted_at.is_not(None))
    return (await db.scalars(statement.order_by(Paper.deleted_at.desc()).offset(skip).limit(limit))).all()


@router.delete("/trash")
async def empty_trash(db=Depends(get_db), user=Depends(get_current_user)):
    """Permanently delete every recycled paper owned by the current user."""
    records = (await db.scalars(select(Paper).where(
        Paper.author_id == user.id, Paper.deleted_at.is_not(None)))).all()
    for paper in records:
        await db.delete(paper)
    await db.commit()
    count = len(records)
    return {"deleted_count": count,
            "message": f"回收站已清空，永久删除 {count} 篇论文。" if count else "回收站原本就是空的。"}


@router.post("/trash/{paper_id}/restore", response_model=PaperDetail)
async def restore_from_trash(paper_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    paper = await owned_paper_including_deleted(db, paper_id, user.id)
    if paper.deleted_at is None:
        raise HTTPException(409, "论文不在回收站中")
    paper.deleted_at = None
    paper.purge_after = None
    paper.status = paper.deleted_from_status or ("review" if paper.final_paper else "outline" if paper.outline else "draft")
    paper.deleted_from_status = ""
    paper.active_run_id = None
    await db.commit()
    await db.refresh(paper, ["chapters", "references"])
    return paper


@router.delete("/trash/{paper_id}/purge", status_code=204)
async def purge_from_trash(paper_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    paper = await owned_paper_including_deleted(db, paper_id, user.id)
    if paper.deleted_at is None:
        raise HTTPException(409, "论文不在回收站中")
    await db.delete(paper)
    await db.commit()
    return Response(status_code=204)


@router.get("/{paper_id}", response_model=PaperDetail)
async def detail(paper_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    paper = await owned_paper(db, paper_id, user.id)
    result = PaperDetail.model_validate(paper)
    result.agent_preferences = effective_preferences(user.preferences, paper.agent_preferences)
    return result


@router.put("/{paper_id}/word-limit")
async def update_word_limit(paper_id: int, data: WordLimitUpdate, request: Request,
                            db=Depends(get_db), user=Depends(get_current_user)):
    paused = False
    async with request.app.state.edit_lock:
        paper = await owned_paper(db, paper_id, user.id)
        if paper.active_run_id:
            run = await db.get(PaperRun, paper.active_run_id)
            if not run:
                raise HTTPException(409, "当前任务记录不存在，请刷新后重试")
            if run.status == "running":
                paused = await request.app.state.workflow.pause(run.id)
                # 结束暂停前的只读事务，确保 SQLite / PostgreSQL 都能读到新状态。
                await db.rollback()
                paper = await owned_paper(db, paper_id, user.id)
                run = await db.get(PaperRun, paper.active_run_id) if paper.active_run_id else None
            if run and run.status not in ("waiting", "paused", "failed", "interrupted"):
                raise HTTPException(409, "当前任务正在切换状态，请刷新后重试")
        await save_version(db, paper, "调整目标字数前自动备份")
        paper.word_limit = data.word_limit
        if paper.outline:
            await sync_outline(db, paper, rescale_outline_word_counts(paper.outline, data.word_limit))
            paper.outline_revision += 1
        if paper.final_paper and not paper.active_run_id:
            report = {key: value for key, value in (paper.quality_report or {}).items()
                      if key not in ("human_reviewed", "human_reviewed_at")}
            paper.quality_report = {**report, "passed": False,
                "warnings": [*report.get("warnings", []),
                    f"目标字数已调整为 {data.word_limit:,} 字，需要重新核对当前初稿"]}
            paper.status = "review"
        await db.commit()
        await db.refresh(paper, ["chapters", "references"])
        status = await db.get(PaperRun, paper.active_run_id) if paper.active_run_id else None
        message = f"目标字数已调整为 {data.word_limit:,} 字"
        if status and status.status == "paused":
            message += "；任务已暂停，请确认后从检查点继续"
        return {"paper": PaperDetail.model_validate(paper).model_dump(),
                "paused": paused, "run_status": status.status if status else None, "message": message}


@router.put("/{paper_id}", response_model=PaperDetail)
async def edit(paper_id: int, data: PaperUpdate, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        paper = await owned_paper(db, paper_id, user.id)
        ensure_editable(paper)
        await save_version(db, paper, "编辑前自动备份")
        changes = data.model_dump(exclude_unset=True, exclude_none=True)
        outline = changes.pop("outline", None)
        for key, value in changes.items():
            setattr(paper, key, value)
        if outline:
            await sync_outline(db, paper, outline)
            paper.title = outline["title"]
            paper.status = "outline"
            paper.outline_revision += 1
        if paper.chapters:
            await rebuild_paper(db, paper)
        await db.commit()
        return paper


@router.delete("/{paper_id}", status_code=204)
async def remove(paper_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    from app.services.task_control import stop_and_trash
    await stop_and_trash(request, paper_id, user.id)
    return Response(status_code=204)


@router.put("/{paper_id}/outline", response_model=PaperDetail)
async def save_outline(paper_id: int, data: OutlineSaveRequest, request: Request,
                       db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        paper = await owned_paper(db, paper_id, user.id)
        await ensure_outline_editable(db, paper)
        if paper.outline_revision != data.expected_revision:
            raise HTTPException(409, "大纲已经在其他页面更新，请刷新后再保存，避免覆盖较新的内容")
        await save_version(db, paper, "大纲手动保存前" if data.source == "manual" else "大纲自动保存前")
        await sync_outline(db, paper, data.outline.model_dump())
        paper.title = data.outline.title
        paper.outline_revision += 1
        if not paper.active_run_id:
            paper.status = "outline"
        report = paper.quality_report or {}
        paper.quality_report = {**report, "references_stale": True,
                                "outline_last_saved_by": data.source,
                                "outline_last_saved_at": utcnow().isoformat()}
        await db.commit()
        await db.refresh(paper, ["chapters", "references"])
        return paper


@router.post("/{paper_id}/outline", response_model=PaperDetail)
async def outline(paper_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        paper = await owned_paper(db, paper_id, user.id)
        ensure_editable(paper)
        await save_version(db, paper, "大纲生成前自动备份")
        references = await refresh_references(db, paper, request.app.state.retriever, strict=True)
        result = await OutlineAgent(request.app.state.settings).execute({
            **{key: getattr(paper, key) for key in ("title", "topic", "keywords", "requirements", "paper_type", "word_limit")},
            "references": references})
        await sync_outline(db, paper, result["outline"])
        paper.outline_revision += 1
        paper.status = "outline"
        await db.commit()
        return paper


@router.post("/{paper_id}/retrieve-references", response_model=PaperDetail)
async def retrieve_references(paper_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        paper = await owned_paper(db, paper_id, user.id)
        ensure_editable(paper)
        await refresh_references(db, paper, request.app.state.retriever)
        await db.commit()
        return paper


@router.post("/{paper_id}/complete-review", response_model=PaperDetail)
async def complete_review(paper_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        paper = await owned_paper(db, paper_id, user.id)
        ensure_editable(paper)
        if not paper.final_paper.strip():
            raise HTTPException(422, "当前还没有可核对的论文初稿")
        await save_version(db, paper, "完成人工核对前自动备份")
        paper.status = "completed"
        paper.finished_at = paper.finished_at or utcnow()
        paper.quality_report = {**(paper.quality_report or {}), "human_reviewed": True,
                                "human_reviewed_at": utcnow().isoformat()}
        await db.commit()
        return paper


@router.post("/{paper_id}/generate", status_code=202)
async def generate(paper_id: int, options: GenerateRequest, request: Request, user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        run_id = await request.app.state.workflow.start(paper_id, user.id, options.model_dump())
    return {"run_id": run_id, "paper_id": paper_id, "message": "任务已启动"}


@router.post("/{paper_id}/stream-generate")
async def stream_generate(paper_id: int, options: GenerateRequest, request: Request, user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        run_id = await request.app.state.workflow.start(paper_id, user.id, options.model_dump())
    return StreamingResponse(request.app.state.workflow.stream(run_id), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "X-Run-ID": run_id})


async def owned_run(db, paper_id, run_id, user_id):
    await owned_paper(db, paper_id, user_id)
    run = await db.get(PaperRun, run_id)
    if not run or run.paper_id != paper_id:
        raise HTTPException(404, "任务不存在")
    return run


@router.get("/{paper_id}/runs")
async def runs(paper_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    await owned_paper(db, paper_id, user.id)
    records = (await db.scalars(select(PaperRun).where(PaperRun.paper_id == paper_id)
                     .order_by(PaperRun.created_at.desc()).limit(30))).all()
    return [{"id": r.id, "status": r.status, "error": r.error, "created_at": r.created_at} for r in records]


@router.get("/{paper_id}/runs/{run_id}")
async def run_status(paper_id: int, run_id: str, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    await owned_run(db, paper_id, run_id, user.id)
    return await request.app.state.workflow.status(run_id)


@router.get("/{paper_id}/runs/{run_id}/events")
async def events(paper_id: int, run_id: str, request: Request, after: int = Query(0, ge=0),
                 db=Depends(get_db), user=Depends(get_current_user)):
    await owned_run(db, paper_id, run_id, user.id)
    if request.headers.get("last-event-id", "").isdigit():
        after = max(after, int(request.headers["last-event-id"]))
    return StreamingResponse(request.app.state.workflow.stream(run_id, after), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@router.get("/{paper_id}/runs/{run_id}/event-snapshot")
async def event_snapshot(paper_id: int, run_id: str, request: Request, after: int = Query(0, ge=0),
                         limit: int = Query(1000, ge=1, le=2000),
                         db=Depends(get_db), user=Depends(get_current_user)):
    await owned_run(db, paper_id, run_id, user.id)
    return await request.app.state.workflow.event_snapshot(run_id, after, limit)


@router.get("/{paper_id}/runs/{run_id}/diagnostics")
async def diagnostics(paper_id: int, run_id: str, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    await owned_run(db, paper_id, run_id, user.id)
    return await request.app.state.workflow.diagnostics(run_id)


@router.post("/{paper_id}/runs/{run_id}/resume", status_code=202)
async def resume(paper_id: int, run_id: str, data: ResumeRequest, request: Request,
                 db=Depends(get_db), user=Depends(get_current_user)):
    await owned_run(db, paper_id, run_id, user.id)
    await request.app.state.workflow.resume(run_id, data.model_dump(exclude_none=True))
    return {"run_id": run_id, "message": "任务继续执行"}


@router.post("/{paper_id}/runs/{run_id}/pause")
async def pause(paper_id: int, run_id: str, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    await owned_run(db, paper_id, run_id, user.id)
    paused = await request.app.state.workflow.pause(run_id)
    return {"message": "任务已暂停" if paused else "任务已经结束，无需暂停", "paused": paused}


@router.post("/{paper_id}/runs/{run_id}/cancel")
async def cancel(paper_id: int, run_id: str, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    await owned_run(db, paper_id, run_id, user.id)
    await request.app.state.workflow.cancel(run_id)
    return {"message": "任务已取消"}


@router.get("/{paper_id}/versions")
async def versions(paper_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    await owned_paper(db, paper_id, user.id)
    records = (await db.scalars(select(PaperVersion).where(PaperVersion.paper_id == paper_id)
                     .order_by(PaperVersion.id.desc()))).all()
    return [{"id": v.id, "label": v.label, "created_at": v.created_at} for v in records]


@router.post("/{paper_id}/versions", status_code=201)
async def version(paper_id: int, data: VersionRequest, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        paper = await owned_paper(db, paper_id, user.id)
        ensure_editable(paper)
        saved = await save_version(db, paper, data.label)
        await db.commit()
    return {"id": saved.id, "label": saved.label}


@router.get("/{paper_id}/versions/{version_id}")
async def version_detail(paper_id: int, version_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    await owned_paper(db, paper_id, user.id)
    saved = await db.get(PaperVersion, version_id)
    if not saved or saved.paper_id != paper_id:
        raise HTTPException(404, "版本不存在")
    return {"id": saved.id, "label": saved.label, "snapshot": saved.snapshot}


@router.post("/{paper_id}/versions/{version_id}/restore", response_model=PaperDetail)
async def restore(paper_id: int, version_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock:
        paper = await owned_paper(db, paper_id, user.id)
        ensure_editable(paper)
        saved = await db.get(PaperVersion, version_id)
        if not saved or saved.paper_id != paper_id:
            raise HTTPException(404, "版本不存在")
        return await restore_version(db, paper, saved)


@router.get("/{paper_id}/export")
async def export(paper_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    paper = await owned_paper(db, paper_id, user.id)
    return Response(paper.final_paper or f"# {paper.title}\n\n{paper.abstract}", media_type="text/markdown",
                    headers={"Content-Disposition": f'attachment; filename="paper-{paper_id}.md"'})
