import asyncio
import hashlib
from pathlib import Path
from typing import Literal
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, Query, Request, UploadFile, File, Form
from fastapi.responses import Response, FileResponse
from sqlalchemy import select, func
from app.api.auth import get_current_user
from app.database import get_db
from app.models.reference import Reference, ReferenceJob, paper_references
from app.schemas.paper import ReferenceInput, ReferenceMetadata, ReferenceResponse, ReferenceJobResponse
from app.services.paper_service import owned_paper, ensure_editable
from app.services.reference_service import (get_reference, owned_reference, upload_path,
    text_digest, library_stats, reference_response)
from app.utils.helpers import format_reference

router = APIRouter()


async def optional_paper(db, paper_id, user_id):
    if paper_id is not None:
        paper = await owned_paper(db, paper_id, user_id)
        ensure_editable(paper)


@router.get("/", response_model=list[ReferenceResponse])
async def list_references(request: Request, paper_id: int | None = None, query: str = Query("", max_length=500),
        status: Literal["all", "indexed", "pending", "failed", "unavailable"] = "all",
        skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200),
        db=Depends(get_db), user=Depends(get_current_user)):
    statement = select(Reference)
    if paper_id is not None:
        await owned_paper(db, paper_id, user.id)
        statement = statement.join(paper_references).where(paper_references.c.paper_id == paper_id)
    if query.strip():
        statement = statement.where(Reference.title.contains(query.strip(), autoescape=True))
    store = request.app.state.vector_store
    ready = (Reference.index_status == "indexed") & (Reference.index_key == store.index_key)
    failed = (Reference.index_status == "failed") & (Reference.index_key == store.index_key)
    if status == "indexed":
        statement = statement.where(ready)
    elif status == "failed":
        statement = statement.where(failed)
    elif status == "pending":
        statement = statement.where(~ready, ~failed)
    elif status == "unavailable":
        statement = statement.where(~ready)
    records = (await db.scalars(statement.order_by(Reference.id.desc()).offset(skip).limit(limit))).all()
    return [reference_response(record, store) for record in records]


@router.get("/stats")
async def stats(request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    return {**await library_stats(db, request.app.state.vector_store),
            "rebuild": await request.app.state.library_indexer.job_progress()}


@router.get("/search")
async def search(request: Request, query: str = Query(min_length=1, max_length=2000),
        paper_id: int | None = None, top_k: int = Query(5, ge=1, le=30),
        db=Depends(get_db), user=Depends(get_current_user)):
    if paper_id is not None:
        await owned_paper(db, paper_id, user.id)
    return await request.app.state.retriever.search(query, top_k=top_k)


@router.post("/reindex-all", status_code=202)
async def reindex_all(request: Request, user=Depends(get_current_user)):
    count = await request.app.state.library_indexer.start(include_failed=True)
    return {"message": f"已新增 {count} 个后台索引任务；已成功或正在处理的资料会跳过"}


# 固定路径必须放在 /{reference_id} 前面，收据不暴露上传路径或私有写作任务信息。
@router.get("/jobs", response_model=list[ReferenceJobResponse])
async def jobs(status: Literal["all", "active", "failed"] = "all", skip: int = Query(0, ge=0),
        limit: int = Query(20, ge=1, le=100), db=Depends(get_db), user=Depends(get_current_user)):
    query = select(ReferenceJob)
    if status == "active":
        query = query.where(ReferenceJob.status.in_(("queued", "running")))
    elif status == "failed":
        query = query.where(ReferenceJob.status == "failed")
    ordering = (ReferenceJob.created_at, ReferenceJob.id) if status == "active" else (ReferenceJob.created_at.desc(), ReferenceJob.id.desc())
    return (await db.scalars(query.order_by(*ordering)
                            .offset(skip).limit(limit))).all()


@router.get("/jobs/{job_id}", response_model=ReferenceJobResponse)
async def job_detail(job_id: str, db=Depends(get_db), user=Depends(get_current_user)):
    job = await db.get(ReferenceJob, job_id)
    if job is None:
        raise HTTPException(404, "处理任务不存在")
    return job


@router.post("/jobs/{job_id}/retry", response_model=ReferenceJobResponse, status_code=202)
async def retry_job(job_id: str, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    manager = request.app.state.library_indexer
    async with request.app.state.library_lock:
        job = await db.get(ReferenceJob, job_id)
        if job is None:
            raise HTTPException(404, "处理任务不存在")
        if job.status in manager.active_states:
            return job
        if job.status != "failed":
            raise HTTPException(409, "此任务已完成；如需重新生成索引，请在文献详情中操作")
        if job.operation == "metadata" and job.owner_id != user.id:
            raise HTTPException(403, "重新识别书目信息请由上传者操作")
        if job.reference_id:
            active = await manager.active_job(db, job.reference_id)
            if active:
                return active
            ref = await get_reference(db, job.reference_id)
            ref.index_status, ref.index_key, ref.index_error = "pending", manager.store.index_key, {}
        elif job.operation != "upload":
            raise HTTPException(404, "原文献已移除，无法重试")
        job.status, job.stage, job.error = "queued", "queued", {}
        job.progress_done = job.progress_total = 0
        await db.commit()
        manager.wake()
        return job


@router.post("/", response_model=ReferenceJobResponse, status_code=202)
async def create(data: ReferenceInput, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.library_lock:
        await optional_paper(db, data.paper_id, user.id)
        if not data.abstract.strip():
            raise HTTPException(422, "录入文献时请提供摘要正文，或改为直接上传 PDF")
        digest = text_digest(data.title + "\n" + data.abstract)
        reference = await db.scalar(select(Reference).where(Reference.content_hash == digest))
        duplicate = reference is not None
        if reference is None:
            reference = Reference(**data.model_dump(exclude={"paper_id"}), owner_id=user.id,
                content_hash=digest, metadata_status="manual",
                metadata_sources={"input": {"source": "manual", "quote": "手动录入"}})
            db.add(reference)
            await db.flush()
        return await request.app.state.library_indexer.enqueue_reference(db, reference, user.id,
            operation="reuse" if duplicate else "reindex", paper_id=data.paper_id, duplicate=duplicate)


@router.post("/upload", response_model=ReferenceJobResponse, status_code=202)
async def upload(request: Request, file: UploadFile = File(...), paper_id: int | None = Form(None),
                 db=Depends(get_db), user=Depends(get_current_user)):
    filename = (file.filename or "document.pdf").replace("\\", "/").rsplit("/", 1)[-1][:500]
    maximum = request.app.state.settings.MAX_UPLOAD_MB * 1024 * 1024
    try:
        content = await file.read(maximum + 1)
    finally:
        await file.close()
    if len(content) > maximum:
        raise HTTPException(413, "PDF 超过上传大小限制")
    if not content.startswith(b"%PDF-"):
        raise HTTPException(422, "文件不是有效的 PDF")
    digest = hashlib.sha256(content).hexdigest()
    manager = request.app.state.library_indexer
    async with request.app.state.library_lock:
        await optional_paper(db, paper_id, user.id)
        reference = await db.scalar(select(Reference).where(Reference.file_hash == digest))
        if reference:
            return await manager.enqueue_reference(db, reference, user.id, operation="reuse",
                paper_id=paper_id, duplicate=True)
        active = await db.scalar(select(ReferenceJob).where(ReferenceJob.file_hash == digest,
            ReferenceJob.status.in_(manager.active_states)).order_by(ReferenceJob.created_at))
        if active:
            if paper_id is not None and active.paper_id != paper_id:
                raise HTTPException(409, "相同文件正在后台处理，完成后请在写作任务中重新检索关联")
            return active
        # 文件先落盘，任务提交后才返回 202；PDF 解析、模型识别、向量化全部由后台完成。
        path = upload_path(request.app.state.settings)
        await asyncio.to_thread(path.write_bytes, content)
        job = ReferenceJob(id=str(uuid4()), owner_id=user.id, paper_id=paper_id,
            filename=filename, file_path=str(path), file_hash=digest, operation="upload")
        db.add(job)
        await db.commit()
        manager.wake()
        return job


@router.get("/{reference_id}", response_model=ReferenceResponse)
async def detail(reference_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    return reference_response(await get_reference(db, reference_id), request.app.state.vector_store)


@router.post("/{reference_id}/reindex", response_model=ReferenceJobResponse, status_code=202)
async def reindex(reference_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.library_lock:
        reference = await get_reference(db, reference_id)
        return await request.app.state.library_indexer.enqueue_reference(db, reference, user.id)


@router.post("/{reference_id}/extract-metadata", response_model=ReferenceJobResponse, status_code=202)
async def recognize(reference_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.library_lock:
        reference = await owned_reference(db, reference_id, user.id)
        await request.app.state.library_indexer.ensure_idle(db, reference.id)
        if not reference.file_path or not Path(reference.file_path).is_file():
            raise HTTPException(404, "原始 PDF 不存在，无法重新识别；可手动补充信息")
        return await request.app.state.library_indexer.enqueue_reference(db, reference, user.id, operation="metadata")


@router.put("/{reference_id}", response_model=ReferenceJobResponse, status_code=202)
async def edit(reference_id: int, data: ReferenceMetadata, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.library_lock:
        reference = await owned_reference(db, reference_id, user.id)
        await request.app.state.library_indexer.ensure_idle(db, reference.id)
        if not reference.full_text:
            if not data.abstract.strip():
                raise HTTPException(422, "摘要正文不能为空")
            digest = text_digest(data.title + "\n" + data.abstract)
            duplicate = await db.scalar(select(Reference.id).where(Reference.content_hash == digest, Reference.id != reference.id))
            if duplicate:
                raise HTTPException(409, "相同题名与摘要已存在于共享库中")
            reference.content_hash = digest
        for key, value in data.model_dump().items():
            setattr(reference, key, value)
        reference.metadata_status = "manual"
        reference.metadata_sources = {**reference.metadata_sources, "review": {"source": "manual", "quote": "上传者已编辑核对，以下自动识别证据为历史记录"}}
        return await request.app.state.library_indexer.enqueue_reference(db, reference, user.id)


@router.get("/{reference_id}/citation")
async def citation(reference_id: int, style: Literal["gbt", "apa", "mla"] = "gbt",
                   db=Depends(get_db), user=Depends(get_current_user)):
    reference = await get_reference(db, reference_id)
    return {"citation": format_reference(ReferenceResponse.model_validate(reference).model_dump(), 1, style)}


@router.get("/{reference_id}/file")
async def download(reference_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    reference = await get_reference(db, reference_id)
    if not reference.file_path or not Path(reference.file_path).is_file():
        raise HTTPException(404, "原始 PDF 不存在；文献正文及已有索引仍可能可用")
    return FileResponse(reference.file_path, media_type="application/pdf", filename=reference.filename or f"reference-{reference.id}.pdf")


@router.delete("/{reference_id}", status_code=204)
async def remove(reference_id: int, request: Request, db=Depends(get_db), user=Depends(get_current_user)):
    async with request.app.state.edit_lock, request.app.state.library_lock:
        reference = await owned_reference(db, reference_id, user.id)
        await request.app.state.library_indexer.ensure_idle(db, reference.id)
        used = await db.scalar(select(func.count()).select_from(paper_references).where(paper_references.c.reference_id == reference.id))
        if used:
            raise HTTPException(409, "此文献已被写作任务关联，不能删除；删除写作任务本身不会删除共享文献")
        try:
            await asyncio.to_thread(request.app.state.vector_store.delete_reference, reference.id)
        except Exception:
            if reference.index_status == "indexed":
                raise HTTPException(503, "向量存储暂不可用，无法完成删除，请恢复存储后重试")
        await db.delete(reference)
        await db.commit()
    return Response(status_code=204)
