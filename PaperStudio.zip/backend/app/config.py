from pathlib import Path
import secrets
from typing import Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parents[1]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=BACKEND_DIR / ".env", extra="ignore", case_sensitive=True)
    APP_NAME: str = "AI 论文写作系统"
    DATA_DIR: Path = BACKEND_DIR / "data"
    DATABASE_URL: str = "sqlite+aiosqlite:///./data/paper_writer.db"
    VECTOR_DB_PATH: Path = BACKEND_DIR / "data/chroma"
    CHECKPOINT_PATH: Path = BACKEND_DIR / "data/checkpoints.sqlite"
    METRICS_LOG_PATH: Path = BACKEND_DIR / "data/logs/metrics.jsonl"
    LLM_PROVIDER: Literal["demo", "openai", "deepseek", "zhipu"] = "demo"
    OPENAI_API_KEY: str = ""
    OPENAI_BASE_URL: str = "https://api.openai.com/v1"
    OPENAI_MODEL: str = "gpt-4.1-mini"
    DEEPSEEK_API_KEY: str = ""
    DEEPSEEK_BASE_URL: str = "https://api.deepseek.com/v1"
    DEEPSEEK_MODEL: str = "deepseek-chat"
    ZHIPU_API_KEY: str = ""
    ZHIPU_BASE_URL: str = "https://open.bigmodel.cn/api/paas/v4"
    ZHIPU_MODEL: str = "glm-4-flash"
    EMBEDDING_PROVIDER: Literal["hash", "openai"] = "hash"
    EMBEDDING_MODEL: str = "text-embedding-3-small"
    EMBEDDING_API_KEY: str = ""
    EMBEDDING_BASE_URL: str = "https://api.openai.com/v1"
    RETRIEVAL_MIN_SCORE: float = Field(0.2, ge=0, le=1)
    RETRIEVAL_MODE: Literal["dense", "hybrid"] = "hybrid"
    RETRIEVAL_DENSE_WEIGHT: float = Field(0.65, ge=0, le=1)
    RETRIEVAL_LEXICAL_WEIGHT: float = Field(0.35, ge=0, le=1)
    RETRIEVAL_CANDIDATE_MULTIPLIER: int = Field(6, ge=2, le=20)
    RETRIEVAL_MAX_CHUNKS_PER_REFERENCE: int = Field(3, ge=1, le=10)
    RETRIEVAL_QUERY_EXPANSION: bool = True
    RETRIEVAL_MAX_QUERIES: int = Field(3, ge=1, le=5)
    SECRET_KEY: str = ""
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(480, ge=5, le=43200)
    MAX_PARALLEL_CHAPTERS: int = Field(3, ge=1, le=8)
    MAX_AGENT_STEPS: int = Field(30, ge=10, le=100)
    MAX_RETRIEVAL_ROUNDS: int = Field(3, ge=1, le=8)
    LLM_TIMEOUT: int = Field(120, ge=5, le=600)
    LLM_MAX_OUTPUT_TOKENS: int | None = Field(None, ge=128, le=65536)
    LLM_EXTRA_BODY: dict = Field(default_factory=dict)
    MAX_UPLOAD_MB: int = Field(20, ge=1, le=100)
    AGENT_FAST_CONTROLS: bool = True
    AGENT_SKIP_SINGLE_REFLECTION: bool = True

    @model_validator(mode="after")
    def resolve_paths(self):
        for name in ("DATA_DIR", "VECTOR_DB_PATH", "CHECKPOINT_PATH", "METRICS_LOG_PATH"):
            path = getattr(self, name)
            if not path.is_absolute():
                setattr(self, name, (BACKEND_DIR / path).resolve())
        url = self.DATABASE_URL
        if url.startswith("sqlite:///"):
            url = url.replace("sqlite:///", "sqlite+aiosqlite:///", 1)
        if url.startswith("postgresql://"):
            url = url.replace("postgresql://", "postgresql+asyncpg://", 1)
        prefix = "sqlite+aiosqlite:///"
        if url.startswith(prefix):
            path = url[len(prefix):]
            if path != ":memory:" and not Path(path).is_absolute():
                url = prefix + (BACKEND_DIR / path).resolve().as_posix()
        self.DATABASE_URL = url
        if self.SECRET_KEY and len(self.SECRET_KEY) < 32:
            raise ValueError("SECRET_KEY 至少需要 32 个字符")
        if self.RETRIEVAL_DENSE_WEIGHT + self.RETRIEVAL_LEXICAL_WEIGHT <= 0:
            raise ValueError("混合检索的向量权重与 BM25 权重不能同时为 0")
        return self

    def prepare(self):
        self.DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.CHECKPOINT_PATH.parent.mkdir(parents=True, exist_ok=True)
        self.METRICS_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        if not self.SECRET_KEY:
            path = self.DATA_DIR / ".jwt-secret"
            try:
                with path.open("x", encoding="utf-8") as stream:
                    stream.write(secrets.token_urlsafe(48))
            except FileExistsError:
                pass
            self.SECRET_KEY = path.read_text(encoding="utf-8").strip()
            if len(self.SECRET_KEY) < 32:
                raise ValueError("本地 JWT 密钥文件无效")


settings = Settings()
