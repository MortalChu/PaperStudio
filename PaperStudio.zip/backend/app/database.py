from pathlib import Path
from fastapi import Request
from sqlalchemy import event
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


class Database:
    def __init__(self, url: str):
        if url.startswith("sqlite+aiosqlite:///") and not url.endswith(":memory:"):
            Path(url.split("///", 1)[1]).parent.mkdir(parents=True, exist_ok=True)
        self.engine = create_async_engine(url, pool_pre_ping=True)
        self.sessions = async_sessionmaker(self.engine, expire_on_commit=False)
        if url.startswith("sqlite"):
            @event.listens_for(self.engine.sync_engine, "connect")
            def configure_sqlite(connection, _):
                cursor = connection.cursor()
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.execute("PRAGMA busy_timeout=10000")
                cursor.execute("PRAGMA journal_mode=WAL")
                cursor.close()

    async def initialize(self):
        from app import models  # noqa: F401
        async with self.engine.begin() as connection:
            await connection.run_sync(Base.metadata.create_all)
            from app.services.reference_service import migrate_legacy_references, migrate_index_diagnostics
            from app.services.paper_service import (migrate_human_review_status, migrate_paper_console,
                                                    migrate_global_agent_sessions)
            from app.services.agent_service import migrate_agent_storage
            await connection.run_sync(migrate_agent_storage)
            await connection.run_sync(migrate_paper_console)
            await connection.run_sync(migrate_global_agent_sessions)
            await connection.run_sync(migrate_index_diagnostics)
            await connection.run_sync(migrate_legacy_references)
            await connection.run_sync(migrate_human_review_status)


async def get_db(request: Request):
    async with request.app.state.database.sessions() as session:
        try:
            yield session
        except BaseException:
            await session.rollback()
            raise
