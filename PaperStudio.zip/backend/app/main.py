import asyncio
from contextlib import asynccontextmanager
from importlib.metadata import version
from uuid import uuid4
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from sqlalchemy import text
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver
from app.config import Settings
from app.database import Database
from app.rag.vector_store import VectorStore
from app.rag.retriever import ReferenceRetriever
from app.workflows.graph_builder import PaperWorkflowGraph
from app.workflows.paper_workflow import PaperWorkflow
from app.services.reference_service import LibraryIndexer
from app.utils.helpers import configure_logging, failure_diagnostic, ProcessingError
from app.metrics import MetricsRecorder


def create_app(settings=None):
    cfg = settings or Settings()

    @asynccontextmanager
    async def lifespan(app):
        cfg.prepare()
        app.state.log_path = configure_logging(cfg)
        app.state.metrics = MetricsRecorder(cfg.METRICS_LOG_PATH)
        database = Database(cfg.DATABASE_URL)
        await database.initialize()
        from app.services.agent_service import migrate_memory_entries
        await migrate_memory_entries(database.sessions)
        app.state.settings = cfg
        app.state.instance_id = str(uuid4())
        app.state.database = database
        app.state.vector_store = VectorStore(cfg, app.state.metrics)
        app.state.retriever = ReferenceRetriever(app.state.vector_store, database.sessions, app.state.metrics)
        app.state.edit_lock = asyncio.Lock()
        app.state.library_lock = asyncio.Lock()
        app.state.agent_chat_tasks = set()
        app.state.agent_turns = {}
        app.state.library_indexer = LibraryIndexer(database.sessions, app.state.vector_store,
                                                  app.state.library_lock, app.state.edit_lock, app.state.metrics)
        async with AsyncSqliteSaver.from_conn_string(str(cfg.CHECKPOINT_PATH)) as checkpointer:
            await checkpointer.setup()
            graph = PaperWorkflowGraph(cfg, app.state.retriever, checkpointer, database.sessions, app.state.metrics)
            app.state.workflow = PaperWorkflow(graph, database.sessions)
            await app.state.workflow.recover()
            await app.state.library_indexer.recover()
            try:
                yield
            finally:
                chat_tasks = list(app.state.agent_chat_tasks)
                for task in chat_tasks:
                    task.cancel()
                await asyncio.gather(*chat_tasks, return_exceptions=True)
                await app.state.workflow.close()
                await app.state.library_indexer.close()
                await database.engine.dispose()

    app = FastAPI(title=cfg.APP_NAME, version="1.0.0", lifespan=lifespan)
    from app.api import agent, auth, papers, chapters, references
    for name, module in (("auth", auth), ("papers", papers), ("chapters", chapters),
                         ("references", references), ("agent", agent)):
        app.include_router(module.router, prefix=f"/api/{name}", tags=[name])

    @app.exception_handler(ValueError)
    async def value_error(request, exc):
        return JSONResponse(status_code=422, content={"detail": str(exc)[:500]})

    @app.exception_handler(ProcessingError)
    async def processing_error(request, exc):
        diagnostic = failure_diagnostic(exc, cfg, step="api_request")
        # 模型认证失败不能返回业务登录的 401，否则前端会误退出用户登录。
        return JSONResponse(status_code=502, content={"detail": diagnostic["message"], "diagnostic": diagnostic})

    @app.exception_handler(Exception)
    async def unexpected_error(request, exc):
        diagnostic = failure_diagnostic(exc, cfg, step="api_request")
        return JSONResponse(status_code=500, content={"detail": diagnostic["message"], "diagnostic": diagnostic})

    @app.get("/")
    async def root():
        return {"message": cfg.APP_NAME, "docs": "/docs"}

    @app.get("/health")
    async def health():
        async with app.state.database.sessions() as db:
            await db.execute(text("SELECT 1"))
        configured = cfg.LLM_PROVIDER == "demo" or bool(getattr(cfg, cfg.LLM_PROVIDER.upper() + "_API_KEY"))
        return {"status": "ok", "database": "connected", "llm_mode": cfg.LLM_PROVIDER,
                "instance_id": app.state.instance_id,
                "llm_configured": configured, "llm_connectivity": "not_probed",
                "llm_model": "内置演示模板" if cfg.LLM_PROVIDER == "demo" else getattr(cfg, cfg.LLM_PROVIDER.upper() + "_MODEL"),
                "embedding_mode": cfg.EMBEDDING_PROVIDER,
                "embedding_model": "离线词面特征" if cfg.EMBEDDING_PROVIDER == "hash" else cfg.EMBEDDING_MODEL,
                "embedding_configured": cfg.EMBEDDING_PROVIDER == "hash" or bool(cfg.EMBEDDING_API_KEY or cfg.OPENAI_API_KEY),
                "retrieval_mode": cfg.RETRIEVAL_MODE, "agent_mode": "autonomous_plan_act_observe_reflect",
                "metrics_log": str(cfg.METRICS_LOG_PATH),
                "vector_store": "initialized" if app.state.vector_store._collection else "lazy",
                "versions": {p: version(p) for p in ("langchain", "langgraph", "fastapi")}}

    return app


app = create_app()
