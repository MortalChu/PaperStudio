import json
import threading
from datetime import datetime, timezone
from pathlib import Path


class MetricsRecorder:
    """Append-only JSONL metrics separated from diagnostic/application logs."""

    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def record(self, event: str, **fields):
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": event,
            **{key: value for key, value in fields.items() if value is not None},
        }
        line = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), default=str)
        with self._lock, self.path.open("a", encoding="utf-8") as stream:
            stream.write(line + "\n")

