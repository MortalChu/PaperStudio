from datetime import datetime
from enum import StrEnum
from sqlalchemy import DateTime, ForeignKey, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database import Base
from app.models.user import utcnow


class PaperStatus(StrEnum):
    DRAFT = "draft"
    OUTLINE = "outline"
    WRITING = "writing"
    REVIEW = "review"
    COMPLETED = "completed"


class Paper(Base):
    __tablename__ = "papers"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(500))
    topic: Mapped[str] = mapped_column(String(200), default="")
    keywords: Mapped[str] = mapped_column(String(500), default="")
    abstract: Mapped[str] = mapped_column(Text, default="")
    paper_type: Mapped[str] = mapped_column(String(20), default="research")
    word_limit: Mapped[int] = mapped_column(default=5000)
    requirements: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(20), default="draft")
    outline: Mapped[dict | None] = mapped_column(JSON)
    final_paper: Mapped[str] = mapped_column(Text, default="")
    quality_report: Mapped[dict] = mapped_column(JSON, default=dict)
    agent_preferences: Mapped[dict] = mapped_column(JSON, default=dict)
    author_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    active_run_id: Mapped[str | None] = mapped_column(String(36))
    outline_revision: Mapped[int] = mapped_column(default=0)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    deleted_from_status: Mapped[str] = mapped_column(String(20), default="")
    purge_after: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    chapters: Mapped[list["Chapter"]] = relationship(  # noqa: F821
        cascade="all, delete-orphan", lazy="selectin", order_by="Chapter.order_index")
    references: Mapped[list["Reference"]] = relationship(  # noqa: F821
        secondary="paper_references", lazy="selectin", order_by="Reference.id")


class PaperVersion(Base):
    __tablename__ = "paper_versions"
    id: Mapped[int] = mapped_column(primary_key=True)
    paper_id: Mapped[int] = mapped_column(ForeignKey("papers.id", ondelete="CASCADE"), index=True)
    label: Mapped[str] = mapped_column(String(200))
    snapshot: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class PaperRun(Base):
    __tablename__ = "paper_runs"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    paper_id: Mapped[int] = mapped_column(ForeignKey("papers.id", ondelete="CASCADE"), index=True)
    status: Mapped[str] = mapped_column(String(20), default="running")
    options: Mapped[dict] = mapped_column(JSON, default=dict)
    events: Mapped[list] = mapped_column(JSON, default=list)
    error: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class AgentMessage(Base):
    """One durable turn in the user/agent conversation for a paper."""
    __tablename__ = "agent_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    paper_id: Mapped[int] = mapped_column(ForeignKey("papers.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(20))
    content: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="completed", index=True)
    action: Mapped[str] = mapped_column(String(30), default="none")
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class GlobalAgentSession(Base):
    """A durable named conversation owned by one account."""
    __tablename__ = "global_agent_sessions"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(200), default="新会话")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class GlobalAgentMessage(Base):
    """A durable user-level conversation that exists without a paper task."""
    __tablename__ = "global_agent_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    session_id: Mapped[int | None] = mapped_column(
        ForeignKey("global_agent_sessions.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(20))
    content: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="completed", index=True)
    action: Mapped[str] = mapped_column(String(30), default="none")
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
