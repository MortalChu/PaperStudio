from datetime import datetime
from sqlalchemy import ForeignKey, String, Text, JSON, Table, Column, Integer, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from app.database import Base
from app.models.user import utcnow


paper_references = Table(
    "paper_references", Base.metadata,
    Column("paper_id", Integer, ForeignKey("papers.id", ondelete="CASCADE"), primary_key=True),
    Column("reference_id", Integer, ForeignKey("library_references.id", ondelete="CASCADE"), primary_key=True),
)


class Reference(Base):
    """部署实例共享的文献；owner_id 仅表示上传者，不限制检索可见性。"""
    __tablename__ = "library_references"
    __table_args__ = {"sqlite_autoincrement": True}
    id: Mapped[int] = mapped_column(primary_key=True)
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True)
    title: Mapped[str] = mapped_column(String(500))
    authors: Mapped[str] = mapped_column(String(500), default="")
    journal: Mapped[str] = mapped_column(String(200), default="")
    year: Mapped[int | None]
    volume: Mapped[str] = mapped_column(String(50), default="")
    issue: Mapped[str] = mapped_column(String(50), default="")
    pages: Mapped[str] = mapped_column(String(50), default="")
    doi: Mapped[str] = mapped_column(String(200), default="")
    url: Mapped[str] = mapped_column(String(1000), default="")
    abstract: Mapped[str] = mapped_column(Text, default="")
    full_text: Mapped[str] = mapped_column(Text, default="")
    file_path: Mapped[str] = mapped_column(String(1000), default="")
    vector_id: Mapped[str] = mapped_column(String(100), default="")
    index_status: Mapped[str] = mapped_column(String(20), default="pending")
    index_key: Mapped[str] = mapped_column(String(100), default="")
    index_error: Mapped[dict] = mapped_column(JSON, default=dict, server_default="{}")
    file_hash: Mapped[str | None] = mapped_column(String(64), unique=True)
    content_hash: Mapped[str | None] = mapped_column(String(64), unique=True)
    filename: Mapped[str] = mapped_column(String(500), default="")
    metadata_status: Mapped[str] = mapped_column(String(30), default="needs_review")
    metadata_sources: Mapped[dict] = mapped_column(JSON, default=dict)


class LibraryMigration(Base):
    __tablename__ = "library_migrations"
    name: Mapped[str] = mapped_column(String(100), primary_key=True)


class LegacyReferenceLink(Base):
    __tablename__ = "legacy_reference_links"
    legacy_id: Mapped[int] = mapped_column(primary_key=True)
    reference_id: Mapped[int] = mapped_column(ForeignKey("library_references.id", ondelete="CASCADE"))


class ReferenceJob(Base):
    """上传收据及持久后台任务；耗时解析与向量请求不占用 HTTP 请求。"""
    __tablename__ = "reference_jobs"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True)
    reference_id: Mapped[int | None] = mapped_column(ForeignKey("library_references.id", ondelete="SET NULL"), index=True)
    paper_id: Mapped[int | None] = mapped_column(ForeignKey("papers.id", ondelete="SET NULL"))
    operation: Mapped[str] = mapped_column(String(20), default="upload")
    status: Mapped[str] = mapped_column(String(20), default="queued", index=True)
    stage: Mapped[str] = mapped_column(String(30), default="queued")
    filename: Mapped[str] = mapped_column(String(500), default="")
    file_path: Mapped[str] = mapped_column(String(1000), default="")
    file_hash: Mapped[str] = mapped_column(String(64), default="", index=True)
    duplicate: Mapped[bool] = mapped_column(default=False)
    progress_done: Mapped[int] = mapped_column(default=0)
    progress_total: Mapped[int] = mapped_column(default=0)
    error: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
