import hashlib
import math
import re
from langchain_core.embeddings import Embeddings
from langchain_openai import OpenAIEmbeddings


class HashEmbeddings(Embeddings):
    """Offline lexical feature hashing for demos, not a semantic language model."""
    def embed_documents(self, texts):
        result = []
        for text in texts:
            vector = [0.0] * 384
            clean = re.sub(r"\s+", "", text.lower())
            tokens = re.findall(r"[a-z0-9]+", text.lower()) + [clean[i:i+2] for i in range(len(clean)-1)]
            for token in tokens:
                digest = hashlib.sha256(token.encode()).digest()
                vector[int.from_bytes(digest[:4], "big") % 384] += 1.0
            norm = math.sqrt(sum(x*x for x in vector)) or 1.0
            result.append([x / norm for x in vector])
        return result

    def embed_query(self, text):
        return self.embed_documents([text])[0]


def get_embedding_model(settings):
    if settings.EMBEDDING_PROVIDER == "hash":
        return HashEmbeddings()
    key = settings.EMBEDDING_API_KEY or settings.OPENAI_API_KEY
    if not key:
        raise ValueError("语义检索需要配置 EMBEDDING_API_KEY 或 OPENAI_API_KEY")
    return OpenAIEmbeddings(model=settings.EMBEDDING_MODEL, api_key=key,
                           base_url=settings.EMBEDDING_BASE_URL, check_embedding_ctx_length=False,
                           request_timeout=settings.LLM_TIMEOUT, max_retries=0)
