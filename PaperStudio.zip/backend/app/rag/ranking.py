import math
import re
from collections import Counter


def tokenize(text: str) -> list[str]:
    """Tokenize mixed Chinese/English text without an external segmenter."""
    normalized = str(text or "").casefold()
    latin = re.findall(r"[a-z0-9]+(?:[-_.][a-z0-9]+)*", normalized)
    chinese_runs = re.findall(r"[\u3400-\u9fff]+", normalized)
    chinese = []
    for run in chinese_runs:
        chinese.extend(run)
        chinese.extend(run[index:index + 2] for index in range(len(run) - 1))
    return latin + chinese


def bm25_rank(query: str, documents: list[dict], top_k: int, *, k1: float = 1.5, b: float = 0.75) -> list[dict]:
    if not documents or top_k <= 0:
        return []
    tokenized = [tokenize(item.get("text", "")) for item in documents]
    query_terms = list(dict.fromkeys(tokenize(query)))
    if not query_terms:
        return []
    lengths = [len(tokens) for tokens in tokenized]
    average_length = sum(lengths) / max(len(lengths), 1) or 1.0
    document_frequency = Counter()
    for tokens in tokenized:
        document_frequency.update(set(tokens))
    total = len(documents)
    scored = []
    for item, tokens, length in zip(documents, tokenized, lengths):
        frequencies = Counter(tokens)
        score = 0.0
        for term in query_terms:
            frequency = frequencies.get(term, 0)
            if not frequency:
                continue
            frequency_in_documents = document_frequency[term]
            inverse_frequency = math.log(1 + (total - frequency_in_documents + 0.5) /
                                         (frequency_in_documents + 0.5))
            denominator = frequency + k1 * (1 - b + b * length / average_length)
            score += inverse_frequency * frequency * (k1 + 1) / denominator
        if score > 0:
            scored.append({**item, "lexical_raw_score": score})
    scored.sort(key=lambda item: item["lexical_raw_score"], reverse=True)
    maximum = scored[0]["lexical_raw_score"] if scored else 1.0
    return [{**item, "lexical_score": round(item["lexical_raw_score"] / maximum, 6)}
            for item in scored[:top_k]]


def reciprocal_rank_fusion(rankings: list[tuple[list[dict], float]], *, rank_constant: int = 60) -> list[dict]:
    fused: dict[str, dict] = {}
    maximum = sum(weight / (rank_constant + 1) for _, weight in rankings) or 1.0
    for ranking, weight in rankings:
        for rank, item in enumerate(ranking, 1):
            key = str(item.get("chunk_id") or f"{item.get('reference_id')}:{item.get('page')}:{item.get('text', '')[:80]}")
            entry = fused.setdefault(key, {**item, "fusion_raw_score": 0.0})
            entry.update({name: value for name, value in item.items()
                          if name in ("dense_score", "lexical_score") and value is not None})
            entry["fusion_raw_score"] += weight / (rank_constant + rank)
    results = []
    for item in fused.values():
        item["fusion_score"] = round(min(1.0, item.pop("fusion_raw_score") / maximum), 6)
        results.append(item)
    return sorted(results, key=lambda item: item["fusion_score"], reverse=True)


def term_coverage(query: str, text: str) -> float:
    terms = set(tokenize(query))
    if not terms:
        return 0.0
    present = set(tokenize(text))
    return len(terms & present) / len(terms)

