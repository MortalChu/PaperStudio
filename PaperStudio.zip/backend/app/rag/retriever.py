import asyncio
import time
from sqlalchemy import select
from app.models.reference import Reference
from app.schemas.paper import ReferenceResponse
from app.utils.helpers import ProcessingError
from app.rag.ranking import reciprocal_rank_fusion, term_coverage


class ReferenceRetriever:
    def __init__(self, vector_store, sessions, metrics=None):
        self.vector_store = vector_store
        self.sessions = sessions
        self.metrics = metrics

    async def search(self, query: str, owner_id: int | None = None, paper_id: int | None = None, top_k=5):
        started = time.perf_counter()
        # owner_id / paper_id 仅保留内部调用兼容性；任务权限由 API 层检查，检索范围为共享库。
        async with self.sessions() as db:
            ready = await db.scalar(select(Reference.id).where(
                Reference.index_status == "indexed", Reference.index_key == self.vector_store.index_key).limit(1))
        if ready is None:
            self._record(started, query, 0, 0)
            return []
        try:
            candidate_k = top_k * self.vector_store.settings.RETRIEVAL_CANDIDATE_MULTIPLIER
            hits = await asyncio.to_thread(self.vector_store.search, query, candidate_k)
        except Exception as exc:
            raise ProcessingError(exc, service="embedding", agent="reference") from exc
        if not hits:
            self._record(started, query, 0, 0)
            return []
        async with self.sessions() as db:
            records = (await db.scalars(select(Reference).where(
                Reference.index_status == "indexed", Reference.index_key == self.vector_store.index_key,
                Reference.id.in_([h["reference_id"] for h in hits])))).all()
            records = {r.id: r for r in records}
            enriched = []
            for hit in hits:
                record = records.get(hit["reference_id"])
                if not record:
                    continue
                metadata = ReferenceResponse.model_validate(record).model_dump()
                coverage = term_coverage(query, " ".join((record.title, record.abstract, hit["text"])))
                exact_bonus = 0.08 if query.casefold() in (record.title + " " + hit["text"]).casefold() else 0.0
                rerank_score = min(1.0, 0.72 * hit["score"] + 0.28 * coverage + exact_bonus)
                enriched.append({**metadata, "excerpt": hit["text"], "page": hit["page"],
                                 "score": round(rerank_score, 6), "rerank_score": round(rerank_score, 6),
                                 "dense_score": hit.get("dense_score", 0.0),
                                 "lexical_score": hit.get("lexical_score", 0.0),
                                 "fusion_score": hit.get("fusion_score", hit["score"]),
                                 "retrieval_method": hit.get("retrieval_method", "dense"),
                                 "chunk_id": hit.get("chunk_id", "")})
            enriched.sort(key=lambda item: item["score"], reverse=True)
            selected, per_reference = [], {}
            for item in enriched:
                if item["score"] < self.vector_store.settings.RETRIEVAL_MIN_SCORE:
                    continue
                count = per_reference.get(item["id"], 0)
                if count >= self.vector_store.settings.RETRIEVAL_MAX_CHUNKS_PER_REFERENCE:
                    continue
                selected.append(item)
                per_reference[item["id"]] = count + 1
                if len(selected) >= top_k:
                    break
            self._record(started, query, len(hits), len(selected))
            return selected

    async def search_many(self, queries: list[str], top_k=5):
        unique_queries = list(dict.fromkeys(query.strip() for query in queries if query.strip()))
        if not unique_queries:
            return []
        rankings = []
        for query in unique_queries:
            rankings.append((await self.search(query, top_k=max(top_k * 2, 10)), 1.0))
        fused = reciprocal_rank_fusion(rankings)
        by_chunk = {}
        for ranking, _ in rankings:
            for item in ranking:
                by_chunk[item.get("chunk_id") or f"{item['id']}:{item.get('page')}:{item['excerpt'][:80]}"] = item
        reranked = []
        for fused_item in fused:
            key = fused_item.get("chunk_id") or f"{fused_item.get('id')}:{fused_item.get('page')}:{fused_item.get('excerpt', '')[:80]}"
            item = by_chunk.get(key, fused_item)
            reranked.append({**item, "multi_query_score": fused_item["fusion_score"],
                             "score": round(0.75 * item["score"] + 0.25 * fused_item["fusion_score"], 6)})
        reranked.sort(key=lambda item: item["score"], reverse=True)
        results = []
        per_reference = {}
        for item in reranked:
            reference_id = item["id"]
            if per_reference.get(reference_id, 0) >= self.vector_store.settings.RETRIEVAL_MAX_CHUNKS_PER_REFERENCE:
                continue
            results.append(item)
            per_reference[reference_id] = per_reference.get(reference_id, 0) + 1
            if len(results) >= top_k:
                break
        return results

    def _record(self, started, query, candidate_count, returned_count):
        if self.metrics:
            self.metrics.record("retrieval", mode=self.vector_store.settings.RETRIEVAL_MODE,
                                duration_ms=round((time.perf_counter() - started) * 1000, 3),
                                query_characters=len(query), candidate_count=candidate_count,
                                returned_count=returned_count,
                                embedding_provider=self.vector_store.settings.EMBEDDING_PROVIDER)
