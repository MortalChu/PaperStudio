import hashlib
import threading
import time
import chromadb
from chromadb.config import Settings as ChromaSettings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from app.rag.embeddings import get_embedding_model
from app.rag.ranking import bm25_rank, reciprocal_rank_fusion


class IndexBuildError(RuntimeError):
    def __init__(self, stage, original):
        self.stage, self.original = stage, original
        super().__init__(f"Index build failed at {stage}")


class VectorStore:
    def __init__(self, settings, metrics=None):
        self.settings = settings
        self.metrics = metrics
        self._collection = None
        self._lock = threading.Lock()
        self._lexical_cache = None
        self._lexical_cache_count = -1
        self.embeddings = None
        fingerprint = hashlib.sha256(("shared-v2:" + settings.EMBEDDING_PROVIDER + ":" +
            settings.EMBEDDING_MODEL + ":" + settings.EMBEDDING_BASE_URL).encode()).hexdigest()[:16]
        self.index_key = "shared_references_" + fingerprint

    def initialize(self):
        with self._lock:
            if self._collection is None:
                client = chromadb.PersistentClient(path=str(self.settings.VECTOR_DB_PATH),
                         settings=ChromaSettings(anonymized_telemetry=False))
                # 模型配置切换后使用新集合；后台根据保存的正文重建索引。
                self._collection = client.get_or_create_collection(
                    self.index_key, embedding_function=None,
                    metadata={"hnsw:space": "cosine"})
        return self._collection

    def embedding_model(self):
        with self._lock:
            if self.embeddings is None:
                self.embeddings = get_embedding_model(self.settings)
        return self.embeddings

    def add_reference(self, reference: dict, pages: list[dict], progress=None):
        started = time.perf_counter()
        progress = progress or (lambda stage, done, total: None)
        try:
            progress("storage", 0, 0)
            collection = self.initialize()
        except IndexBuildError:
            raise
        except Exception as exc:
            raise IndexBuildError("storage", exc) from exc
        splitter = RecursiveCharacterTextSplitter(chunk_size=1200, chunk_overlap=180,
                     separators=["\n\n", "\n", "。", ". ", " ", ""])
        texts, metadatas, ids = [], [], []
        for page in pages:
            for chunk in splitter.split_text(page["text"]):
                ids.append(f"ref-{reference['id']}-{len(ids)}")
                texts.append(chunk)
                metadatas.append({"reference_id": reference["id"], "page": page.get("page", 0)})
        if not texts:
            raise ValueError("文献没有可检索的文本")
        progress("embedding", 0, len(texts))
        try:
            model = self.embedding_model()
            vectors = []
            # 控制单次请求片段数，避免把整份长 PDF 一次发给向量服务。
            for start in range(0, len(texts), 16):
                batch = texts[start:start + 16]
                batch_vectors = model.embed_documents(batch)
                if len(batch_vectors) != len(batch):
                    raise ValueError("embedding_count_mismatch")
                vectors.extend(batch_vectors)
                progress("embedding", len(vectors), len(texts))
        except IndexBuildError:
            raise
        except Exception as exc:
            raise IndexBuildError("embedding", exc) from exc
        # Replace after embeddings succeed; failed remote calls leave the previous index intact.
        try:
            progress("storage", 0, len(ids))
            collection.delete(where={"reference_id": reference["id"]})
            for i in range(0, len(ids), 100):
                collection.upsert(ids=ids[i:i+100], documents=texts[i:i+100],
                                  metadatas=metadatas[i:i+100], embeddings=vectors[i:i+100])
                progress("storage", min(i + 100, len(ids)), len(ids))
        except IndexBuildError:
            raise
        except Exception as exc:
            raise IndexBuildError("storage", exc) from exc
        self._lexical_cache = None
        self._lexical_cache_count = -1
        if self.metrics:
            self.metrics.record("index_build", reference_id=reference["id"], status="completed",
                                chunk_count=len(ids), duration_ms=round((time.perf_counter() - started) * 1000, 3),
                                embedding_provider=self.settings.EMBEDDING_PROVIDER)
        return len(ids)

    def dense_search(self, query, top_k=5):
        collection = self.initialize()
        if collection.count() == 0:
            return []
        result = collection.query(query_embeddings=[self.embedding_model().embed_query(query)],
            n_results=min(top_k, collection.count()),
            include=["documents", "metadatas", "distances"])
        return [{"chunk_id": chunk_id, "text": text, **metadata,
                 "dense_score": round(max(0.0, 1 - distance), 6),
                 "score": round(max(0.0, 1 - distance), 6), "retrieval_method": "dense"}
                for chunk_id, text, metadata, distance in zip(
                    result["ids"][0], result["documents"][0], result["metadatas"][0],
                    result["distances"][0])]

    def _lexical_documents(self):
        collection = self.initialize()
        count = collection.count()
        if self._lexical_cache is not None and self._lexical_cache_count == count:
            return self._lexical_cache
        result = collection.get(include=["documents", "metadatas"])
        self._lexical_cache = [
            {"chunk_id": chunk_id, "text": text, **metadata}
            for chunk_id, text, metadata in zip(result["ids"], result["documents"], result["metadatas"])
        ]
        self._lexical_cache_count = count
        return self._lexical_cache

    def lexical_search(self, query, top_k=5):
        return [{**item, "score": item["lexical_score"], "retrieval_method": "bm25"}
                for item in bm25_rank(query, self._lexical_documents(), top_k)]

    def hybrid_search(self, query, top_k=5):
        candidate_k = max(top_k, 1)
        dense = self.dense_search(query, candidate_k)
        lexical = self.lexical_search(query, candidate_k)
        fused = reciprocal_rank_fusion([
            (dense, self.settings.RETRIEVAL_DENSE_WEIGHT),
            (lexical, self.settings.RETRIEVAL_LEXICAL_WEIGHT),
        ])
        return [{**item, "score": item["fusion_score"], "retrieval_method": "hybrid_rrf"}
                for item in fused[:candidate_k]]

    def search(self, query, top_k=5, mode=None):
        mode = mode or self.settings.RETRIEVAL_MODE
        return self.hybrid_search(query, top_k) if mode == "hybrid" else self.dense_search(query, top_k)

    def delete_reference(self, reference_id):
        self.initialize().delete(where={"reference_id": reference_id})
        self._lexical_cache = None
        self._lexical_cache_count = -1
