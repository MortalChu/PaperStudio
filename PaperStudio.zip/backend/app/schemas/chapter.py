from pydantic import BaseModel, ConfigDict, Field
from typing import Literal


class ChapterCreate(BaseModel):
    paper_id: int
    parent_id: int | None = None
    title: str = Field(min_length=1, max_length=200)
    order_index: int = Field(0, ge=0)
    content: str = Field("", max_length=100000)
    points: list[str] = Field(default_factory=list, max_length=30)
    word_count: int = Field(1000, ge=100, le=10000)


class ChapterUpdate(BaseModel):
    title: str | None = Field(None, min_length=1, max_length=200)
    content: str | None = Field(None, max_length=100000)
    summary: str | None = Field(None, max_length=10000)


class ChapterResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    paper_id: int
    parent_id: int | None
    section_key: str
    order_index: int
    title: str
    content: str
    summary: str
    points: list[str]
    word_count: int


class PolishRequest(BaseModel):
    focus: Literal["all", "language", "logic", "format"] = "all"
