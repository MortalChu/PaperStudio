from datetime import datetime
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator
from app.schemas.chapter import ChapterResponse


class Section(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    points: list[str] = Field(default_factory=list, max_length=30)
    word_count: int = Field(800, ge=100, le=10000)
    subsections: list["Section"] = Field(default_factory=list, max_length=12)


class Outline(BaseModel):
    title: str = Field(min_length=5, max_length=500)
    sections: list[Section] = Field(min_length=1, max_length=20)

    @model_validator(mode="after")
    def bounded_tree(self):
        def count(nodes, depth=1):
            if depth > 3:
                raise ValueError("大纲最多支持三级章节")
            return sum(1 + (count(n.subsections, depth + 1) if n.subsections else 0) for n in nodes)
        if count(self.sections) > 40:
            raise ValueError("章节总数不能超过 40")
        return self


class PaperCreate(BaseModel):
    title: str = Field(min_length=5, max_length=500)
    topic: str = Field("", max_length=200)
    keywords: str = Field("", max_length=500)
    abstract: str = Field("", max_length=10000)
    paper_type: Literal["research", "review", "application"] = "research"
    word_limit: int = Field(5000, ge=1000, le=30000)
    requirements: str = Field("", max_length=10000)


class PaperUpdate(BaseModel):
    title: str | None = Field(None, min_length=5, max_length=500)
    topic: str | None = Field(None, max_length=200)
    keywords: str | None = Field(None, max_length=500)
    abstract: str | None = Field(None, max_length=10000)
    requirements: str | None = Field(None, max_length=10000)
    outline: Outline | None = None


class WordLimitUpdate(BaseModel):
    word_limit: int = Field(ge=1000, le=30000)


class ReferenceMetadata(BaseModel):
    title: str = Field(min_length=1, max_length=500)
    authors: str = Field("", max_length=500)
    journal: str = Field("", max_length=200)
    year: int | None = Field(None, ge=1500, le=2100)
    volume: str = Field("", max_length=50)
    issue: str = Field("", max_length=50)
    pages: str = Field("", max_length=50)
    doi: str = Field("", max_length=200)
    url: str = Field("", max_length=1000)
    abstract: str = Field("", max_length=50000)


class ReferenceInput(ReferenceMetadata):
    # 兼容旧客户端的可选关联参数；文献自身不再隶属于任务。
    paper_id: int | None = None


class ReferenceResponse(ReferenceMetadata):
    model_config = ConfigDict(from_attributes=True)
    id: int
    index_status: str
    index_error: dict = Field(default_factory=dict)
    owner_id: int | None = None
    metadata_status: str = "needs_review"
    metadata_sources: dict = Field(default_factory=dict)
    filename: str = ""


class ReferenceUploadResponse(ReferenceResponse):
    duplicate: bool = False
    message: str = ""


class ReferenceJobResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    reference_id: int | None
    operation: str
    status: str
    stage: str
    filename: str
    duplicate: bool
    progress_done: int
    progress_total: int
    error: dict
    created_at: datetime
    updated_at: datetime


class MetadataExtraction(BaseModel):
    title: str = Field("", max_length=500)
    authors: str = Field("", max_length=500)
    journal: str = Field("", max_length=200)
    year: int | None = Field(None, ge=1500, le=2100)
    volume: str = Field("", max_length=50)
    issue: str = Field("", max_length=50)
    pages: str = Field("", max_length=50)
    doi: str = Field("", max_length=200)
    url: str = Field("", max_length=1000)
    abstract: str = Field("", max_length=10000)
    evidence: dict[str, str] = Field(default_factory=dict, max_length=12)


class PaperResponse(PaperCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    author_id: int
    status: str
    outline: dict | None
    active_run_id: str | None
    outline_revision: int = 0
    deleted_at: datetime | None = None
    deleted_from_status: str = ""
    purge_after: datetime | None = None
    finished_at: datetime | None = None
    agent_preferences: dict = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class PaperDetail(PaperResponse):
    chapters: list[ChapterResponse]
    references: list[ReferenceResponse]
    final_paper: str
    quality_report: dict


class TopicRequest(BaseModel):
    field: str = Field(min_length=2, max_length=200)
    keywords: str = Field("", max_length=500)
    requirements: str = Field("", max_length=5000)


class GenerateRequest(BaseModel):
    is_topic_clear: bool = True
    review_outline: bool = True
    max_revisions: int = Field(1, ge=0, le=3)
    citation_style: Literal["gbt", "apa", "mla"] = "gbt"
    confirm_overwrite: bool = False


class ResumeRequest(BaseModel):
    title: str | None = Field(None, min_length=5, max_length=500)
    outline: Outline | None = None
    approved: bool = True
    auto_review: bool | None = None


class OutlineSaveRequest(BaseModel):
    outline: Outline
    expected_revision: int = Field(ge=0)
    source: Literal["manual", "auto"] = "manual"


class VersionRequest(BaseModel):
    label: str = Field("手动保存", min_length=1, max_length=200)


class AgentPreferencesUpdate(BaseModel):
    auto_review: bool | None = None
    annotation_color: str | None = Field(None, pattern=r"^#[0-9A-Fa-f]{6}$")
    collapse_quality_issues: bool | None = None
    collapse_agent_trace: bool | None = None
    writing_style: str | None = Field(None, max_length=1000)
    persistent_instructions: str | None = Field(None, max_length=3000)
    preference_memory: list[str] | None = Field(None, max_length=100)


class AgentChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=5000)


class GlobalAgentTurnRequest(AgentChatRequest):
    session_id: int | None = Field(None, ge=1)


class AgentMessageResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    role: str
    content: str
    status: str
    action: str
    details: dict = Field(default_factory=dict)
    created_at: datetime
    completed_at: datetime | None


class AgentChatResponse(BaseModel):
    user_message: AgentMessageResponse
    assistant_message: AgentMessageResponse
    preferences: dict
    operation: str
    run_id: str | None = None
    queued: bool = False
