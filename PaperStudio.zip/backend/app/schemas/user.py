from pydantic import BaseModel, ConfigDict, EmailStr, Field


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=50, pattern=r"^[\w-]+$")
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    email: str
    preferences: dict = Field(default_factory=dict)


class UserPreferencesUpdate(BaseModel):
    auto_review: bool | None = None
    annotation_color: str | None = Field(None, pattern=r"^#[0-9A-Fa-f]{6}$")
    collapse_quality_issues: bool | None = None
    collapse_agent_trace: bool | None = None
    writing_style: str | None = Field(None, max_length=1000)
    persistent_instructions: str | None = Field(None, max_length=3000)
    preference_memory: list[str] | None = Field(None, max_length=100)


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=50)
    password: str = Field(min_length=1, max_length=128)
