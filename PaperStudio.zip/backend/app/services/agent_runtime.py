import asyncio
import logging
from time import perf_counter
from dataclasses import dataclass
from typing import Awaitable, Callable


@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: dict
    handler: Callable[[dict], Awaitable[dict]]
    destructive: bool = False


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, ToolSpec] = {}
        self._defaults: dict = {}

    def register(self, spec: ToolSpec):
        if spec.name in self._tools:
            raise ValueError(f"重复的 Agent 工具：{spec.name}")
        self._tools[spec.name] = spec
        return self

    def with_defaults(self, **values):
        self._defaults = {key: value for key, value in values.items() if value is not None}
        return self

    def manifest(self):
        return [{"name": item.name, "description": item.description,
                 "parameters": item.parameters, "destructive": item.destructive}
                for item in self._tools.values()]

    async def execute(self, call):
        name = str(call.get("name") or "")
        supplied = call.get("arguments") if isinstance(call.get("arguments"), dict) else {}
        defaults = {} if supplied.get("title") or supplied.get("paper_id") else self._defaults
        arguments = {**defaults, **supplied}
        tool = self._tools.get(name)
        if not tool:
            return {"tool": name, "ok": False, "code": "unsupported_tool",
                    "message": f"当前 Agent 没有可执行 `{name}` 的工具。", "output": {}}
        properties = tool.parameters.get("properties", {})
        arguments = {**{k: v for k, v in defaults.items() if k in properties}, **supplied}
        invalid = []
        for key, value in supplied.items():
            schema = properties.get(key)
            if schema is None:
                if tool.parameters.get("additionalProperties") is False:
                    invalid.append(key)
                continue
            kind = schema.get("type")
            valid = {"string": isinstance(value, str), "integer": type(value) is int,
                     "boolean": type(value) is bool, "array": isinstance(value, list),
                     "object": isinstance(value, dict)}.get(kind, True)
            if valid and "enum" in schema:
                valid = value in schema["enum"]
            if valid and kind == "integer":
                valid = schema.get("minimum", value) <= value <= schema.get("maximum", value)
            if not valid:
                invalid.append(key)
        if invalid:
            return {"tool": name, "ok": False, "code": "invalid_arguments",
                    "message": "工具参数格式不正确：" + "、".join(invalid), "output": {}}
        required = tool.parameters.get("required", [])
        missing = [key for key in required if arguments.get(key) in (None, "")]
        if missing:
            return {"tool": name, "ok": False, "code": "missing_arguments",
                    "message": "执行该操作还需要提供：" + "、".join(missing) + "。", "output": {}}
        try:
            output = await tool.handler(arguments)
            if not isinstance(output, dict):
                output = {"value": output}
            return {"tool": name, "ok": True, "code": "completed",
                    "message": str(output.get("message") or f"工具 {name} 已执行。"), "output": output}
        except LookupError as exc:
            return {"tool": name, "ok": False, "code": "target_not_found",
                    "message": str(exc), "output": {}}
        except ValueError as exc:
            return {"tool": name, "ok": False, "code": "invalid_request",
                    "message": str(exc), "output": {}}
        except Exception as exc:
            detail = getattr(exc, "detail", None)
            if detail:
                return {"tool": name, "ok": False, "code": "tool_rejected",
                        "message": str(detail), "output": {}}
            logging.getLogger(__name__).exception("Agent tool failed: %s", name)
            return {"tool": name, "ok": False, "code": "tool_failed",
                    "message": f"工具 {name} 执行失败，尚未确认完成；详情已记录到诊断日志。", "output": {}}


class AutonomousAgentLoop:
    """A bounded plan → act → observe → reflect loop with loop and tool allow-list guards."""

    def __init__(self, planner, registry, max_cycles=3, max_tool_calls=6):
        self.planner = planner
        self.registry = registry
        self.max_cycles = max_cycles
        self.max_tool_calls = max_tool_calls
        settings = getattr(planner, "settings", None)
        self.fast_controls = getattr(settings, "AGENT_FAST_CONTROLS", True)
        self.skip_single_reflection = getattr(settings, "AGENT_SKIP_SINGLE_REFLECTION", True)

    @staticmethod
    def control_plan(context):
        # Exact standalone controls only: questions, negations and compound requests go to the planner.
        message = str(context.get("message") or "").strip().rstrip("。！!")
        if not context.get("focused_paper"):
            return None
        controls = {"暂停": "pause_task", "暂停任务": "pause_task", "暂停本次任务": "pause_task",
            "暂停本次写作任务": "pause_task", "取消任务": "cancel_task", "取消本次任务": "cancel_task",
            "确认大纲": "confirm_outline", "确认大纲并继续": "confirm_outline",
            "开始写作": "start_writing", "启动完整写作流程": "start_writing"}
        name = controls.get(message)
        if not name:
            return None
        return {"goal": message, "response_mode": "tool", "single_step": True,
                "tool_calls": [{"name": name, "arguments": {}, "purpose": message}],
                "decision_summary": "明确的当前任务控制指令，直接校验状态并执行。"}

    async def run(self, context, progress=None):
        capabilities = self.registry.manifest()
        payload = {**context, "capabilities": capabilities, "observations": []}
        started = perf_counter()
        plan = self.control_plan(context) if self.fast_controls else None
        fast_control = plan is not None
        if plan is None:
            plan = await self.planner.plan(payload)
        planning_ms = round((perf_counter() - started) * 1000, 2)
        trace = [{"stage": "plan", "summary": plan.get("decision_summary", ""),
                  "tools": [item.get("name") for item in plan.get("tool_calls", [])]}]
        observations = []
        reflection = None
        seen = set()
        calls = plan.get("tool_calls") or []

        for cycle in range(self.max_cycles):
            if not calls or len(observations) >= self.max_tool_calls:
                break
            for call in calls[:self.max_tool_calls - len(observations)]:
                signature = (str(call.get("name")), repr(sorted((call.get("arguments") or {}).items())))
                if signature in seen:
                    observations.append({"tool": call.get("name"), "ok": False,
                        "code": "repeated_call", "message": "Agent 已阻止重复执行同一个工具调用。", "output": {}})
                    continue
                seen.add(signature)
                if progress:
                    progress("tool", f"正在执行：{call.get('name', 'unknown')}")
                tool_start = perf_counter()
                observation = await self.registry.execute(call)
                observation["duration_ms"] = round((perf_counter() - tool_start) * 1000, 2)
                observations.append(observation)
                if not observation["ok"]:
                    break
            if self.skip_single_reflection and plan.get("single_step") and len(observations) == 1 and observations[0].get("ok"):
                reflection = {"goal_satisfied": True, "next_tool_calls": [],
                              "reflection_summary": "单步操作已获得工具执行回执，无需额外模型反思。"}
                trace.append({"stage": "verification", "summary": reflection["reflection_summary"]})
                break
            try:
                reflection = await self.planner.reflect({**context, "capabilities": capabilities,
                    "plan": plan, "observations": observations,
                    "remaining_tool_budget": self.max_tool_calls - len(observations)})
            except Exception:
                logging.getLogger(__name__).exception("Agent reflection failed")
                reflection = {"goal_satisfied": False, "requires_user_input": True,
                    "user_message": "后续评估失败；以上为已经取得的执行结果，未继续安排其他操作。",
                    "next_tool_calls": [], "reflection_summary": "评估失败，保留已有执行结果。"}
            trace.append({"stage": "reflect", "summary": reflection.get("reflection_summary", ""),
                          "goal_satisfied": reflection.get("goal_satisfied", False),
                          "next_tools": [item.get("name") for item in reflection.get("next_tool_calls", [])]})
            if reflection.get("goal_satisfied") or reflection.get("requires_user_input"):
                break
            calls = reflection.get("next_tool_calls") or []

        return {"plan": plan, "observations": observations, "reflection": reflection or {},
                "trace": trace, "capabilities": capabilities, "timings": {"planning_ms": planning_ms,
                "tool_ms": sum(o.get("duration_ms", 0) for o in observations), "fast_control": fast_control}}
