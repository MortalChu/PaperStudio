import re
from copy import deepcopy

from sqlalchemy import inspect, text


DEFAULT_AGENT_PREFERENCES = {
    "auto_review": False,
    "annotation_color": "#B45309",
    "collapse_quality_issues": True,
    "collapse_agent_trace": True,
    "writing_style": "",
    "persistent_instructions": "",
    "preference_memory": [],
}


def normalize_preferences(value=None):
    """Return a complete, safe preference object for API and UI use."""
    result = deepcopy(DEFAULT_AGENT_PREFERENCES)
    if isinstance(value, dict):
        for key in result:
            if key in value:
                result[key] = value[key]
    if not isinstance(result["auto_review"], bool):
        result["auto_review"] = False
    if not isinstance(result["collapse_quality_issues"], bool):
        result["collapse_quality_issues"] = True
    if not isinstance(result["collapse_agent_trace"], bool):
        result["collapse_agent_trace"] = True
    color = str(result.get("annotation_color") or "").upper()
    result["annotation_color"] = color if re.fullmatch(r"#[0-9A-F]{6}", color) else "#B45309"
    result["writing_style"] = str(result.get("writing_style") or "")[:1000]
    result["persistent_instructions"] = str(result.get("persistent_instructions") or "")[:3000]
    memory = result.get("preference_memory")
    if not isinstance(memory, list):
        memory = []
    result["preference_memory"] = list(dict.fromkeys(
        str(item).strip()[:1000] for item in memory if str(item).strip()))[-100:]
    return result


def memory_entries(value):
    """Legacy values get stable IDs without inventing historical timestamps."""
    import hashlib
    value = value or {}
    if isinstance(value.get("_entries"), list):
        return deepcopy(value["_entries"])
    entries = []
    for key in DEFAULT_AGENT_PREFERENCES:
        incoming = value.get(key)
        if incoming is None or incoming == DEFAULT_AGENT_PREFERENCES[key]:
            continue
        values = incoming if key == "preference_memory" and isinstance(incoming, list) else [incoming]
        for item in values:
            identity = hashlib.sha256((key + repr(item)).encode()).hexdigest()[:24]
            entries.append({"id": identity, "content": str(item), "source": "旧版偏好（时间未记录）",
                "created_at": None, "updated_at": None,
                "values": {key: [item] if key == "preference_memory" else item}})
    return entries


def preference_storage(entries):
    result = {"_entries": deepcopy(entries)}
    for entry in entries:
        for key, value in entry.get("values", {}).items():
            if key == "preference_memory":
                result[key] = list(dict.fromkeys([*result.get(key, []), *value]))
            elif key in DEFAULT_AGENT_PREFERENCES:
                result[key] = value
    return result


def merge_preferences(current, updates, source="用户设置"):
    from uuid import uuid4
    from datetime import datetime, timezone
    entries = memory_entries(current)
    changes = {k: v for k, v in (updates or {}).items() if k in DEFAULT_AGENT_PREFERENCES and v is not None}
    if not changes:
        return preference_storage(entries)
    checked = normalize_preferences(changes)
    changes = {k: checked[k] for k in changes}
    # Superseded explicit settings must not reappear when their replacement is forgotten.
    touched = set(changes) - {"preference_memory"}
    entries = [e for e in entries if not (set(e.get("values", {})) & touched)]
    instruction = "；".join(changes.get("preference_memory") or [])
    content = instruction or "；".join(f"{k}：{v}" for k, v in changes.items())
    entries = [e for e in entries if e.get("content") != content]
    now = datetime.now(timezone.utc).isoformat()
    entries.append({"id": uuid4().hex, "content": content, "values": changes,
                    "source": source, "created_at": now, "updated_at": now})
    return preference_storage(entries)


def effective_preferences(account, paper=None):
    result = normalize_preferences(account)
    overrides = preference_storage(memory_entries(paper)) if paper is not None else {}
    for key, value in overrides.items():
        if key == "preference_memory":
            result[key] = list(dict.fromkeys([*result.get(key, []), *value]))
        elif key in DEFAULT_AGENT_PREFERENCES:
            result[key] = value
    return {k: result[k] for k in DEFAULT_AGENT_PREFERENCES}


async def load_effective_preferences(db, paper):
    from app.models.user import User
    account = await db.get(User, paper.author_id)
    return effective_preferences(account.preferences if account else {}, paper.agent_preferences)


async def migrate_memory_entries(sessions):
    from sqlalchemy import select
    from app.models.user import User
    from app.models.paper import Paper
    async with sessions() as db:
        users = (await db.scalars(select(User))).all()
        for user in users:
            account_entries = memory_entries(user.preferences)
            user.preferences = preference_storage(account_entries)
            papers = (await db.scalars(select(Paper).where(Paper.author_id == user.id))).all()
            for paper in papers:
                raw = paper.agent_preferences or {}
                if "_entries" in raw:
                    continue
                # v7 copied account defaults into each paper. Identical legacy values become inherited.
                entries = memory_entries(raw)
                entries = [e for e in entries if not any(e["values"] == a["values"] for a in account_entries)]
                paper.agent_preferences = preference_storage(entries)
        await db.commit()


def migrate_agent_storage(connection):
    """Add preference columns for databases created by earlier releases."""
    inspector = inspect(connection)
    dialect = connection.dialect.name
    additions = (("users", "preferences"), ("papers", "agent_preferences"))
    for table, column in additions:
        columns = {item["name"] for item in inspector.get_columns(table)}
        if column in columns:
            continue
        if dialect == "postgresql":
            definition = "JSON NOT NULL DEFAULT '{}'::json"
        else:
            definition = "JSON NOT NULL DEFAULT '{}'"
        connection.execute(text(f"ALTER TABLE {table} ADD COLUMN {column} {definition}"))
