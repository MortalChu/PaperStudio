import asyncio
from contextvars import ContextVar
from time import perf_counter
from langchain_core.callbacks import BaseCallbackHandler

_turn = ContextVar("agent_turn_metrics", default=None)


def begin_turn():
    data = {"started": perf_counter(), "owner": asyncio.current_task(), "calls": 0,
            "input_tokens": 0, "output_tokens": 0, "usage_known": True, "errors": 0,
            "first_content_ms": None, "first_tool_ms": None, "llm_ms": 0}
    _turn.set(data)
    return data


class UsageCallback(BaseCallbackHandler):
    def __init__(self, data):
        self.data = data
        self.starts = {}

    def on_chat_model_start(self, serialized, messages, *, run_id, **kwargs):
        self.data["calls"] += 1
        self.starts[run_id] = perf_counter()

    def on_llm_start(self, serialized, prompts, *, run_id, **kwargs):
        self.on_chat_model_start(serialized, prompts, run_id=run_id)

    def on_llm_end(self, response, *, run_id, **kwargs):
        self.data["llm_ms"] += (perf_counter() - self.starts.pop(run_id, perf_counter())) * 1000
        usage = None
        for group in response.generations:
            for generation in group:
                usage = getattr(getattr(generation, "message", None), "usage_metadata", None) or usage
        if not usage:
            usage = (response.llm_output or {}).get("token_usage")
        if usage and ("input_tokens" in usage or "prompt_tokens" in usage):
            self.data["input_tokens"] += usage.get("input_tokens", usage.get("prompt_tokens", 0))
            self.data["output_tokens"] += usage.get("output_tokens", usage.get("completion_tokens", 0))
        else:
            self.data["usage_known"] = False

    def on_llm_error(self, error, *, run_id, **kwargs):
        self.data["errors"] += 1
        self.data["usage_known"] = False
        self.data["llm_ms"] += (perf_counter() - self.starts.pop(run_id, perf_counter())) * 1000


def call_config():
    data = _turn.get()
    # A spawned writing workflow is a different job, not part of the console's token usage.
    if not data or data["owner"] is not asyncio.current_task():
        return {}
    return {"callbacks": [UsageCallback(data)]}


def mark(data, field):
    if data[field] is None:
        data[field] = round((perf_counter() - data["started"]) * 1000, 2)


def record_turn(request, data, state, result=None):
    recorder = request.app.state.metrics
    if not recorder:
        return
    known = data["usage_known"]
    recorder.record("agent_latency", turn_id=state["id"], user_id=state["user_id"],
        paper_id=state.get("paper_id"), status=state["status"],
        total_ms=round((perf_counter() - data["started"]) * 1000, 2),
        first_content_ms=data["first_content_ms"], first_tool_ms=data["first_tool_ms"],
        model_calls=data["calls"], model_error_count=data["errors"],
        llm_ms=round(data["llm_ms"], 2), token_usage_available=known,
        input_tokens=data["input_tokens"] if known else "unknown",
        output_tokens=data["output_tokens"] if known else "unknown",
        **((result or {}).get("timings") or {}))
