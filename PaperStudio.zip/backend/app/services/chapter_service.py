from fastapi import HTTPException
from app.models.chapter import Chapter
from app.services.paper_service import owned_paper


async def owned_chapter(db, chapter_id, user_id):
    chapter = await db.get(Chapter, chapter_id)
    if chapter is None:
        raise HTTPException(404, "章节不存在")
    paper = await owned_paper(db, chapter.paper_id, user_id)
    return chapter, paper


def writing_input(chapter, paper):
    return {"title": paper.title, "outline": paper.outline, "section_title": chapter.title,
            "outline_points": chapter.points, "word_count": chapter.word_count,
            "requirements": paper.requirements,
            "references": (paper.quality_report or {}).get("references", [])}
