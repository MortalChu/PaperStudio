from datetime import timezone
from zoneinfo import ZoneInfo

from sqlalchemy import select

from app.models.paper import AgentMessage, Paper
from app.services.agent_runtime import ToolRegistry, ToolSpec
from app.services.agent_service import merge_preferences, normalize_preferences, effective_preferences, load_effective_preferences
from app.services.paper_service import refresh_references


def _object(properties, required=None):
    return {"type": "object", "properties": properties, "required": required or [],
            "additionalProperties": False}


def _string(description):
    return {"type": "string", "description": description}


class GlobalAgentTools:
    """Account-level tools. Every successful result is backed by a completed state change or read."""

    def __init__(self, request, session, user):
        self.request = request
        self.session = session
        self.user = user
        self.user_id = user.id
        self.current_message = ""

    async def papers(self, deleted=None):
        query = select(Paper).where(Paper.author_id == self.user_id)
        if deleted is True:
            query = query.where(Paper.deleted_at.is_not(None)).order_by(Paper.deleted_at.desc())
        elif deleted is False:
            query = query.where(Paper.deleted_at.is_(None)).order_by(Paper.updated_at.desc())
        return (await self.session.scalars(query)).all()

    async def resolve(self, arguments, deleted=False):
        records = await self.papers(deleted)
        paper_id = arguments.get("paper_id")
        if paper_id is not None:
            matches = [item for item in records if item.id == int(paper_id)]
        else:
            title = str(arguments.get("title") or "").strip()
            exact = [item for item in records if item.title.strip().lower() == title.lower()]
            matches = exact or [item for item in records if title and title.lower() in item.title.lower()]
        if not matches:
            location = "回收站" if deleted else "论文列表"
            raise LookupError(f"没有在当前账号的{location}中找到对应论文。")
        if len(matches) != 1:
            names = "、".join(f"《{item.title}》" for item in matches[:5])
            raise ValueError(f"匹配到多篇论文：{names}。请提供完整标题或任务编号。")
        return matches[0]

    @staticmethod
    def status_label(status):
        return {"draft": "草稿", "outline": "大纲阶段", "writing": "撰写中",
                "review": "初稿待人工核对", "completed": "已人工核对"}.get(status, status)

    @staticmethod
    def local_time(value):
        if not value:
            return "尚未结束"
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%d %H:%M")

    def summary(self, item):
        return {"id": item.id, "title": item.title, "status": self.status_label(item.status),
                "created_at": self.local_time(item.created_at),
                "finished_at": self.local_time(item.finished_at),
                "deleted": item.deleted_at is not None, "active_run_id": item.active_run_id}

    async def focused_state(self, item):
        state = self.summary(item)
        if item.active_run_id:
            run = await self.request.app.state.workflow.status(item.active_run_id)
            state["run_status"] = run["status"]
            state["waiting_for"] = [r.get("kind") for r in run.get("requests", [])]
        return state

    async def list_papers(self, arguments):
        active = await self.papers(False)
        recycled = await self.papers(True) if arguments.get("include_trash") else []
        output = [self.summary(item) for item in active]
        recycled_output = [self.summary(item) for item in recycled]
        lines = [f"- #{item['id']} 《{item['title']}》（{item['status']}）" for item in output]
        message = "当前账号的论文任务：\n" + ("\n".join(lines) or "- 暂无论文任务")
        if arguments.get("include_trash"):
            message += f"\n回收站中有 {len(recycled_output)} 篇论文。"
        return {"message": message, "papers": output, "trash": recycled_output,
                "operation": "list_papers"}

    async def get_paper(self, arguments):
        try:
            item = await self.resolve(arguments, False)
        except LookupError:
            item = await self.resolve(arguments, True)
        data = self.summary(item)
        return {"message": (f"《{item.title}》创建于 {data['created_at']}；当前状态为{data['status']}；"
                            f"任务结束时间：{data['finished_at']}。"),
                "paper": data, "operation": "get_paper"}

    async def open_paper(self, arguments):
        item = await self.resolve(arguments, False)
        return {"message": f"已打开《{item.title}》。", "paper_id": item.id,
                "navigate": True, "operation": "open_paper"}

    async def create_paper(self, arguments):
        title = str(arguments.get("title") or "").strip()
        if len(title) < 5:
            raise ValueError("论文题目至少需要 5 个字符。")
        word_limit = int(arguments.get("word_limit") or 5000)
        if not 1000 <= word_limit <= 30000:
            raise ValueError("目标字数必须在 1000 到 30000 之间。")
        preferences = {}
        preferences["auto_review"] = False
        item = Paper(title=title, topic=str(arguments.get("topic") or "")[:200],
                     word_limit=word_limit, author_id=self.user_id,
                     agent_preferences=preferences)
        self.session.add(item)
        await self.session.commit()
        await self.session.refresh(item)
        return {"message": f"已创建论文任务《{title}》。", "paper_id": item.id,
                "navigate": True, "operation": "create_paper"}

    async def move_paper_to_trash(self, arguments):
        try:
            item = await self.resolve(arguments, False)
        except LookupError:
            item = await self.resolve(arguments, True)
        from app.services.task_control import stop_and_trash
        result = await stop_and_trash(self.request, item.id, self.user_id)
        await self.session.refresh(item)
        return result


    async def restore_paper(self, arguments):
        item = await self.resolve(arguments, True)
        item.deleted_at = None
        item.purge_after = None
        item.status = item.deleted_from_status or (
            "review" if item.final_paper else "outline" if item.outline else "draft")
        item.deleted_from_status = ""
        item.active_run_id = None
        await self.session.commit()
        return {"message": f"《{item.title}》已从回收站恢复。", "paper_id": item.id,
                "operation": "restore_paper"}

    async def purge_paper(self, arguments):
        item = await self.resolve(arguments, True)
        paper_id, title = item.id, item.title
        await self.session.delete(item)
        await self.session.commit()
        return {"message": f"《{title}》已从回收站永久删除。", "paper_id": paper_id,
                "operation": "purge_paper"}

    async def empty_trash(self, arguments):
        records = await self.papers(True)
        for item in records:
            await self.session.delete(item)
        await self.session.commit()
        count = len(records)
        return {"message": (f"回收站已清空，永久删除 {count} 篇论文。"
                            if count else "回收站原本就是空的。"),
                "deleted_count": count, "operation": "empty_trash"}

    async def trash_status(self, arguments):
        records = await self.papers(True)
        return {"message": ("回收站为空。" if not records else f"回收站中目前有 {len(records)} 篇论文。"),
                "count": len(records), "operation": "trash_status"}

    async def _start(self, arguments, outline_only=False):
        item = await self.resolve(arguments, False)
        if item.active_run_id:
            status = await self.request.app.state.workflow.status(item.active_run_id)
            return {"message": f"《{item.title}》已有状态为 {status['status']} 的任务，没有重复启动。",
                    "paper_id": item.id, "run_id": item.active_run_id,
                    "operation": "generate_outline" if outline_only else "start_writing"}
        async with self.request.app.state.edit_lock:
            run_id = await self.request.app.state.workflow.start(item.id, self.user_id, {
                "is_topic_clear": True, "review_outline": True, "max_revisions": 1,
                "citation_style": (item.quality_report or {}).get("citation_style", "gbt")})
        return {"message": (f"《{item.title}》的大纲生成任务已启动，将在大纲确认点等待。" if outline_only
                            else f"《{item.title}》的完整写作任务已启动。"),
                "paper_id": item.id, "run_id": run_id,
                "operation": "generate_outline" if outline_only else "start_writing"}

    async def generate_outline(self, arguments):
        return await self._start(arguments, True)

    async def start_writing(self, arguments):
        return await self._start(arguments, False)

    async def pause_task(self, arguments):
        item = await self.resolve(arguments, False)
        if not item.active_run_id:
            return {"message": f"《{item.title}》当前没有可暂停的任务。", "paper_id": item.id,
                    "operation": "pause_task"}
        paused = await self.request.app.state.workflow.pause(item.active_run_id)
        status = await self.request.app.state.workflow.status(item.active_run_id)
        return {"message": (f"《{item.title}》已暂停。" if paused else
                            f"《{item.title}》任务已结束，无需暂停。"),
                "paper_id": item.id, "run_id": item.active_run_id,
                "run_status": status["status"], "operation": "pause_task"}

    async def confirm_outline(self, arguments):
        item = await self.resolve(arguments, False)
        if not item.active_run_id:
            raise ValueError("当前没有等待确认的大纲任务。")
        status = await self.request.app.state.workflow.status(item.active_run_id)
        if not any(r.get("kind") == "outline" for r in status.get("requests", [])):
            raise ValueError("当前任务不在大纲确认阶段；没有重复确认或启动任务。")
        async with self.request.app.state.edit_lock:
            await self.session.refresh(item)
            if item.deleted_at:
                raise ValueError("论文已删除，不能继续任务。")
            await self.request.app.state.workflow.resume(item.active_run_id,
                                                         {"outline": item.outline, "approved": True})
        return {"message": f"《{item.title}》的大纲已确认，正在继续写作。",
                "paper_id": item.id, "run_id": item.active_run_id, "operation": "resume_task"}

    async def resume_task(self, arguments):
        item = await self.resolve(arguments, False)
        if not item.active_run_id:
            raise ValueError(f"《{item.title}》当前没有可继续的任务。")
        status = await self.request.app.state.workflow.status(item.active_run_id)
        if status["status"] == "running":
            return {"message": "任务已经在运行，没有重复启动。", "paper_id": item.id,
                    "run_id": item.active_run_id, "operation": "resume_task"}
        if any(r.get("kind") == "outline" for r in status.get("requests", [])):
            raise ValueError("请先编辑并保存大纲，然后明确确认大纲。")
        async with self.request.app.state.edit_lock:
            await self.session.refresh(item)
            if item.deleted_at:
                raise ValueError("论文已删除，不能继续任务。")
            await self.request.app.state.workflow.resume(item.active_run_id, {})
        return {"message": f"《{item.title}》已从检查点继续执行。", "paper_id": item.id,
                "run_id": item.active_run_id, "operation": "resume_task"}

    async def cancel_task(self, arguments):
        item = await self.resolve(arguments, False)
        if not item.active_run_id:
            return {"message": f"《{item.title}》当前没有需要取消的任务。", "paper_id": item.id,
                    "operation": "cancel_task"}
        run_id = item.active_run_id
        await self.request.app.state.workflow.cancel(run_id)
        return {"message": f"《{item.title}》的本次生成任务已取消。", "paper_id": item.id,
                "run_id": run_id, "operation": "cancel_task"}

    async def retrieve_references(self, arguments):
        item = await self.resolve(arguments, False)
        references = await refresh_references(
            self.session, item, self.request.app.state.retriever, strict=True)
        await self.session.commit()
        return {"message": f"已为《{item.title}》完成检索并关联 {len(references)} 篇文献。",
                "paper_id": item.id, "reference_count": len(references),
                "operation": "retrieve_references"}

    async def update_paper(self, arguments):
        item = await self.resolve(arguments, False)
        if item.active_run_id:
            raise ValueError(f"《{item.title}》有未结束任务，请先暂停并取消本次任务后再修改基本信息。")
        changed = {}
        mapping = {"new_title": "title", "topic": "topic", "keywords": "keywords",
                   "requirements": "requirements", "word_limit": "word_limit"}
        for source, target in mapping.items():
            value = arguments.get(source)
            if value is None or value == "":
                continue
            if target == "word_limit":
                value = int(value)
                if not 1000 <= value <= 30000:
                    raise ValueError("目标字数必须在 1000 到 30000 之间。")
            changed[target] = value
        if not changed:
            raise ValueError("没有提供需要修改的论文信息。")
        from app.api.papers import edit as edit_paper, update_word_limit
        from app.schemas.paper import PaperUpdate, WordLimitUpdate
        ordinary = {key: value for key, value in changed.items() if key != "word_limit"}
        if ordinary:
            await edit_paper(item.id, PaperUpdate(**ordinary), self.request, self.session, self.user)
        if changed.get("word_limit") is not None:
            await update_word_limit(item.id, WordLimitUpdate(word_limit=changed["word_limit"]),
                                    self.request, self.session, self.user)
        return {"message": "论文信息已更新：" + "、".join(f"{key}={value}" for key, value in changed.items()) + "。",
                "paper_id": item.id, "changed": changed, "operation": "update_paper"}

    async def _request_content_action(self, arguments, operation):
        item = await self.resolve(arguments, False)
        instruction = str(arguments.get("instruction") or "").strip()
        if not instruction:
            raise ValueError("请说明希望如何修改或核对论文。")
        if operation == "revise" and not (item.final_paper or item.chapters):
            raise ValueError(f"《{item.title}》尚无可修改正文，请先生成正文。")
        if operation == "review" and not item.final_paper:
            raise ValueError(f"《{item.title}》尚无完整初稿，当前无法核对全文。")
        targets = arguments.get("target_sections") or []
        command = AgentMessage(paper_id=item.id, user_id=self.user_id, role="user",
            content=instruction, status="pending", action=operation,
            details={"plan": {"operation": operation, "instruction": instruction,
                "target_sections": targets, "retrieval_query": arguments.get("retrieval_query", "")}})
        self.session.add(command)
        await self.session.commit()
        if item.active_run_id:
            await self.request.app.state.workflow.steer(item.active_run_id)
            run_id = item.active_run_id
        else:
            run_id = await self.request.app.state.workflow.start_agent_run(item.id, self.user_id)
        label = "定向修改" if operation == "revise" else "按需核对"
        return {"message": f"《{item.title}》的{label}任务已启动。",
                "paper_id": item.id, "run_id": run_id, "operation": f"{operation}_paper"}

    async def revise_paper(self, arguments):
        return await self._request_content_action(arguments, "revise")

    async def review_paper(self, arguments):
        return await self._request_content_action(arguments, "review")

    async def set_preferences(self, arguments):
        instruction = str(arguments.get("instruction") or "").strip()
        if not instruction:
            raise ValueError("请给出需要记住的具体偏好。")
        if self.current_message and instruction not in self.current_message:
            raise ValueError("记忆必须引用本轮用户的明确要求，不能从历史对话重新保存。")
        updates = {"preference_memory": [instruction]}
        for key in ("auto_review", "annotation_color", "collapse_quality_issues",
                    "collapse_agent_trace", "writing_style", "persistent_instructions"):
            if arguments.get(key) is not None:
                updates[key] = arguments[key]
        scope = arguments.get("scope") or ("paper" if arguments.get("paper_id") else "account")
        if scope == "paper":
            item = await self.resolve(arguments, False)
            item.agent_preferences = merge_preferences(item.agent_preferences, updates, source="论文对话")
            scope_label = f"论文《{item.title}》"
        else:
            self.user.preferences = merge_preferences(self.user.preferences, updates, source="账号对话")
            scope_label = "当前账号"
        await self.session.commit()
        return {"message": f"该要求已保存为{scope_label}的偏好。",
                "saved": updates, "scope": scope, "operation": "set_preferences"}

    async def reindex_references(self, arguments):
        from app.api.references import reindex_all
        result = await reindex_all(self.request, self.user)
        return {**result, "operation": "reindex_references"}

    def registry(self):
        target = {"title": _string("论文完整标题"), "paper_id": {"type": "integer", "description": "论文编号"}}
        target_schema = _object(target)
        registry = ToolRegistry()
        specs = [
            ToolSpec("list_papers", "读取当前账号的论文及真实状态。", _object({
                "include_trash": {"type": "boolean", "description": "是否同时统计回收站"}}), self.list_papers),
            ToolSpec("get_paper", "读取指定论文的状态、创建时间、结束时间。", target_schema, self.get_paper),
            ToolSpec("open_paper", "在界面中打开指定未删除论文。", target_schema, self.open_paper),
            ToolSpec("create_paper", "创建论文任务并返回任务编号。", _object({
                "title": _string("论文题目，至少5字"), "topic": _string("研究方向"),
                "word_limit": {"type": "integer", "minimum": 1000, "maximum": 30000}}, ["title"]), self.create_paper),
            ToolSpec("move_paper_to_trash", "停止任务并把指定论文移入回收站。", target_schema,
                     self.move_paper_to_trash, True),
            ToolSpec("restore_paper", "从回收站恢复指定论文。", target_schema, self.restore_paper),
            ToolSpec("purge_paper", "永久删除回收站中的指定论文。", target_schema, self.purge_paper, True),
            ToolSpec("empty_trash", "永久删除当前账号回收站中的全部论文。", _object({}), self.empty_trash, True),
            ToolSpec("trash_status", "读取回收站数量，不执行删除。", _object({}), self.trash_status),
            ToolSpec("generate_outline", "启动指定论文的大纲生成，并在确认点等待。", target_schema, self.generate_outline),
            ToolSpec("start_writing", "启动指定论文完整写作任务。", target_schema, self.start_writing),
            ToolSpec("pause_task", "暂停指定论文当前运行任务并读取暂停结果。", target_schema, self.pause_task),
            ToolSpec("confirm_outline", "确认已保存的大纲并继续等待中的任务。", target_schema, self.confirm_outline),
            ToolSpec("resume_task", "从指定论文检查点继续任务。", target_schema, self.resume_task),
            ToolSpec("cancel_task", "取消指定论文当前生成任务。", target_schema, self.cancel_task, True),
            ToolSpec("retrieve_references", "为指定论文执行共享文献检索并返回关联数量。",
                     _object({**target, "query": _string("可选检索重点")}), self.retrieve_references),
            ToolSpec("update_paper", "修改指定论文的题目、方向、关键词、要求或目标字数。", _object({
                **target, "new_title": _string("修改后的论文题目"), "topic": _string("研究方向"),
                "keywords": _string("关键词"), "requirements": _string("写作要求"),
                "word_limit": {"type": "integer", "minimum": 1000, "maximum": 30000}}), self.update_paper),
            ToolSpec("revise_paper", "按用户指令定向修改指定论文已有正文。", _object({
                **target, "instruction": _string("具体修改要求"),
                "target_sections": {"type": "array", "items": {"type": "string"}}}, ["instruction"]), self.revise_paper),
            ToolSpec("review_paper", "按用户要求核对指定论文的结构、引用与证据。", _object({
                **target, "instruction": _string("具体核对要求"),
                "target_sections": {"type": "array", "items": {"type": "string"}},
                "retrieval_query": _string("发现证据缺口时的检索重点")}, ["instruction"]), self.review_paper),
            ToolSpec("set_preferences", "保存当前论文偏好或账号长期写作偏好。", _object({
                **target,
                "instruction": _string("必须逐字引用本轮用户希望记住的要求，不得从历史消息复制"),
                "scope": {"type": "string", "enum": ["paper", "account"]},
                "auto_review": {"type": "boolean", "description": "是否自动核对"},
                "annotation_color": _string("标注颜色，#RRGGBB"),
                "collapse_quality_issues": {"type": "boolean"},
                "collapse_agent_trace": {"type": "boolean"},
                "writing_style": _string("写作风格"),
                "persistent_instructions": _string("长期写作要求")}, ["instruction"]),
                self.set_preferences),
            ToolSpec("reindex_references", "重试共享文献库中的失败或待建索引。", _object({}), self.reindex_references),
        ]
        for spec in specs:
            registry.register(spec)
        return registry
