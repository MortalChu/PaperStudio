from copy import deepcopy
from fastapi import HTTPException
from sqlalchemy import select, delete
from app.models.paper import (Paper, PaperVersion, PaperRun,
                              GlobalAgentSession, GlobalAgentMessage)
from app.models.chapter import Chapter
from app.models.reference import Reference, LegacyReferenceLink, LibraryMigration
from app.schemas.chapter import ChapterResponse
from app.schemas.paper import ReferenceResponse
from app.utils.helpers import assemble_paper, flatten_outline

PAPER_FIELDS = ("title", "topic", "keywords", "abstract", "paper_type", "word_limit", "requirements", "outline",
                "status", "final_paper", "quality_report")


def migrate_human_review_status(connection):
    """One-time conversion: legacy automatic completion was not a human review."""
    marker = "paper_human_review_v1"
    exists = connection.execute(select(LibraryMigration.name).where(LibraryMigration.name == marker)).scalar()
    if exists:
        return
    connection.execute(Paper.__table__.update().where(Paper.status == "completed").values(status="review"))
    connection.execute(LibraryMigration.__table__.insert().values(name=marker))


def migrate_paper_console(connection):
    """Add recycle-bin and optimistic outline fields without resetting existing data."""
    from sqlalchemy import inspect, text
    columns = {item["name"] for item in inspect(connection).get_columns("papers")}
    dialect = connection.dialect.name
    definitions = {
        "outline_revision": "INTEGER NOT NULL DEFAULT 0",
        "deleted_at": "TIMESTAMP NULL" if dialect == "postgresql" else "DATETIME NULL",
        "deleted_from_status": "VARCHAR(20) NOT NULL DEFAULT ''",
        "purge_after": "TIMESTAMP NULL" if dialect == "postgresql" else "DATETIME NULL",
        "finished_at": "TIMESTAMP NULL" if dialect == "postgresql" else "DATETIME NULL",
    }
    for name, definition in definitions.items():
        if name not in columns:
            connection.execute(text(f"ALTER TABLE papers ADD COLUMN {name} {definition}"))
    # Older completed drafts have no dedicated end timestamp. Their last persisted
    # update is the closest recoverable value and is marked as such in the patch notes.
    if {"status", "updated_at"} <= columns:
        connection.execute(text(
            "UPDATE papers SET finished_at = updated_at "
            "WHERE finished_at IS NULL AND status IN ('review', 'completed')"))


def migrate_global_agent_sessions(connection):
    """Attach legacy account messages to one history session per user."""
    from sqlalchemy import func, inspect, text
    inspector = inspect(connection)
    if "global_agent_messages" not in inspector.get_table_names():
        return
    columns = {item["name"] for item in inspector.get_columns("global_agent_messages")}
    if "session_id" not in columns:
        connection.execute(text("ALTER TABLE global_agent_messages ADD COLUMN session_id INTEGER NULL"))
    connection.execute(text(
        "CREATE INDEX IF NOT EXISTS ix_global_agent_messages_session_id "
        "ON global_agent_messages (session_id)"))
    groups = connection.execute(select(
        GlobalAgentMessage.user_id,
        func.min(GlobalAgentMessage.created_at),
        func.max(GlobalAgentMessage.created_at),
    ).where(GlobalAgentMessage.session_id.is_(None)).group_by(GlobalAgentMessage.user_id)).all()
    for user_id, created_at, updated_at in groups:
        first_text = connection.execute(select(GlobalAgentMessage.content).where(
            GlobalAgentMessage.user_id == user_id,
            GlobalAgentMessage.session_id.is_(None),
            GlobalAgentMessage.role == "user",
        ).order_by(GlobalAgentMessage.id).limit(1)).scalar() or "旧版对话"
        title = ("旧版会话 · " + first_text.replace("\n", " ").strip())[:200]
        result = connection.execute(GlobalAgentSession.__table__.insert().values(
            user_id=user_id, title=title, created_at=created_at, updated_at=updated_at))
        session_id = result.inserted_primary_key[0]
        connection.execute(GlobalAgentMessage.__table__.update().where(
            GlobalAgentMessage.user_id == user_id,
            GlobalAgentMessage.session_id.is_(None)).values(session_id=session_id))


def rescale_outline_word_counts(outline, target):
    """Return a copy whose flattened section budgets follow the new paper target."""
    if not outline:
        return outline
    result = deepcopy(outline)
    sections = flatten_outline(result)
    if not sections:
        return result
    minimum, maximum = 100, 10000
    feasible = min(max(target, len(sections) * minimum), len(sections) * maximum)
    weights = [max(int(section.get("word_count", minimum)), 1) for section in sections]
    total_weight = sum(weights)
    counts = [min(max(round(feasible * weight / total_weight), minimum), maximum) for weight in weights]
    delta = feasible - sum(counts)
    while delta:
        candidates = [index for index, count in enumerate(counts)
                      if (delta > 0 and count < maximum) or (delta < 0 and count > minimum)]
        if not candidates:
            break
        change = 1 if delta > 0 else -1
        step = max(1, abs(delta) // len(candidates))
        for index in candidates:
            amount = min(step, maximum - counts[index]) if change > 0 else min(step, counts[index] - minimum)
            amount = min(amount, abs(delta))
            counts[index] += change * amount
            delta -= change * amount
            if not delta:
                break
    for section, count in zip(sections, counts):
        # flatten_outline 返回的是浅复制，需要按结构路径写回真正的嵌套字典。
        node = result["sections"]
        current = None
        for part in section["key"].split("."):
            current = node[int(part) - 1]
            node = current.get("subsections", [])
        current["word_count"] = count
    return result


async def owned_paper(db, paper_id, user_id):
    paper = await db.scalar(select(Paper).where(
        Paper.id == paper_id, Paper.author_id == user_id, Paper.deleted_at.is_(None)))
    if paper is None:
        raise HTTPException(404, "论文不存在")
    return paper


async def owned_paper_including_deleted(db, paper_id, user_id):
    paper = await db.scalar(select(Paper).where(Paper.id == paper_id, Paper.author_id == user_id))
    if paper is None:
        raise HTTPException(404, "论文不存在")
    return paper


async def ensure_outline_editable(db, paper):
    """An active id alone does not lock the outline; only a running worker does."""
    if not paper.active_run_id:
        return None
    run = await db.get(PaperRun, paper.active_run_id)
    if run and run.status in ("running", "pausing"):
        raise HTTPException(409, "当前写作任务正在运行，请先在 Agent 对话中暂停任务，再编辑大纲")
    return run


def ensure_editable(paper):
    if paper.active_run_id:
        raise HTTPException(409, "论文有未结束的生成任务，请先完成或取消任务")


async def attach_references(db, paper, references):
    """记录使用关系；保留历史关联，避免历史稿件的来源被删除。"""
    ids = {int(r["id"]) for r in references if r.get("id")}
    if not ids:
        return
    links = (await db.scalars(select(LegacyReferenceLink).where(LegacyReferenceLink.legacy_id.in_(ids)))).all()
    mapping = {link.legacy_id: link.reference_id for link in links}
    ids = {mapping.get(reference_id, reference_id) for reference_id in ids}
    await db.refresh(paper, ["references"])
    existing = {r.id for r in paper.references}
    for reference in (await db.scalars(select(Reference).where(Reference.id.in_(ids - existing)))).all():
        paper.references.append(reference)
    await db.flush()


async def refresh_references(db, paper, retriever, strict=False):
    from app.agents.reference_agent import ReferenceAgent
    try:
        result = await ReferenceAgent(retriever).execute({"query": " ".join(
            [paper.title, paper.topic, paper.keywords]), "top_k": 20,
            "format": (paper.quality_report or {}).get("citation_style", "gbt")})
        references = result["references"]
        retrieval = {"status": "matched" if references else "empty", "count": len(references),
            "references": references, "message": f"已从共享库检索到 {len(references)} 篇文献" if references else
            "共享库暂无符合检索条件的文献。请先入库相关资料，等待索引完成，再重新检索。"}
    except Exception:
        if strict:
            raise
        references = []
        retrieval = {"status": "error", "count": 0, "references": [],
            "message": "任务已创建，但自动检索失败。请检查向量模型配置及索引状态后重新检索。"}
    await attach_references(db, paper, references)
    report = {**(paper.quality_report or {}), "retrieval": retrieval}
    # 已生成稿件的引用编号是快照，不能被后来检索结果替换。
    if not paper.final_paper:
        report["references"] = references
    paper.quality_report = report
    if strict and not references:
        raise ValueError(retrieval["message"])
    return references


async def save_version(db, paper, label):
    chapters = (await db.scalars(select(Chapter).where(Chapter.paper_id == paper.id)
                 .order_by(Chapter.order_index))).all()
    snapshot = {"paper": {key: deepcopy(getattr(paper, key)) for key in PAPER_FIELDS},
                "chapters": [ChapterResponse.model_validate(c).model_dump() for c in chapters],
                "references": [ReferenceResponse.model_validate(r).model_dump() for r in paper.references]}
    version = PaperVersion(paper_id=paper.id, label=label, snapshot=snapshot)
    db.add(version)
    await db.flush()
    return version


async def sync_outline(db, paper, outline, contents=None):
    """Reconcile by structural path, preserving unchanged chapter IDs and content."""
    existing = (await db.scalars(select(Chapter).where(Chapter.paper_id == paper.id))).all()
    old = {c.section_key: c for c in existing}
    nodes = flatten_outline(outline)
    incoming_titles = {s["title"] for s in nodes}
    used_ids = set()
    assigned = {}
    for index, section in enumerate(nodes):
        chapter = old.get(section["key"])
        if chapter and (chapter.id in used_ids or chapter.title != section["title"]):
            chapter = None
        if chapter is None:
            matches = [c for c in existing if c.title == section["title"] and c.id not in used_ids]
            if len(matches) == 1:
                chapter = matches[0]
            else:
                previous = old.get(section["key"])
                if previous and previous.id not in used_ids and previous.title not in incoming_titles:
                    chapter = previous
        if chapter is None:
            chapter = Chapter(paper_id=paper.id, section_key=section["key"])
            db.add(chapter)
        chapter.section_key = section["key"]
        chapter.title = section["title"]
        chapter.order_index = index
        chapter.points = section["points"]
        chapter.word_count = section["word_count"]
        chapter.parent_id = assigned.get(section["parent_key"])
        if contents is not None:
            chapter.content = contents.get(section["key"], "")
        await db.flush()
        assigned[section["key"]] = chapter.id
        used_ids.add(chapter.id)
    # Reparent surviving chapters before deleting obsolete parents.
    for chapter in sorted(existing, key=lambda c: c.section_key.count("."), reverse=True):
        if chapter.id not in used_ids:
            await db.delete(chapter)
    paper.outline = outline
    await db.flush()
    await db.refresh(paper, ["chapters"])


async def rebuild_paper(db, paper):
    await db.flush()
    await db.refresh(paper, ["chapters", "references"])
    # Manual chapter edits must also update the next generation's outline.
    nodes = {c.id: {"title": c.title, "points": c.points, "word_count": c.word_count,
                     "subsections": []} for c in paper.chapters}
    roots = []
    for chapter in paper.chapters:
        if chapter.parent_id in nodes:
            nodes[chapter.parent_id]["subsections"].append(nodes[chapter.id])
        else:
            roots.append(nodes[chapter.id])
        if chapter.title.strip() == "摘要":
            paper.abstract = chapter.content
    paper.outline = {"title": paper.title, "sections": roots} if roots else None
    report = {key: value for key, value in (paper.quality_report or {}).items()
              if key not in ("human_reviewed", "human_reviewed_at")}
    refs = report.get("references")
    if refs is None:
        refs = [ReferenceResponse.model_validate(r).model_dump() for r in paper.references]
    paper.final_paper = assemble_paper(paper.title,
        [ChapterResponse.model_validate(c).model_dump() for c in paper.chapters], refs,
        report.get("citation_style", "gbt"))
    # An old automatic report must not certify subsequently edited content.
    paper.quality_report = {**report, "passed": False, "warnings": ["内容已手动修改，需要重新核对"], "issues": []}
    paper.status = "review"


async def restore_version(db, paper, version):
    await save_version(db, paper, f"回滚前自动备份（目标版本 {version.id}）")
    for key, value in version.snapshot["paper"].items():
        setattr(paper, key, deepcopy(value))
    paper.outline_revision += 1
    await db.execute(delete(Chapter).where(Chapter.paper_id == paper.id))
    await db.flush()
    remapped = {}
    for saved in version.snapshot["chapters"]:
        values = {k: v for k, v in saved.items() if k not in ("id", "parent_id", "paper_id")}
        chapter = Chapter(**values, paper_id=paper.id, parent_id=remapped.get(saved["parent_id"]))
        db.add(chapter)
        await db.flush()
        remapped[saved["id"]] = chapter.id
    await db.refresh(paper, ["chapters"])
    # Bibliography used in the historical draft lives inside final_paper/quality_report.
    # Current uploaded source library is deliberately independent of manuscript versions.
    await db.commit()
    return paper
