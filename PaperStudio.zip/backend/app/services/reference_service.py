import asyncio
import hashlib
import logging
import re
import traceback
import time
import unicodedata
from contextlib import nullcontext
from io import BytesIO
from pathlib import Path
from uuid import uuid4
from fastapi import HTTPException
from pypdf import PdfReader
from sqlalchemy import select, inspect, MetaData, Table, or_, func, text, update
from app.models.reference import Reference, ReferenceJob, LibraryMigration, LegacyReferenceLink, paper_references
from app.schemas.paper import ReferenceResponse, ReferenceMetadata, MetadataExtraction

METADATA_FIELDS = tuple(ReferenceMetadata.model_fields)


def migrate_index_diagnostics(connection):
    columns = {c["name"] for c in inspect(connection).get_columns("library_references")}
    if "index_error" not in columns:
        connection.execute(text("ALTER TABLE library_references ADD COLUMN index_error JSON NOT NULL DEFAULT '{}'"))


def reference_response(reference, store):
    data = ReferenceResponse.model_validate(reference)
    if reference.index_key != store.index_key:
        data.index_status = "pending"
        data.index_error = {}
    return data


def index_message(reference):
    if reference.index_status == "indexed":
        return "索引已完成，文献已进入可检索知识库，可用于写作"
    if reference.index_status == "failed":
        reason = (reference.index_error or {}).get("message", "旧版未记录具体原因，请重试以获取诊断信息")
        return "索引失败，资料已保留在待处理区，暂不能检索或用于写作。原因：" + reason
    return "资料已保留在待处理区，等待索引完成后才能用于检索和写作"


def index_diagnostic(exc, settings, stage):
    """仅返回固定诊断文案，不把供应商响应、请求头、密钥或 PDF 内容送到页面。"""
    stage = getattr(exc, "stage", stage)
    original = getattr(exc, "original", exc)
    error_type = type(original).__name__
    status = getattr(original, "status_code", None)
    detail = str(original).lower()
    code, message = "index_unknown", "处理未完成，请提供下方诊断编号、错误类型及后端对应日志以便排查"
    pdf_errors = {"文件不是有效的 PDF", "请先解密 PDF 再上传", "单份文献不能超过 500 页",
                  "PDF 文本过长，请按章节拆分", "PDF 无可提取文本；扫描件需先进行 OCR"}
    if stage == "read_pdf" and isinstance(original, ValueError) and str(original) in pdf_errors:
        code, message = "pdf_invalid", str(original)
    elif stage == "read_pdf" and error_type in ("PdfReadError", "PdfStreamError"):
        code, message = "pdf_unreadable", "PDF 内容损坏或格式不受支持，请重新导出 PDF 后上传"
    elif stage == "embedding" and settings.EMBEDDING_PROVIDER != "hash" and not (settings.EMBEDDING_API_KEY or settings.OPENAI_API_KEY):
        code, message = "embedding_key_missing", "未配置向量服务密钥，请填写 EMBEDDING_API_KEY（也支持兼用 OPENAI_API_KEY）；DeepSeek / 智谱聊天密钥不会自动用于向量服务"
    elif status == 401:
        code, message = "embedding_auth", "向量服务拒绝认证，请检查向量服务密钥与接口地址是否匹配"
    elif status == 403:
        code, message = "embedding_forbidden", "当前密钥没有调用此向量模型的权限，请检查模型访问权限"
    elif status == 404:
        code, message = "embedding_not_found", "向量接口或模型不存在，请核对 EMBEDDING_BASE_URL、EMBEDDING_MODEL，确认接口支持向量化"
    elif status == 429:
        code, message = "embedding_rate_limit", "向量服务额度不足或请求受限，请检查额度或稍后重试"
    elif status in (400, 413, 422):
        code, message = "embedding_request", "向量服务不接受请求参数或文本批次，请确认配置的是向量模型，并核对服务的输入限制"
    elif isinstance(status, int) and status >= 500:
        code, message = "embedding_server", "向量服务暂时异常，请稍后重试"
    elif "timeout" in error_type.lower():
        code, message = "index_timeout", ("存储或任务进度写入超时，请检查数据库连接、存储性能及后端日志"
            if stage == "storage" else "向量处理请求超时，请检查网络、服务状态或调整 LLM_TIMEOUT")
    elif "connection" in error_type.lower() or "ssl" in detail or "certificate" in detail:
        code, message = "index_connection", "无法连接向量服务，请检查接口地址、网络、代理或证书配置"
    elif isinstance(original, PermissionError) or "readonly" in detail or "read-only" in detail:
        code, message = "index_permission", "资料或向量存储目录不可读写，请检查目录权限和容器挂载权限"
    elif getattr(original, "errno", None) == 28 or "disk is full" in detail:
        code, message = "index_disk_full", "存储空间不足，请释放数据目录所在磁盘空间后重试"
    elif isinstance(original, (ModuleNotFoundError, ImportError)):
        code, message = "index_dependency", "向量处理依赖缺失或不兼容，请检查后端依赖安装情况"
    elif "dimension" in detail:
        code, message = "embedding_dimension", "向量维度与当前集合不一致，请核对向量模型名称及其实际输出维度"
    elif "embedding_count_mismatch" in detail:
        code, message = "embedding_response", "向量服务返回的向量数量与输入片段数量不一致"
    elif "没有可检索的文本" in detail:
        code, message = "index_empty_text", "资料没有可检索文本，请补充摘要或对扫描 PDF 做 OCR"
    elif isinstance(original, FileNotFoundError):
        code, message = "index_file_missing", "原始文件或存储路径不存在，请检查资料目录"
    diagnostic = {"code": code, "message": message, "stage": stage, "error_type": error_type,
                  "diagnostic_id": uuid4().hex[:12]}
    if isinstance(status, int):
        diagnostic["http_status"] = status
    # 不记录异常原文或局部变量，保留定位需要的阶段、类型和代码位置。
    logging.getLogger(__name__).error("Index diagnostic %s: stage=%s type=%s status=%s code=%s\n%s",
        diagnostic["diagnostic_id"], stage, error_type, status, code,
        "".join(traceback.format_list(traceback.extract_tb(original.__traceback__))))
    return diagnostic


def normalized(value):
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", str(value))).strip()


def text_digest(value):
    value = normalized(value)
    return hashlib.sha256(value.encode("utf-8")).hexdigest() if value else None


def extract_pdf(content: bytes):
    if not content.startswith(b"%PDF-"):
        raise ValueError("文件不是有效的 PDF")
    reader = PdfReader(BytesIO(content))
    if reader.is_encrypted:
        raise ValueError("请先解密 PDF 再上传")
    if len(reader.pages) > 500:
        raise ValueError("单份文献不能超过 500 页")
    pages = []
    length = 0
    for index, page in enumerate(reader.pages):
        text = (page.extract_text() or "").strip()
        length += len(text)
        if length > 1_000_000:
            raise ValueError("PDF 文本过长，请按章节拆分")
        if text:
            pages.append({"page": index + 1, "text": text})
    if not pages:
        raise ValueError("PDF 无可提取文本；扫描件需先进行 OCR")
    return pages


async def get_reference(db, reference_id):
    reference = await db.get(Reference, reference_id)
    if not reference:
        raise HTTPException(404, "文献不存在")
    return reference


async def owned_reference(db, reference_id, user_id):
    reference = await get_reference(db, reference_id)
    if reference.owner_id != user_id:
        raise HTTPException(403, "共享文献可供所有用户检索，修改或删除请由上传者操作")
    return reference


async def index_reference(db, store, reference, pages=None, progress=None):
    reference.index_status = "pending"
    reference.index_key = store.index_key
    reference.index_error = {}
    await db.commit()
    try:
        if pages is None:
            if reference.file_path and Path(reference.file_path).is_file():
                content = await asyncio.to_thread(Path(reference.file_path).read_bytes)
                pages = await asyncio.to_thread(extract_pdf, content)
            elif reference.full_text:
                # 迁移后的 PDF 路径不可用时仍可重建文本索引；页码 0 表示无法恢复原页码。
                pages = [{"page": 0, "text": reference.full_text}]
            else:
                pages = [{"page": 0, "text": reference.title + "\n" + reference.abstract}]
        data = ReferenceResponse.model_validate(reference).model_dump()
        await asyncio.to_thread(store.add_reference, data, pages, progress)
        reference.index_status = "indexed"
        reference.index_key = store.index_key
        reference.vector_id = f"ref-{reference.id}"
    except Exception as exc:
        reference.index_status = "failed"
        reference.index_error = index_diagnostic(exc, store.settings, "document")
        await db.commit()
        raise
    await db.commit()


def upload_path(settings, user_id=None):
    directory = settings.DATA_DIR / "uploads" / "shared"
    directory.mkdir(parents=True, exist_ok=True)
    return directory / f"{uuid4().hex}.pdf"


async def extract_metadata(content, pages, filename, settings):
    """优先读取嵌入信息与正文；模型字段必须有原文证据，无法识别时留空。"""
    reader = PdfReader(BytesIO(content))
    pdf_info = reader.metadata or {}
    data = MetadataExtraction().model_dump(exclude={"evidence"})
    sources = {}
    contexts = [{"page": page["page"], "text": page["text"][:7000]} for page in pages[:3]]
    context = "\n".join(p["text"] for p in contexts)[:16000]
    for field, pdf_field in (("title", "/Title"), ("authors", "/Author")):
        value = normalized(pdf_info.get(pdf_field) or "")[:500]
        if len(value) > 2 and not re.search(r"^(untitled|unknown|administrator|Microsoft Word|LaTeX)\b", value, re.I):
            data[field] = value
            sources[field] = {"source": "pdf_metadata", "quote": value}
    # DOI 仅从首页头部提取，避免把文末参考文献的 DOI 当成本篇文献的 DOI。
    first_page = pages[0]["text"][:7000]
    doi = re.search(r"\b10\.\d{4,9}/[-._;()/:A-Z0-9]+", first_page, re.I)
    if doi:
        data["doi"] = doi.group().rstrip(".,;)")
        sources["doi"] = {"source": "pdf_text", "page": pages[0]["page"], "quote": doi.group()}
    for field, pattern in (
        ("authors", r"(?im)^\s*(?:作者|Authors?)\s*[:：]\s*(.+)$"),
        ("journal", r"(?im)^\s*(?:期刊|刊名|Journal)\s*[:：]\s*(.+)$"),
        ("year", r"(?im)(?:出版年|发表年份|Published(?:\s+in)?|Copyright|©)\s*[:：]?\s*((?:19|20)\d{2})"),
    ):
        found = re.search(pattern, first_page)
        if found:
            data[field] = int(found.group(1)) if field == "year" else found.group(1).strip()[:200 if field == "journal" else 500]
            sources[field] = {"source": "pdf_text", "page": pages[0]["page"], "quote": found.group().strip()}
    abstract = re.search(r"(?is)(?:\babstract\b|摘\s*要)\s*[:：]?\s*(.{40,6000}?)(?=\n\s*(?:keywords|key words|关键词|关 键 词|1[.\s]+|introduction)|\Z)", context)
    if abstract:
        data["abstract"] = abstract.group(1).strip()
        sources["abstract"] = {"source": "pdf_text", "quote": data["abstract"][:500]}
    if settings.LLM_PROVIDER != "demo":
        from app.agents.base_agent import BaseAgent

        class MetadataAgent(BaseAgent):
            task = "metadata"
            instruction = (
                "从 PDF 首页和开头正文提取当前这篇文章的书目信息，不能提取引用的其他论文的信息。"
                "返回符合 output_schema 的 JSON；authors 为作者姓名字符串，不含单位。"
                "title、journal、abstract 保留原文，不翻译、不改写；年份是发表年份而非文件创建年份。"
                "每个非空字段必须在 evidence 中提供可在 pdf_text 或 pdf_info 找到的逐字原文。"
                "未出现的作者、期刊、年份、卷期、页码、DOI 留空或 null，禁止凭常识补全。"
            )

            async def execute(self, inputs):
                return await self.structured(inputs, MetadataExtraction)

        try:
            result = await asyncio.wait_for(MetadataAgent(settings).execute({
                "pdf_info": {k: str(pdf_info.get(k, ""))[:1000] for k in ("/Title", "/Author", "/Subject")},
                "pdf_text": context,
            }), timeout=settings.LLM_TIMEOUT)
            available = normalized(context + "\n" + "\n".join(str(pdf_info.get(k, "")) for k in ("/Title", "/Author", "/Subject"))).casefold()
            for field in METADATA_FIELDS:
                value = getattr(result, field)
                quote = normalized(result.evidence.get(field, ""))
                if not value or not quote or quote.casefold() not in available:
                    continue
                # 不仅检查引文存在，还检查字段内容受该引文支持。
                supported = normalized(value).casefold() in quote.casefold()
                if field == "authors":
                    names = re.findall(r"[\w\u4e00-\u9fff]+", str(value).casefold())
                    supported = bool(names) and all(name in quote.casefold() for name in names)
                if supported:
                    data[field] = value
                    page_number = next((p["page"] for p in contexts if quote.casefold() in normalized(p["text"]).casefold()), 0)
                    sources[field] = {"source": "model_with_pdf_evidence", "page": page_number, "quote": quote[:1000]}
        except Exception:
            # 自动识别失败不阻止入库，保留已确定字段与可编辑的待核对状态。
            sources["extraction_note"] = {"source": "system", "quote": "模型辅助识别未完成，已保留从 PDF 直接提取的信息"}
    if not data["title"]:
        candidates = [line.strip() for line in first_page.splitlines()[:15]
                      if 8 <= len(line.strip()) <= 250 and not re.search(
                          r"doi|https?://|copyright|received|accepted|issn|journal|@|\bvolume\b", line, re.I)]
        data["title"] = (candidates[0] if candidates else Path(filename).stem or "未识别题名")[:500]
        sources["title"] = {"source": "header_candidate" if candidates else "filename", "quote": data["title"]}
    if data["doi"] and not data["url"]:
        data["url"] = "https://doi.org/" + data["doi"]
    validated = ReferenceMetadata.model_validate(data).model_dump()
    core = ("title", "authors", "journal", "year")
    complete = all(validated[k] for k in core) and sources["title"]["source"] not in ("header_candidate", "filename")
    return validated, sources, "auto_extracted" if complete else "needs_review"


def migrate_legacy_references(connection):
    """一次性、事务内复制旧文献到共享库。保留旧表；不删除 PDF 或旧向量集合。"""
    marker = "shared_library_v2"
    if connection.scalar(select(LibraryMigration.name).where(LibraryMigration.name == marker)):
        return
    if "references" not in inspect(connection).get_table_names():
        connection.execute(LibraryMigration.__table__.insert().values(name=marker))
        return
    legacy = Table("references", MetaData(), autoload_with=connection)
    rows = connection.execute(select(legacy).order_by(legacy.c.id)).mappings().all()
    known_files, known_texts, associations = {}, {}, set()
    for old in rows:
        file_hash = None
        filename = Path(old.get("file_path") or "").name
        file_path = Path(old["file_path"]) if old.get("file_path") else None
        if file_path and file_path.is_file():
            try:
                with file_path.open("rb") as stream:
                    file_hash = hashlib.file_digest(stream, "sha256").hexdigest()
            except OSError:
                pass
        full_text = old.get("full_text") or ""
        content_hash = text_digest(full_text or ((old.get("title") or "") + "\n" + (old.get("abstract") or "")))
        canonical = known_files.get(file_hash) if file_hash else None
        canonical = canonical or (known_texts.get(content_hash) if content_hash else None)
        if canonical is None:
            canonical = old["id"]
            values = {k: old.get(k) or (None if k == "year" else "") for k in METADATA_FIELDS}
            values["title"] = values["title"] or filename or "待核对文献"
            connection.execute(Reference.__table__.insert().values(
                id=canonical, owner_id=old.get("owner_id"), **values, full_text=full_text,
                file_path=old.get("file_path") or "", filename=filename, file_hash=file_hash,
                content_hash=content_hash, index_status="pending", index_key="", vector_id="",
                metadata_status="needs_review", metadata_sources={"migration": {"source": "legacy", "quote": "旧版录入信息，保留供核对"}},
            ))
        if file_hash:
            known_files[file_hash] = canonical
        if content_hash:
            known_texts[content_hash] = canonical
        connection.execute(LegacyReferenceLink.__table__.insert().values(legacy_id=old["id"], reference_id=canonical))
        pair = (old.get("paper_id"), canonical)
        if pair[0] is not None and pair not in associations:
            connection.execute(paper_references.insert().values(paper_id=pair[0], reference_id=pair[1]))
            associations.add(pair)
    if connection.dialect.name == "postgresql":
        connection.execute(text("SELECT setval(pg_get_serial_sequence('library_references', 'id'), "
            "COALESCE((SELECT MAX(legacy_id) FROM legacy_reference_links), 1), EXISTS(SELECT 1 FROM legacy_reference_links))"))
    elif connection.dialect.name == "sqlite" and rows:
        # 跳过去重后腾出的旧编号，旧检查点中的文献 ID 才不会指向新上传的文献。
        connection.execute(text("UPDATE sqlite_sequence SET seq = :maximum WHERE name = 'library_references'"),
                           {"maximum": max(row["id"] for row in rows)})
    connection.execute(LibraryMigration.__table__.insert().values(name=marker))


async def library_stats(db, store):
    total = await db.scalar(select(func.count()).select_from(Reference))
    indexed = await db.scalar(select(func.count()).select_from(Reference).where(
        Reference.index_status == "indexed", Reference.index_key == store.index_key))
    review = await db.scalar(select(func.count()).select_from(Reference).where(Reference.metadata_status == "needs_review"))
    failed = await db.scalar(select(func.count()).select_from(Reference).where(
        Reference.index_status == "failed", Reference.index_key == store.index_key))
    return {"total": total, "indexed": indexed, "pending": total - indexed,
            "awaiting": total - indexed - failed, "failed": failed, "needs_review": review,
            "scope": "instance_shared", "embedding_mode": store.settings.EMBEDDING_PROVIDER}


class LibraryIndexer:
    """单进程持久任务队列。锁只保护状态变更，不覆盖解析或模型请求。"""
    active_states = ("queued", "running")

    def __init__(self, sessions, store, lock, paper_lock=None, metrics=None):
        self.sessions, self.store, self.lock = sessions, store, lock
        self.paper_lock = paper_lock or asyncio.Lock()
        self.metrics = metrics
        self.task = None
        self.event = asyncio.Event()
        self.closing = False
        self.progress = {"status": "idle", "error": {}}

    def wake(self):
        if not self.closing:
            if self.task is None or self.task.done():
                self.task = asyncio.create_task(self.run())
            self.event.set()

    async def recover(self):
        # 本项目按单个后端进程部署；中断任务从当前步骤重新执行，索引按文献替换。
        async with self.lock, self.sessions() as db:
            await db.execute(update(ReferenceJob).where(ReferenceJob.status == "running").values(
                status="queued", stage="queued", progress_done=0, progress_total=0))
            await db.commit()
        await self.start()
        self.wake()

    async def active_job(self, db, reference_id):
        return await db.scalar(select(ReferenceJob).where(ReferenceJob.reference_id == reference_id,
            ReferenceJob.status.in_(self.active_states)).order_by(ReferenceJob.created_at))

    async def ensure_idle(self, db, reference_id):
        if await self.active_job(db, reference_id):
            raise HTTPException(409, "这份资料正在后台处理，请等待任务结束后再修改或删除")

    async def enqueue_reference(self, db, reference, owner_id, operation="reindex", paper_id=None, duplicate=False):
        """调用方持有 library_lock；提交后唤醒，返回持久任务收据。"""
        active = await self.active_job(db, reference.id)
        if active:
            if paper_id is not None and active.paper_id != paper_id:
                raise HTTPException(409, "文献正在处理，请完成后在写作任务中重新检索关联")
            return active
        ready = reference.index_status == "indexed" and reference.index_key == self.store.index_key
        job = ReferenceJob(id=str(uuid4()), owner_id=owner_id, reference_id=reference.id,
            operation=operation, paper_id=paper_id, filename=reference.filename or reference.title,
            file_path=reference.file_path, file_hash=reference.file_hash or "", duplicate=duplicate)
        # 复用已有成功索引也走轻量后台完成步骤，以便安全关联可选的写作任务。
        if not (operation == "reuse" and ready):
            reference.index_status, reference.index_key, reference.index_error = "pending", self.store.index_key, {}
        db.add(job)
        await db.commit()
        self.wake()
        return job

    async def start(self, include_failed=False):
        count = 0
        async with self.lock, self.sessions() as db:
            query = select(Reference).where(or_(Reference.index_status != "indexed", Reference.index_key != self.store.index_key))
            if not include_failed:
                query = query.where(or_(Reference.index_status != "failed", Reference.index_key != self.store.index_key))
            for reference in (await db.scalars(query)).all():
                if not await self.active_job(db, reference.id):
                    await self.enqueue_reference(db, reference, reference.owner_id)
                    count += 1
        self.wake()
        return count

    async def job_progress(self):
        async with self.sessions() as db:
            counts = dict((await db.execute(select(ReferenceJob.status, func.count()).where(
                ReferenceJob.status.in_(self.active_states)).group_by(ReferenceJob.status))).all())
        total = sum(counts.values())
        return {**self.progress, "status": "failed" if self.progress["status"] == "failed" else "running" if total else "idle",
                "total": total, "queued": counts.get("queued", 0), "running": counts.get("running", 0)}

    async def _progress(self, job_id, stage, done=0, total=0):
        async with self.sessions() as db:
            await db.execute(update(ReferenceJob).where(ReferenceJob.id == job_id, ReferenceJob.status == "running").values(
                stage=stage, progress_done=done, progress_total=total))
            await db.commit()

    async def run(self):
        self.progress = {"status": "idle", "error": {}}
        try:
            while not self.closing:
                await self.event.wait()
                self.event.clear()
                while not self.closing:
                    async with self.lock, self.sessions() as db:
                        job = await db.scalar(select(ReferenceJob).where(ReferenceJob.status == "queued")
                            .order_by(ReferenceJob.created_at, ReferenceJob.id).limit(1))
                        if job is None:
                            break
                        job.status = "running"
                        job_id, metric_reference_id, metric_operation = job.id, job.reference_id, job.operation
                        await db.commit()
                    started = time.perf_counter()
                    try:
                        await self._execute(job_id)
                        if self.metrics:
                            self.metrics.record("reference_job", job_id=job_id,
                                                reference_id=metric_reference_id, operation=metric_operation,
                                                status="completed",
                                                duration_ms=round((time.perf_counter() - started) * 1000, 3))
                    except asyncio.CancelledError:
                        if self.metrics:
                            self.metrics.record("reference_job", job_id=job_id,
                                                reference_id=metric_reference_id, operation=metric_operation,
                                                status="interrupted",
                                                duration_ms=round((time.perf_counter() - started) * 1000, 3))
                        raise  # 下次启动时从持久队列恢复。
                    except Exception as exc:
                        if self.metrics:
                            self.metrics.record("reference_job", job_id=job_id,
                                                reference_id=metric_reference_id, operation=metric_operation,
                                                status="failed", error_type=type(exc).__name__,
                                                duration_ms=round((time.perf_counter() - started) * 1000, 3))
                        async with self.lock, self.sessions() as db:
                            job = await db.get(ReferenceJob, job_id)
                            if job is not None:
                                ref = await db.get(Reference, job.reference_id) if job.reference_id else None
                                error = (ref.index_error if ref and ref.index_status == "failed" else None)
                                job.error = error or index_diagnostic(exc, self.store.settings, job.stage)
                                job.status = "failed"
                                job.stage = job.error.get("stage", job.stage)
                                if ref and ref.index_status != "indexed":
                                    ref.index_status, ref.index_key, ref.index_error = "failed", self.store.index_key, job.error
                                await db.commit()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.progress = {"status": "failed", "error": index_diagnostic(exc, self.store.settings, "storage")}

    async def _execute(self, job_id):
        async with self.sessions() as db:
            job = await db.get(ReferenceJob, job_id)
            operation, reference_id = job.operation, job.reference_id
            link_paper_id = job.paper_id
            path, filename, digest, owner_id = job.file_path, job.filename, job.file_hash, job.owner_id
        pages = None
        if reference_id is None:
            if operation != "upload":
                raise FileNotFoundError("reference_removed")
            await self._progress(job_id, "read_pdf")
            content = await asyncio.to_thread(Path(path).read_bytes)
            pages = await asyncio.to_thread(extract_pdf, content)
            full_text = "\n\n".join(p["text"] for p in pages)
            content_hash = text_digest(full_text)
            async with self.lock, self.sessions() as db:
                reference_id = await db.scalar(select(Reference.id).where(or_(
                    Reference.file_hash == digest, Reference.content_hash == content_hash)))
                if reference_id is not None:
                    receipt = await db.get(ReferenceJob, job_id)
                    receipt.reference_id, receipt.duplicate = reference_id, True
                    await db.commit()  # 立即绑定，避免去重检查后被其他请求删除。
            if reference_id is None:
                await self._progress(job_id, "metadata")
                metadata, sources, status = await extract_metadata(content, pages, filename, self.store.settings)
            async with self.lock, self.sessions() as db:
                # 与手动摘要录入同时发生时仍做一次去重检查。
                existing = await db.scalar(select(Reference).where(or_(
                    Reference.file_hash == digest, Reference.content_hash == content_hash)))
                job = await db.get(ReferenceJob, job_id)
                if existing:
                    job.reference_id, job.duplicate = existing.id, True
                    pages = None  # 使用已保存原文，保持原始 PDF 页码一致。
                else:
                    ref = Reference(**metadata, owner_id=owner_id, filename=filename, file_path=path,
                        file_hash=digest, content_hash=content_hash, full_text=full_text,
                        metadata_status=status, metadata_sources=sources, index_key=self.store.index_key)
                    db.add(ref)
                    await db.flush()
                    job.reference_id = ref.id
                reference_id = job.reference_id
                await db.commit()
        if operation == "metadata":
            await self._progress(job_id, "read_pdf")
            content = await asyncio.to_thread(Path(path).read_bytes)
            pages = await asyncio.to_thread(extract_pdf, content)
            await self._progress(job_id, "metadata")
            metadata, sources, status = await extract_metadata(content, pages, filename, self.store.settings)
            async with self.lock, self.sessions() as db:
                ref = await get_reference(db, reference_id)
                for key, value in metadata.items():
                    setattr(ref, key, value)
                ref.metadata_status, ref.metadata_sources = status, sources
                await db.commit()
        loop = asyncio.get_running_loop()

        def progress(stage, done, total):
            if not self.closing:
                # 在线程内通知事件循环持久化进度；不持有资料锁或 SQLite 写事务。
                pending = asyncio.run_coroutine_threadsafe(self._progress(job_id, stage, done, total), loop)
                try:
                    pending.result(timeout=15)
                except Exception as exc:
                    pending.cancel()
                    from app.rag.vector_store import IndexBuildError
                    raise IndexBuildError("storage", exc) from exc

        await self._progress(job_id, "read_pdf")
        async with self.sessions() as db:
            ref = await get_reference(db, reference_id)
            ready = ref.index_status == "indexed" and ref.index_key == self.store.index_key
            if not (ready and operation in ("upload", "reuse")):
                await index_reference(db, self.store, ref, pages, progress)
        # 写作任务的关联只在索引成功后发生，不改动正在生成中的任务。
        from app.models.paper import Paper
        async with (self.paper_lock if link_paper_id else nullcontext()), self.lock, self.sessions() as db:
            job = await db.get(ReferenceJob, job_id)
            if job.paper_id:
                paper = await db.get(Paper, job.paper_id)
                if paper and paper.author_id == job.owner_id and not paper.active_run_id:
                    if all(ref.id != reference_id for ref in paper.references):
                        paper.references.append(await get_reference(db, reference_id))
            job.status, job.stage, job.error = "completed", "done", {}
            await db.commit()

    async def close(self):
        self.closing = True
        if self.task and not self.task.done():
            self.task.cancel()
            await asyncio.gather(self.task, return_exceptions=True)
