from fastapi import HTTPException
from app.models.paper import Paper
from app.models.user import utcnow


async def stop_and_trash(request, paper_id, owner_id):
    async with request.app.state.edit_lock:
        async with request.app.state.database.sessions() as db:
            paper = await db.get(Paper, paper_id)
            if not paper or paper.author_id != owner_id:
                raise HTTPException(404, "论文不存在")
            if paper.deleted_at:
                return {"paper_id": paper_id, "message": "论文已在回收站中。",
                        "operation": "move_paper_to_trash"}
            run_id, title = paper.active_run_id, paper.title
        if run_id:
            try:
                await request.app.state.workflow.cancel(run_id)
            except HTTPException as exc:
                if exc.status_code != 409:
                    raise
                status = await request.app.state.workflow.status(run_id)
                if status["status"] not in ("completed", "cancelled"):
                    raise
        try:
            async with request.app.state.database.sessions() as db:
                paper = await db.get(Paper, paper_id)
                if not paper or paper.author_id != owner_id:
                    raise HTTPException(404, "论文不存在")
                if not paper.deleted_at:
                    paper.deleted_from_status = paper.status
                    paper.deleted_at = utcnow()
                    paper.purge_after = None
                    paper.active_run_id = None
                    paper.finished_at = paper.finished_at or utcnow()
                    await db.commit()
        except Exception as exc:
            raise HTTPException(409, "生成任务已停止，但移入回收站失败；请刷新论文列表后重试。") from exc
        return {"paper_id": paper_id, "operation": "move_paper_to_trash",
                "message": f"《{title}》已移入回收站，相关运行任务已停止。"}
