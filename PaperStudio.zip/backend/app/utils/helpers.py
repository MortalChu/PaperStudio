import json
import re
from collections.abc import Iterable


def sse(event: str, data, event_id: int | None = None) -> str:
    prefix = f"id: {event_id}\n" if event_id is not None else ""
    return prefix + f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


def flatten_outline(outline: dict) -> list[dict]:
    result = []

    def visit(sections, prefix="", parent=None, depth=0):
        for i, section in enumerate(sections):
            key = f"{prefix}{i + 1}"
            result.append({**section, "key": key, "parent_key": parent, "depth": depth})
            visit(section.get("subsections", []), key + ".", key, depth + 1)

    visit(outline.get("sections", []))
    return result


def format_reference(ref: dict, number=1, style="gbt") -> str:
    author = ref.get("authors") or "作者未提供"
    title = ref.get("title") or "题名未提供"
    journal = ref.get("journal") or "来源未提供"
    year = str(ref.get("year") or "年份未提供")
    volume, issue, pages = (ref.get(k, "") for k in ("volume", "issue", "pages"))
    publication = f"{volume}{f'({issue})' if issue else ''}{f': {pages}' if pages else ''}"
    doi = ref.get("doi", "").removeprefix("https://doi.org/")
    suffix = f" https://doi.org/{doi}" if doi else (f" {ref['url']}" if ref.get("url") else "")
    if style == "apa":
        text = f"{author} ({year}). {title}. {journal}{', ' + publication if publication else ''}."
    elif style == "mla":
        text = f'{author}. “{title}.” {journal}, {year}{", " + publication if publication else ""}.'
    else:
        text = f"{author}. {title}[J]. {journal}, {year}{', ' + publication if publication else ''}."
    return f"[{number}] {text}{suffix}"


def assemble_paper(title: str, chapters: Iterable[dict], references: list[dict], style="gbt") -> str:
    parts = [f"# {title}"]
    for chapter in chapters:
        depth = min(chapter.get("depth", chapter.get("section_key", "").count(".")) + 2, 5)
        parts.append(f"{'#' * depth} {chapter['title']}\n\n{chapter.get('content', '')}")
    if references:
        parts.append("## 参考文献\n\n" + "\n\n".join(
            format_reference(r, i + 1, style) for i, r in enumerate(references)))
    return "\n\n".join(parts)


def citation_numbers(text: str) -> set[int]:
    return {int(x) for x in re.findall(r"\[(\d+)\]", text)}


def text_length(text: str) -> int:
    return len(re.sub(r"\s", "", text))


# 错误诊断只保留定位字段，不把模型原文、HTTP 请求头或密钥写进诊断包。
class ProcessingError(RuntimeError):
    def __init__(self, original, *, step="", service="", agent="", section_key=""):
        self.original = original
        self.step, self.service, self.agent, self.section_key = step, service, agent, section_key
        super().__init__("处理步骤未完成")


class StructuredOutputError(ValueError):
    def __init__(self, fields=None):
        self.fields = fields or []
        super().__init__("模型返回内容未通过 JSON / 大纲结构校验，修复重试后仍无效")


def configure_logging(settings):
    import logging
    from logging.handlers import RotatingFileHandler
    path = settings.DATA_DIR / "logs" / "agent.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("app")
    for handler in list(logger.handlers):
        if getattr(handler, "paper_writer_handler", False):
            logger.removeHandler(handler)
            handler.close()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    for handler in (RotatingFileHandler(path, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"),
                    logging.StreamHandler()):
        handler.paper_writer_handler = True
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    logger.info("Application logging ready: %s", path)
    return path


def failure_diagnostic(exc, settings, *, run_id="", step="workflow", paper_id=None):
    import logging
    import traceback
    from datetime import datetime, timezone
    from uuid import uuid4
    from urllib.parse import urlsplit
    chain, seen = [], set()
    current = exc
    while current is not None and id(current) not in seen and len(chain) < 12:
        seen.add(id(current))
        chain.append(current)
        current = getattr(current, "original", None) or current.__cause__
    operation = next((e for e in chain if getattr(e, "step", "")), None)
    if operation:
        step = operation.step
    service = next((e.service for e in chain if getattr(e, "service", "")), "internal")
    agent = next((e.agent for e in chain if getattr(e, "agent", "")), "")
    section = next((e.section_key for e in chain if getattr(e, "section_key", "")), "")
    errors = [e for e in chain if not isinstance(e, ProcessingError)] or [exc]
    error = next((e for e in errors if getattr(e, "status_code", None)), errors[0])
    status = getattr(error, "status_code", None)
    if status is None:
        status = getattr(getattr(error, "response", None), "status_code", None)
    error_type = type(error).__name__
    # 只用于归类，异常原文与整个供应商响应不会持久化或返回浏览器。
    detail = str(error).lower()
    provider = settings.EMBEDDING_PROVIDER if service == "embedding" else settings.LLM_PROVIDER if service == "chat" else ""
    prefix = settings.LLM_PROVIDER.upper()
    model = (settings.EMBEDDING_MODEL if service == "embedding" else
             getattr(settings, prefix + "_MODEL", "内置演示模板") if service == "chat" else "")
    base_url = (settings.EMBEDDING_BASE_URL if service == "embedding" else
                getattr(settings, prefix + "_BASE_URL", "") if service == "chat" else "")
    secrets = [value for name in ("OPENAI_API_KEY", "DEEPSEEK_API_KEY", "ZHIPU_API_KEY", "EMBEDDING_API_KEY", "SECRET_KEY")
               if (value := getattr(settings, name, ""))]

    def safe_token(value):
        value = str(value or "")
        if not re.fullmatch(r"[A-Za-z0-9_.:/-]{1,120}", value) or any(secret in value for secret in secrets):
            return ""
        return value

    body = getattr(error, "body", None)
    body = body if isinstance(body, dict) else {}
    provider_error = body.get("error", body)
    provider_error = provider_error if isinstance(provider_error, dict) else {}
    provider_code = safe_token(provider_error.get("code"))
    parameter = safe_token(provider_error.get("param"))
    structured = next((e for e in errors if isinstance(e, StructuredOutputError)), None)
    code, message, action = "execution_error", "内部执行异常", "请用诊断编号查找后端日志，并反馈错误类型和调用栈。"
    if structured or error_type in ("ValidationError", "OutputParserException", "JSONDecodeError"):
        code, message, action = "model_output_invalid", "模型输出未通过 JSON / 大纲结构校验", "检查模型是否支持按要求输出完整 JSON；可以重试，或取消任务后手动编辑大纲。"
    elif isinstance(status, int):
        code, message, action = {
            401: ("model_auth", "模型服务拒绝认证", "检查当前服务的 API 密钥与接口地址是否匹配。"),
            403: ("model_forbidden", "当前账号无权调用该模型", "检查模型访问权限及供应商账号状态。"),
            404: ("model_not_found", "模型或接口路径不存在", "核对模型标识和 Base URL，确认服务支持 OpenAI 兼容接口。"),
            429: ("model_rate_limit", "模型服务限流或额度不足", "检查余额与调用配额；并行润色时可降低 MAX_PARALLEL_CHAPTERS。"),
        }.get(status, ("model_request_rejected", "模型服务拒绝了请求", "检查供应商错误码、模型能力及请求参数。"))
        if status >= 500:
            code, message, action = "model_server_error", "模型服务或网关异常", "检查供应商服务状态，恢复后从检查点继续。"
        elif status in (400, 413, 422):
            if any(word in detail for word in ("context_length", "context length", "maximum context", "too many tokens", "input too long")):
                code, message, action = "model_context_limit", "输入超过模型上下文或长度限制", "缩减输入材料或选用上下文容量更大的模型；单纯增加超时时间无效。"
            elif "enable_thinking" in detail:
                code, message, action = "model_thinking_parameter", "模型接口对思考模式参数有额外要求", "检查供应商对 enable_thinking 与 stream 的要求，反馈错误码后再调整调用参数。"
            elif "unsupported" in detail or "not supported" in detail:
                code, message, action = "model_parameter_unsupported", "模型不支持当前请求中的某个参数或调用方式", "结合错误参数名检查 temperature、stream 等能力；不要仅修改超时时间。"
    elif "timeout" in error_type.lower():
        code, message, action = "model_timeout", "等待模型响应超时", "检查网络和模型响应速度；必要时调整 LLM_TIMEOUT，或降低并行润色数量。"
    elif any(word in error_type.lower() for word in ("connection", "connect", "ssl")):
        code, message, action = "model_connection", "无法连接模型服务", "检查后端到模型接口的网络、代理、证书及 Base URL。"
    elif "API_KEY" in str(error) and isinstance(error, ValueError):
        code, message, action = "model_key_missing", "当前模型服务尚未配置密钥", "填写所选写作 / 向量服务对应的 API_KEY，随后重启后端。"
    elif isinstance(error, ValueError) and str(error).startswith("共享知识库暂无"):
        code, message, action = "references_missing", "本次检索没有找到可用文献", "确认相关文献索引已完成，调整题目或关键词后重新检索。已有历史关联不代表本次检索一定命中。"
    elif isinstance(error, ValueError) and ("生成结果为空" in str(error) or "正文为空" in str(error)):
        code, message, action = "model_output_empty", "模型返回的正文为空", "核对模型是否返回可用文本、是否支持流式正文输出，再重试。"
    elif isinstance(error, (PermissionError, FileNotFoundError)) or "OperationalError" in error_type:
        code, message, action = "storage_error", "数据库、检查点或存储不可用", "检查数据路径、磁盘权限、空间和数据库连接；参照日志中的代码位置定位。"
    elif isinstance(error, (ImportError, ModuleNotFoundError)):
        code, message, action = "dependency_error", "运行依赖缺失或不兼容", "根据后端日志中的模块和代码位置检查依赖安装情况。"
    elif "recursion" in error_type.lower():
        code, message, action = "workflow_limit", "工作流执行超过步数限制", "检查工作流循环与修订条件，反馈诊断编号。"
    try:
        host = safe_token(urlsplit(base_url).hostname) if base_url else ""
    except ValueError:
        host = ""
    diagnostic = {"diagnostic_id": uuid4().hex[:12], "run_id": run_id, "paper_id": paper_id,
        "time": datetime.now(timezone.utc).isoformat(), "step": step, "service": service, "agent": agent,
        "section_key": section, "code": code, "message": message, "action": action,
        "error_type": error_type, "provider": provider, "model": model, "endpoint_host": host}
    if isinstance(status, int):
        diagnostic["http_status"] = status
    if provider_code:
        diagnostic["provider_code"] = provider_code
    if parameter:
        diagnostic["parameter"] = parameter
    request_id = safe_token(getattr(error, "request_id", ""))
    if request_id:
        diagnostic["provider_request_id"] = request_id
    if structured:
        diagnostic["validation_fields"] = structured.fields
    frames = []
    for item in chain:
        frames.append(type(item).__name__ + ":\n" + "".join(traceback.format_list(traceback.extract_tb(item.__traceback__))))
    logging.getLogger("app.diagnostics").error("Failure diagnostic %s\n%s",
        json.dumps(diagnostic, ensure_ascii=False), "\nCaused by:\n".join(frames))
    return diagnostic
