import asyncio
import json
from langchain.chat_models import init_chat_model
from langchain_core.messages import AIMessage
from langchain_core.runnables import RunnableLambda
from app.config import Settings


def demo_response(prompt):
    """Deterministic offline fixtures, visibly labelled and never used as a fallback."""
    messages = prompt.to_messages()
    task = messages[0].content.split("\n", 1)[0]
    data = json.loads(messages[-1].content)
    title = data.get("title", "研究主题")
    if "planner" in task:
        action = data.get("recommended_action") or data.get("available_actions", ["finish"])[0]
        result = {"action": action, "rationale": "根据当前状态选择下一项可执行行动。",
                  "retrieval_query": data.get("suggested_query", "")}
        return AIMessage(content=json.dumps(result, ensure_ascii=False))
    if "retrieval_query" in task:
        query = data.get("query", "").strip()
        concepts = [value.strip() for value in query.replace("，", " ").replace(",", " ").split() if value.strip()]
        queries = [query]
        if data.get("title") and data["title"] != query:
            queries.append(data["title"])
        if len(concepts) > 1:
            queries.append(" ".join(concepts[:6]))
        return AIMessage(content=json.dumps({"queries": list(dict.fromkeys(queries))[:3],
                                              "concepts": concepts[:8]}, ensure_ascii=False))
    if "reflection" in task:
        hard_issues = data.get("deterministic_issues", [])
        evidence_gaps = data.get("deterministic_evidence_gaps", [])
        decision = "revise" if hard_issues else "retrieve_more" if evidence_gaps else "finish"
        result = {"decision": decision,
                  "summary": "依据结构、字数、引用与证据覆盖情况完成本轮评审。",
                  "issues": hard_issues, "evidence_gaps": evidence_gaps,
                  "target_sections": data.get("suggested_target_sections", []),
                  "retrieval_query": data.get("suggested_query", ""),
                  "revision_instructions": hard_issues}
        return AIMessage(content=json.dumps(result, ensure_ascii=False))
    if "topic" in task:
        field = data.get("field") or data.get("topic") or "人工智能"
        result = {"topics": [{
            "title": f"{field}的{angle}研究",
            "value": "明确应用场景、评价指标与适用边界。",
            "innovation": "比较现有方法并验证可复现的改进假设。",
            "feasibility": "需先确认公开数据或自有数据的可用性。",
        } for angle in ("方法比较与评估", "应用机制与局限", "可靠性与优化路径")]}
        return AIMessage(content=json.dumps(result, ensure_ascii=False))
    if "outline" in task:
        names = ["摘要", "引言", "相关研究", "研究方法", "结果与分析", "讨论", "结论"]
        if data.get("paper_type") == "review":
            names = ["摘要", "引言", "文献筛选方法", "研究进展", "争议与局限", "研究展望", "结论"]
        if data.get("paper_type") == "application":
            names = ["摘要", "引言", "需求分析", "系统设计", "实现与评价", "局限与改进", "结论"]
        result = {"title": title, "sections": [{"title": n, "points": [f"围绕{title}说明{n}的核心问题",
                   "依据已提供材料展开论证，区分已有证据与待验证假设"],
                   "word_count": max(100, data.get("word_limit", 5000) // len(names))} for n in names]}
        return AIMessage(content=json.dumps(result, ensure_ascii=False))
    if "polish" in task:
        return AIMessage(content=data["content"].replace("非常非常", "较为").strip())
    refs = data.get("references", [])
    points = "；".join(data.get("outline_points", []))
    evidence = "\n\n".join(f"所提供文献《{r['title']}》的相关摘录：{r.get('excerpt', '')[:240]} [{r['citation_number']}]"
                            for r in refs[:2])
    content = (
        f"【演示模式示例，非真实模型生成】\n\n本节围绕“{title}”讨论{data.get('section_title', '')}。"
        f"主要内容包括：{points or '研究背景、方法和局限'}。\n\n"
        "研究应明确问题定义、样本来源、比较基线以及评价指标，记录分析步骤以便复核。"
        "对材料中的观点，应区分作者结论、适用条件与尚待验证的推断。\n\n"
        f"{evidence or '【待补充文献】当前没有可引用的文献片段。'}\n\n"
        "【待验证】尚未提供实验记录与原始数据，不能据此报告真实的统计结果或性能提升。"
        "后续应补充证据、说明局限，并将观察结果与研究假设分别表述。"
    )
    return AIMessage(content=content)


def get_llm(settings: Settings, temperature=0.4):
    if settings.LLM_PROVIDER == "demo":
        async def respond(prompt):
            await asyncio.sleep(0)
            return demo_response(prompt)
        return RunnableLambda(respond)
    prefix = settings.LLM_PROVIDER.upper()
    key = getattr(settings, f"{prefix}_API_KEY")
    if not key:
        raise ValueError(f"请在 backend/.env 中配置 {prefix}_API_KEY")
    return init_chat_model(
        model=getattr(settings, f"{prefix}_MODEL"), model_provider="openai",
        api_key=key, base_url=getattr(settings, f"{prefix}_BASE_URL"),
        temperature=temperature, timeout=settings.LLM_TIMEOUT, max_retries=2,
        **({"max_tokens": settings.LLM_MAX_OUTPUT_TOKENS} if settings.LLM_MAX_OUTPUT_TOKENS else {}),
        **({"extra_body": settings.LLM_EXTRA_BODY} if settings.LLM_EXTRA_BODY else {}),
    )
