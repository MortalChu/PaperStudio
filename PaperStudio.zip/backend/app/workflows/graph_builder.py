import asyncio
import inspect
import time

from langgraph.config import get_stream_writer
from langgraph.errors import GraphInterrupt
from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt
from sqlalchemy import select

from app.agents.outline_agent import OutlineAgent
from app.agents.planner_agent import PlannerAgent
from app.agents.polish_agent import PolishAgent
from app.agents.reference_agent import ReferenceAgent
from app.agents.reflection_agent import ReflectionAgent
from app.agents.topic_agent import TopicAgent
from app.agents.writer_agent import WriterAgent
from app.models.paper import AgentMessage, Paper
from app.schemas.paper import Outline, ResumeRequest
from app.services.agent_service import merge_preferences, normalize_preferences, effective_preferences, load_effective_preferences
from app.utils.helpers import ProcessingError, assemble_paper, citation_numbers, flatten_outline, text_length
from app.workflows.state import PaperState


class PaperWorkflowGraph:
    """Stateful planner/tool/reflection loop with bounded actions and durable checkpoints."""

    def __init__(self, settings, retriever, checkpointer, sessions=None, metrics=None):
        self.settings = settings
        self.sessions = sessions
        self.metrics = metrics
        self.topic_agent = TopicAgent(settings)
        self.outline_agent = OutlineAgent(settings)
        self.writer_agent = WriterAgent(settings)
        self.polish_agent = PolishAgent(settings)
        self.planner_agent = PlannerAgent(settings)
        self.reflection_agent = ReflectionAgent(settings)
        self.reference_agent = ReferenceAgent(retriever, settings)
        self.semaphore = asyncio.Semaphore(settings.MAX_PARALLEL_CHAPTERS)
        self.live_event_sink = None

        builder = StateGraph(PaperState)
        nodes = ("analyze_topic", "plan_next", "recommend_topic", "confirm_topic", "generate_outline",
                 "confirm_outline", "confirm_review", "user_intervention", "add_references", "refresh_references", "write_sections", "write_section",
                 "polish_paper", "quality_check", "finalize")
        for name in nodes:
            builder.add_node(name, self._traced_node(name, getattr(self, "_" + name)))
        builder.add_edge(START, "analyze_topic")
        builder.add_edge("analyze_topic", "plan_next")
        routes = {name: name for name in ("recommend_topic", "confirm_topic", "generate_outline",
                                          "confirm_outline", "confirm_review", "add_references", "refresh_references",
                                          "write_sections", "polish_paper", "quality_check", "finalize")}
        builder.add_conditional_edges("plan_next", self._route_plan, routes)
        for name in ("recommend_topic", "confirm_topic", "generate_outline", "confirm_outline", "confirm_review",
                     "add_references", "refresh_references", "polish_paper", "quality_check"):
            builder.add_edge(name, "plan_next")
        builder.add_edge("user_intervention", "plan_next")
        builder.add_edge("write_sections", "write_section")
        builder.add_conditional_edges("write_section", self._route_after_section,
                                      {"write_section": "write_section", "plan_next": "plan_next"})
        builder.add_edge("finalize", END)
        self.graph = builder.compile(checkpointer=checkpointer)

    async def _current_paper(self, state):
        if not self.sessions or not state.get("paper_id"):
            return None
        async with self.sessions() as db:
            return await db.get(Paper, state["paper_id"])

    async def _finish_active_user_message(self, state):
        message_id = state.get("active_user_message_id")
        if not message_id or not self.sessions:
            return
        from app.models.user import utcnow
        async with self.sessions() as db:
            message = await db.get(AgentMessage, message_id)
            if message and message.status == "executing":
                operation = message.action
                message.status = "completed"
                message.completed_at = utcnow()
                labels = {"revise": "定向章节修改", "retrieve": "补充文献检索", "review": "按需核对"}
                summary = (state.get("last_reflection") or {}).get("summary", "") if operation == "review" else ""
                content = f"已完成本轮{labels.get(operation, '工具操作')}。"
                if summary:
                    content += " " + summary
                content += " 规划器会结合更新后的论文状态决定是否还需执行后续步骤。"
                db.add(AgentMessage(paper_id=message.paper_id, user_id=message.user_id,
                    role="assistant", content=content, status="completed", action="tool_result",
                    details={"in_reply_to": message.id, "operation": operation},
                    completed_at=utcnow()))
                await db.commit()

    async def _pending_user_message(self, state):
        if not self.sessions:
            return None
        async with self.sessions() as db:
            return await db.scalar(select(AgentMessage).where(
                AgentMessage.paper_id == state["paper_id"], AgentMessage.role == "user",
                AgentMessage.status == "pending").order_by(AgentMessage.id))

    @staticmethod
    def _resolve_targets(outline, requested):
        sections = flatten_outline(outline)
        resolved = []
        chinese = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5,
                   "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}
        for target in requested or []:
            compact = str(target).replace(" ", "")
            number = None
            if compact.startswith("第") and compact.endswith(("章", "节")):
                raw = compact[1:-1]
                if raw.isdigit():
                    number = int(raw)
                elif raw in chinese:
                    number = chinese[raw]
                elif raw.startswith("十") and len(raw) == 2:
                    number = 10 + chinese.get(raw[1:], 0)
                elif raw.endswith("十") and len(raw) == 2:
                    number = chinese.get(raw[0], 0) * 10
            for section in sections:
                key, title = section["key"], section["title"]
                if (number and (key == str(number) or key.startswith(str(number) + "."))) or \
                        target in (key, title) or str(target) in title:
                    resolved.append(key)
        return list(dict.fromkeys(resolved))

    def _traced_node(self, name, function):
        async def invoke(state):
            section = state.get("section") or {}
            if name == "write_section" and state.get("pending_section_keys"):
                key = state["pending_section_keys"][0]
                section = next((item for item in flatten_outline(state.get("outline") or {})
                                if item["key"] == key), {"key": key, "title": f"章节 {key}"})
            section_key = section.get("key", "")
            writer = get_stream_writer()
            writer({"kind": "step_start", "step": name, "section_key": section_key,
                    "title": section.get("title", "")})
            started = time.perf_counter()
            status = "completed"
            try:
                result = function(state)
                return await result if inspect.isawaitable(result) else result
            except GraphInterrupt:
                status = "waiting_for_human"
                raise
            except Exception as exc:
                status = "failed"
                raise ProcessingError(exc, step=name, section_key=section_key) from exc
            finally:
                if self.metrics:
                    self.metrics.record("workflow_node", node=name, status=status,
                                        paper_id=state.get("paper_id"), section_key=section_key,
                                        duration_ms=round((time.perf_counter() - started) * 1000, 3))
        return invoke

    async def _analyze_topic(self, state):
        return {"current_step": "analyze_topic", "is_topic_clear": bool(state.get("is_topic_clear", True)),
                "last_action": "analyze_topic"}

    def _available_actions(self, state):
        if not state.get("is_topic_clear"):
            return (["confirm_topic"], "confirm_topic") if state.get("topics") else (["recommend_topic"], "recommend_topic")
        if not state.get("references"):
            return ["retrieve"], "retrieve"
        if not state.get("outline"):
            actions = ["generate_outline"]
            if state.get("retrieval_round", 0) < state.get("max_retrieval_rounds", 3):
                actions.append("retrieve")
            return actions, "generate_outline"
        if not state.get("outline_confirmed"):
            return ["confirm_outline"], "confirm_outline"
        if state.get("references_stale"):
            return ["retrieve"], "retrieve"
        if state.get("auto_review") is None:
            return ["confirm_review"], "confirm_review"

        sections = flatten_outline(state["outline"])
        completed = state.get("sections_content", {})
        missing = [section for section in sections if not completed.get(section["key"], "").strip()]
        if missing:
            actions = ["write_sections"]
            if state.get("retrieval_round", 0) < state.get("max_retrieval_rounds", 3):
                actions.append("retrieve")
            return actions, "write_sections"

        writing_round = state.get("writing_round", 0)
        if not state.get("auto_review", False):
            if state.get("polished_round", 0) < writing_round:
                return ["polish", "finish"], "polish"
            return ["finish"], "finish"
        if state.get("reflection_round", 0) < writing_round:
            actions = ["reflect"]
            if state.get("polished_round", 0) < writing_round:
                actions.append("polish")
                return actions, "polish"
            return actions, "reflect"

        reflection = state.get("last_reflection") or {}
        decision = reflection.get("decision", "finish")
        if decision == "retrieve_more" and state.get("last_action") in ("add_references", "refresh_references"):
            if state.get("revision_count", 0) < state.get("max_revisions", 1):
                return ["write_sections"], "write_sections"
            return ["finish"], "finish"
        if decision == "retrieve_more" and state.get("retrieval_round", 0) < state.get("max_retrieval_rounds", 3):
            return ["retrieve", "write_sections"], "retrieve"
        if decision == "revise" and state.get("revision_count", 0) < state.get("max_revisions", 1):
            actions = ["write_sections"]
            if state.get("retrieval_round", 0) < state.get("max_retrieval_rounds", 3):
                actions.append("retrieve")
            return actions, "write_sections"
        if state.get("polished_round", 0) < writing_round:
            return ["polish", "finish"], "polish"
        return ["finish"], "finish"

    async def _plan_next(self, state):
        # A completed tool call acknowledges the durable user turn before another action is planned.
        if state.get("active_user_message_id"):
            await self._finish_active_user_message(state)
            completed_user_action = state.get("active_user_action", "")
            state = {**state, "active_user_message_id": 0, "user_instruction": "",
                     "user_target_sections": [], "active_user_action": ""}
            if completed_user_action != "review":
                state["last_reflection"] = {"decision": "finish",
                    "summary": "上一条用户工具要求已执行。", "issues": [],
                    "evidence_gaps": [], "target_sections": [], "revision_instructions": []}
        current = await self._current_paper(state)
        preferences = {}
        if self.sessions and current:
            async with self.sessions() as db:
                preferences = await load_effective_preferences(db, current)
        state = {**state, "auto_review": preferences.get("auto_review", state.get("auto_review", False)),
                 "writing_style": preferences.get("writing_style", state.get("writing_style", "")),
                 "persistent_instructions": preferences.get(
                     "persistent_instructions", state.get("persistent_instructions", "")),
                 "preference_memory": preferences.get(
                     "preference_memory", state.get("preference_memory", []))}
        step = state.get("agent_step", 0) + 1
        if step > state.get("max_agent_steps", self.settings.MAX_AGENT_STEPS):
            if state.get("final_paper"):
                decision = {"action": "finish", "rationale": "达到最大行动步数，保存最近一次完整评审结果。",
                            "retrieval_query": "", "guardrail_applied": True}
                allowed = ["finish"]
            else:
                raise RuntimeError("规划智能体超过最大行动步数，且尚无可保存的完整初稿")
        else:
            pending = await self._pending_user_message(state)
            pending_plan = (pending.details or {}).get("plan", {}) if pending else {}
            pending_operation = pending_plan.get("operation")
            outlined_sections = flatten_outline(state["outline"]) if state.get("outline") else []
            can_revise = bool(outlined_sections and state.get("references"))
            can_review = bool(outlined_sections and all(
                state.get("sections_content", {}).get(section["key"], "").strip()
                for section in outlined_sections))
            if pending_operation == "retrieve":
                allowed, recommended = ["retrieve"], "retrieve"
            elif pending_operation == "revise" and can_revise:
                allowed, recommended = ["write_sections"], "write_sections"
            elif pending_operation == "review" and can_review:
                allowed, recommended = ["reflect"], "reflect"
            else:
                pending = None
                allowed, recommended = self._available_actions(state)
            base_query = " ".join(filter(None, (state.get("title"), state.get("topic"), state.get("keywords"))))
            reflection = state.get("last_reflection") or {}
            suggested_query = (pending_plan.get("retrieval_query") if pending else "") or \
                reflection.get("retrieval_query") or " ".join(reflection.get("evidence_gaps", [])) or base_query
            decision = await self.planner_agent.execute({
                "goal": pending_plan.get("instruction") if pending else
                    "根据共享文献生成有引用依据、可供作者核对的论文初稿",
                "available_actions": allowed, "recommended_action": recommended,
                "suggested_query": suggested_query,
                "state_summary": {"title": state.get("title"), "topic_clear": state.get("is_topic_clear"),
                    "reference_count": len(state.get("references", [])), "has_outline": bool(state.get("outline")),
                    "outline_confirmed": state.get("outline_confirmed", False),
                    "completed_sections": len(state.get("sections_content", {})),
                    "writing_round": state.get("writing_round", 0),
                    "retrieval_round": state.get("retrieval_round", 0),
                    "revision_count": state.get("revision_count", 0)},
                "last_action": state.get("last_action", ""), "reflection": reflection,
                "preferences": {"writing_style": state.get("writing_style", ""),
                    "persistent_instructions": state.get("persistent_instructions", ""),
                    "preference_memory": state.get("preference_memory", [])},
            })
            if pending:
                targets = self._resolve_targets(state.get("outline"), pending_plan.get("target_sections", []))
                if pending_operation == "revise":
                    reflection = {"decision": "revise", "summary": "执行用户在对话中提出的定向修改。",
                        "issues": [], "evidence_gaps": [], "target_sections": targets,
                        "revision_instructions": [pending_plan.get("instruction", pending.content)],
                        "retrieval_query": ""}
                async with self.sessions() as db:
                    stored = await db.get(AgentMessage, pending.id)
                    stored.status = "executing"
                    await db.commit()
                state = {**state, "active_user_message_id": pending.id,
                    "active_user_action": pending_operation,
                    "user_instruction": pending_plan.get("instruction", pending.content),
                    "user_target_sections": targets,
                    "polish_targets": targets if pending_operation == "revise" and can_review else [],
                    "last_reflection": reflection,
                    "max_revisions": max(state.get("max_revisions", 1), state.get("revision_count", 0) + 1)}
        get_stream_writer()({"kind": "agent_decision", "step": "plan_next", "action": decision["action"],
                             "rationale": decision["rationale"], "available_actions": allowed,
                             "guardrail_applied": decision.get("guardrail_applied", False)})
        record = {"step": step, "action": decision["action"], "rationale": decision["rationale"],
                  "guardrail_applied": decision.get("guardrail_applied", False)}
        return {"agent_step": step, "next_action": decision["action"],
                "planned_retrieval_query": decision.get("retrieval_query", ""),
                "agent_decisions": [record], "current_step": "plan_next",
                "auto_review": state.get("auto_review", False),
                "writing_style": state.get("writing_style", ""),
                "persistent_instructions": state.get("persistent_instructions", ""),
                "preference_memory": state.get("preference_memory", []),
                "active_user_message_id": state.get("active_user_message_id", 0),
                "active_user_action": state.get("active_user_action", ""),
                "user_instruction": state.get("user_instruction", ""),
                "user_target_sections": state.get("user_target_sections", []),
                "polish_targets": state.get("polish_targets", []),
                "last_reflection": state.get("last_reflection", {})}

    def _route_plan(self, state):
        action = state["next_action"]
        if action == "retrieve":
            return "refresh_references" if state.get("outline_confirmed") else "add_references"
        return {"polish": "polish_paper", "reflect": "quality_check", "finish": "finalize"}.get(action, action)

    def _user_intervention(self, state):
        return {"current_step": "user_intervention", "last_action": "user_intervention"}

    async def _recommend_topic(self, state):
        sources = await self.reference_agent.execute({"query": state["topic"] or state["title"], "top_k": 8,
                                                       "title": state.get("title", "")})
        result = await self.topic_agent.execute({"field": state["topic"] or state["title"],
                    "keywords": state["keywords"], "requirements": state["requirements"],
                    "references": sources["references"]})
        return {"topics": result["topics"], "current_step": "recommend_topic", "last_action": "recommend_topic"}

    def _confirm_topic(self, state):
        response = interrupt({"kind": "topic", "topics": state["topics"], "message": "请选择或输入论文题目"})
        validated = ResumeRequest.model_validate(response)
        if not validated.title:
            raise ValueError("确认选题时必须提供题目")
        return {"title": validated.title, "is_topic_clear": True, "outline": None,
                "current_step": "confirm_topic", "last_action": "confirm_topic"}

    async def _generate_outline(self, state):
        outline = state.get("outline")
        current = await self._current_paper(state)
        if outline and current and current.outline:
            outline = current.outline
        word_limit = current.word_limit if current else state["word_limit"]
        if not outline:
            result = await self.outline_agent.execute({**{key: state[key] for key in
                        ("title", "paper_type", "requirements", "topic", "keywords")},
                        "word_limit": word_limit, "references": state.get("references", []),
                        "writing_style": state.get("writing_style", ""),
                        "persistent_instructions": state.get("persistent_instructions", ""),
                        "preference_memory": state.get("preference_memory", [])})
            outline = result["outline"]
        return {"outline": Outline.model_validate(outline).model_dump(), "word_limit": word_limit,
                "outline_confirmed": False, "current_step": "generate_outline", "last_action": "generate_outline"}

    def _confirm_outline(self, state):
        outline = state["outline"]
        if state.get("review_outline", True):
            response = interrupt({"kind": "outline", "outline": outline, "message": "编辑并确认大纲后开始撰写"})
            validated = ResumeRequest.model_validate(response)
            if not validated.approved:
                raise ValueError("大纲尚未确认")
            if validated.outline:
                outline = validated.outline.model_dump()
        return {"outline": outline, "title": outline["title"], "outline_confirmed": True,
                "references_stale": True, "current_step": "confirm_outline", "last_action": "confirm_outline"}

    async def _confirm_review(self, state):
        response = interrupt({"kind": "review_preference",
            "message": "初稿完成后，是否允许我自动核对结构、引用和证据缺口，并自主决定补检索或修订？"})
        validated = ResumeRequest.model_validate(response)
        if validated.auto_review is None:
            raise ValueError("请选择是否允许 Agent 自动核对")
        current = await self._current_paper(state)
        if current and self.sessions:
            async with self.sessions() as db:
                paper = await db.get(Paper, current.id)
                paper.agent_preferences = merge_preferences(
                    paper.agent_preferences, {"auto_review": validated.auto_review,
                                              "preference_memory": [
                        "允许 Agent 自动核对" if validated.auto_review else "不进行 Agent 自动核对"]})
                await db.commit()
        return {"auto_review": validated.auto_review, "current_step": "confirm_review",
                "last_action": "confirm_review"}

    async def _add_references(self, state):
        base_query = " ".join(filter(None, (state.get("title"), state.get("topic"), state.get("keywords"))))
        reflection = state.get("last_reflection") or {}
        query = state.get("planned_retrieval_query") or reflection.get("retrieval_query") or base_query
        result = await self.reference_agent.execute({"query": query, "title": state.get("title", ""),
                    "top_k": 20, "format": state["citation_style"], "reflection": reflection,
                    "existing_references": state.get("references", [])})
        if not result["references"]:
            raise ValueError("共享知识库暂无符合检索条件的文献。请先上传相关资料，等待索引完成后继续任务。")
        return {"references": result["references"], "formatted_references": result["formatted"],
                "retrieval_query_plan": result["query_plan"],
                "retrieval_round": state.get("retrieval_round", 0) + 1, "references_stale": False,
                "current_step": "add_references", "last_action": "add_references"}

    async def _refresh_references(self, state):
        result = await self._add_references(state)
        result.update(current_step="refresh_references", last_action="refresh_references")
        return result

    async def _write_sections(self, state):
        reflection = state.get("last_reflection") or {}
        is_revision = reflection.get("decision") in ("revise", "retrieve_more") and state.get("writing_round", 0) > 0
        sections = flatten_outline(state["outline"])
        targets = set(reflection.get("target_sections", [])) if reflection.get("decision") == "revise" else set()
        if targets:
            selected = [section for section in sections
                        if section["key"] in targets or section["title"] in targets]
            if selected:
                sections = selected
        elif reflection.get("decision") not in ("revise", "retrieve_more"):
            completed = state.get("sections_content", {})
            missing = [section for section in sections if not completed.get(section["key"], "").strip()]
            if missing:
                sections = missing
        if not sections:
            raise ValueError("当前大纲没有可写作章节")
        return {"current_step": "write_sections", "last_action": "write_sections", "final_paper": "",
                "pending_section_keys": [section["key"] for section in sections],
                "writing_round": state.get("writing_round", 0) + 1,
                "revision_count": state.get("revision_count", 0) + (1 if is_revision else 0)}

    def _route_after_section(self, state):
        return "write_section" if state.get("pending_section_keys") else "plan_next"

    async def _write_section(self, state):
        pending = list(state.get("pending_section_keys") or [])
        if not pending:
            raise ValueError("章节写作队列为空")
        section_key = pending[0]
        outline = state["outline"]
        sections = flatten_outline(outline)
        section = next((item for item in sections if item["key"] == section_key), None)
        if not section:
            raise ValueError(f"大纲中不存在章节 {section_key}")
        current = await self._current_paper(state)
        if current and current.outline:
            outline = current.outline
            sections = flatten_outline(outline)
            section = next((item for item in sections if item["key"] == section_key), section)
        writer = get_stream_writer()
        reflection = state.get("last_reflection") or {}
        position = next((index for index, item in enumerate(sections) if item["key"] == section_key), 0)
        previous_sections = [{"key": item["key"], "title": item["title"],
            "content": state.get("sections_content", {}).get(item["key"], "")[-1500:]}
            for item in sections[:position] if state.get("sections_content", {}).get(item["key"])]
        data = {"title": state["title"], "outline": outline, "section_title": section["title"],
                "outline_points": section["points"], "word_count": section["word_count"],
                "references": state["references"], "requirements": state["requirements"],
                "revision_feedback": reflection.get("revision_instructions", []) + reflection.get("issues", []),
                "user_instruction": state.get("user_instruction", ""),
                "writing_style": state.get("writing_style", ""),
                "persistent_instructions": state.get("persistent_instructions", "")}
        data["preference_memory"] = state.get("preference_memory", [])
        if current and self.sessions:
            async with self.sessions() as db:
                preferences = await load_effective_preferences(db, current)
            for key in ("writing_style", "persistent_instructions", "preference_memory"):
                data[key] = preferences[key]
        data["previous_sections"] = previous_sections[-3:]
        async with self.semaphore:
            content = ""
            async for token in self.writer_agent.stream_execute(data):
                content += token
                event = {"kind": "token", "section_key": section["key"],
                         "title": section["title"], "text": token}
                # 部分 LangGraph/provider 组合会在节点结束后才转交 custom 事件。
                # 直接写入工作流的内存事件缓冲，轮询界面即可在章节完成前读到 token。
                if self.live_event_sink and state.get("run_id"):
                    await self.live_event_sink(state["run_id"], event)
                else:
                    writer(event)
        if not content.strip():
            raise ValueError(f"章节“{section['title']}”生成结果为空")
        return {"sections_content": {section["key"]: content},
                "pending_section_keys": pending[1:], "current_step": "write_section"}

    async def _polish_paper(self, state):
        async def polish(section):
            async with self.semaphore:
                original = state["sections_content"][section["key"]]
                try:
                    result = await self.polish_agent.execute({"content": original, "focus": "all",
                        "writing_style": state.get("writing_style", ""),
                        "persistent_instructions": state.get("persistent_instructions", ""),
                        "preference_memory": state.get("preference_memory", [])})
                except Exception as exc:
                    raise ProcessingError(exc, step="polish_paper", section_key=section["key"]) from exc
                return section["key"], result["polished"]
        sections = flatten_outline(state["outline"])
        targets = set(state.get("polish_targets", []))
        if targets:
            selected = [section for section in sections if section["key"] in targets]
            if selected:
                sections = selected
        pairs = await asyncio.gather(*(polish(section) for section in sections))
        return {"sections_content": dict(pairs), "polished_round": state.get("writing_round", 0),
                "polish_targets": [],
                "current_step": "polish_paper", "last_action": "polish_paper"}

    async def _quality_check(self, state):
        current = await self._current_paper(state)
        outline = current.outline if current and current.outline else state["outline"]
        word_limit = current.word_limit if current else state["word_limit"]
        sections = flatten_outline(outline)
        chapters = [{**section, "content": state["sections_content"].get(section["key"], "")} for section in sections]
        body = "\n".join(chapter["content"] for chapter in chapters)
        issues, warnings, gaps, targets = [], [], [], []
        for chapter in chapters:
            if not chapter["content"].strip():
                issues.append(f"章节“{chapter['title']}”缺少正文")
                targets.append(chapter["key"])
        invalid = citation_numbers(body) - {reference["citation_number"] for reference in state["references"]}
        if invalid:
            issues.append(f"存在无法溯源的引用编号：{sorted(invalid)}")
        if not state["references"]:
            gaps.append("缺少可引用文献")
        if "【待补充文献】" in body:
            gaps.append("正文仍有待补充文献标记")
        if "【待验证】" in body:
            warnings.append("正文包含待验证内容，需要作者补充研究数据或人工核对")
        actual = text_length(body)
        if actual < word_limit * 0.7:
            issues.append(f"正文字数约 {actual}，低于目标 {word_limit} 的 70%")
        elif actual > word_limit * 1.3:
            issues.append(f"正文字数约 {actual}，超过目标 {word_limit} 的 130%")
        suggested_query = " ".join(filter(None, (state.get("title"), *gaps)))
        reflection = await self.reflection_agent.execute({
            "title": state["title"], "outline": outline,
            "chapters": [{"key": chapter["key"], "title": chapter["title"],
                          "content": chapter["content"][:3000]} for chapter in chapters],
            "references": [{"citation_number": reference["citation_number"], "title": reference["title"],
                            "excerpt": reference.get("excerpt", "")[:1200]} for reference in state["references"]],
            "deterministic_issues": issues, "deterministic_evidence_gaps": gaps,
            "suggested_target_sections": targets, "suggested_query": suggested_query,
            "preferences": {"writing_style": state.get("writing_style", ""),
                "persistent_instructions": state.get("persistent_instructions", ""),
                "preference_memory": state.get("preference_memory", [])},
        })
        reflection["issues"] = list(dict.fromkeys([*issues, *reflection.get("issues", [])]))
        reflection["evidence_gaps"] = list(dict.fromkeys([*gaps, *reflection.get("evidence_gaps", [])]))
        reflection["target_sections"] = list(dict.fromkeys([*targets, *reflection.get("target_sections", [])]))
        if not reflection.get("retrieval_query"):
            reflection["retrieval_query"] = suggested_query

        revisions_left = state.get("revision_count", 0) < state.get("max_revisions", 1)
        retrievals_left = state.get("retrieval_round", 0) < state.get("max_retrieval_rounds", 3)
        if reflection["evidence_gaps"] and retrievals_left:
            reflection["decision"] = "retrieve_more"
        elif reflection["issues"] and revisions_left:
            reflection["decision"] = "revise"
        elif reflection["decision"] == "revise" and not revisions_left:
            reflection["decision"] = "finish"
            warnings.append("已达到自动修订轮数上限，保留问题供作者核对")
        elif reflection["decision"] == "retrieve_more" and not retrievals_left:
            reflection["decision"] = "revise" if revisions_left else "finish"
            warnings.append("已达到补充检索轮数上限，保留证据缺口供作者核对")

        report = {"issues": reflection["issues"], "warnings": list(dict.fromkeys(warnings)),
                  "passed": reflection["decision"] == "finish" and not reflection["issues"] and not warnings,
                  "character_count": actual, "revision_count": state.get("revision_count", 0),
                  "retrieval_round": state.get("retrieval_round", 0), "references": state["references"],
                  "citation_style": state["citation_style"], "reflection": reflection,
                  "scope": "智能体评审结构、字数、引用与证据覆盖；不代表事实核查或学术质量认证"}
        final = assemble_paper(state["title"], chapters, state["references"], state["citation_style"])
        get_stream_writer()({"kind": "reflection", "step": "quality_check",
                             "decision": reflection["decision"], "summary": reflection["summary"],
                             "issues": reflection["issues"], "evidence_gaps": reflection["evidence_gaps"],
                             "target_sections": reflection["target_sections"]})
        return {"quality_report": report, "final_paper": final,
                "requires_revision": reflection["decision"] != "finish", "last_reflection": reflection,
                "reflection_round": state.get("writing_round", 0), "outline": outline, "word_limit": word_limit,
                "current_step": "quality_check", "last_action": "quality_check"}

    async def _finalize(self, state):
        if not state.get("final_paper"):
            sections = flatten_outline(state["outline"])
            chapters = [{**section, "content": state["sections_content"].get(section["key"], "")}
                        for section in sections]
            final = assemble_paper(state["title"], chapters, state["references"], state["citation_style"])
        else:
            final = state["final_paper"]
        report = {**(state.get("quality_report") or {}), "references": state.get("references", []),
                  "citation_style": state.get("citation_style", "gbt")}
        content_changed = bool(state.get("is_followup") and state.get("writing_round", 1) > 1)
        if content_changed:
            report.pop("human_reviewed", None)
            report.pop("human_reviewed_at", None)
        if not state.get("auto_review", False):
            if content_changed:
                # Earlier findings describe an older version and must not be shown as current results.
                report.update(issues=[], warnings=[], passed=False,
                              review_status="not_run_after_change")
            report.update(auto_review_skipped=True,
                          scope="已按本论文偏好跳过智能体自动核对；仍需作者确认事实、引用和实验内容")
        return {"final_paper": final, "quality_report": report,
                "current_step": "finalize", "last_action": "finalize"}
