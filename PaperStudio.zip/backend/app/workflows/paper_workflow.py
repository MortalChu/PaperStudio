import asyncio
import contextlib
import logging
import time
from uuid import uuid4
from fastapi import HTTPException
from sqlalchemy import update
from langgraph.types import Command
from app.models.paper import AgentMessage, Paper, PaperRun
from app.services.paper_service import save_version, sync_outline, attach_references
from app.utils.helpers import sse, failure_diagnostic
from app.models.user import User, utcnow
from app.services.agent_service import merge_preferences, normalize_preferences, effective_preferences, load_effective_preferences

STEP_LABELS = {"analyze_topic": "分析选题", "recommend_topic": "推荐选题", "confirm_topic": "确认选题",
               "plan_next": "自主规划下一步",
               "generate_outline": "依据文献生成大纲", "confirm_outline": "确认大纲", "add_references": "检索共享文献库",
               "confirm_review": "询问是否自动核对", "user_intervention": "立即处理用户新要求",
               "refresh_references": "按确认后的题目检索文献",
               "write_sections": "分配写作章节", "write_section": "生成章节正文", "polish_paper": "润色正文",
               "quality_check": "反思内容与证据", "finalize": "汇总最终初稿",
               "save_result": "保存生成结果", "workflow": "启动或恢复工作流"}


class PaperWorkflow:
    """Single backend worker, durable checkpoints and background jobs independent of SSE clients."""
    def __init__(self, graph, sessions):
        self.graph = graph.graph
        self.settings = graph.settings
        self.sessions = sessions
        self.metrics = graph.metrics
        self.tasks = {}
        self.live_events = {}
        self.pause_requests = set()
        self.resume_lock = asyncio.Lock()
        graph.live_event_sink = self._record

    def config(self, run_id):
        return {"configurable": {"thread_id": run_id}, "recursion_limit": 100,
                "max_concurrency": 8}

    async def recover(self):
        async with self.sessions() as db:
            await db.execute(update(PaperRun).where(PaperRun.status == "running").values(
                status="interrupted", error="后端已重启，可从最近检查点继续"))
            await db.commit()

    async def close(self):
        tasks = list(self.tasks.values())
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    async def start(self, paper_id, owner_id, options):
        from app.services.paper_service import owned_paper
        run_id = str(uuid4())
        async with self.sessions() as db:
            paper = await owned_paper(db, paper_id, owner_id)
            confirm_overwrite = bool(options.pop("confirm_overwrite", False))
            if paper.final_paper and not confirm_overwrite:
                raise HTTPException(422, "当前任务已有完整初稿。重新生成会在成功后替换当前大纲、章节和全文；请明确确认重新生成。原稿会自动保存到历史版本。")
            claim = await db.execute(update(Paper).where(Paper.id == paper_id, Paper.active_run_id.is_(None))
                                      .values(active_run_id=run_id, finished_at=None))
            if claim.rowcount != 1:
                raise HTTPException(409, "该论文已有任务，请继续或取消现有任务")
            await save_version(db, paper, "整篇生成前自动备份")
            state = {key: getattr(paper, key) for key in ("title", "topic", "keywords", "paper_type", "word_limit", "requirements", "outline")}
            state.update(options)
            account = await db.get(User, owner_id)
            preferences = effective_preferences(account.preferences if account else {}, paper.agent_preferences)
            state.update(run_id=run_id, paper_id=paper.id, owner_id=owner_id,
                         sections_content={}, references=[], revision_count=0,
                         outline_confirmed=False, references_stale=False, agent_step=0,
                         max_agent_steps=self.settings.MAX_AGENT_STEPS, agent_decisions=[],
                         writing_round=0, polished_round=0, reflection_round=0,
                         retrieval_round=0, max_retrieval_rounds=self.settings.MAX_RETRIEVAL_ROUNDS,
                         last_reflection={}, last_action="", planned_retrieval_query="",
                         auto_review=preferences["auto_review"], writing_style=preferences["writing_style"],
                         persistent_instructions=preferences["persistent_instructions"],
                         preference_memory=preferences["preference_memory"],
                         active_user_message_id=0, active_user_action="",
                         user_instruction="", user_target_sections=[], polish_targets=[],
                         pending_section_keys=[], is_followup=False)
            run = PaperRun(id=run_id, paper_id=paper_id, status="running", options={"initial_state": state}, events=[])
            db.add(run)
            paper.status = "writing"
            await db.commit()
        self.live_events[run_id] = []
        self.tasks[run_id] = asyncio.create_task(self._execute(run_id, state))
        return run_id

    async def start_agent_run(self, paper_id, owner_id):
        """Start an incremental conversational run from the current persisted manuscript."""
        from app.services.paper_service import owned_paper
        run_id = str(uuid4())
        async with self.sessions() as db:
            paper = await owned_paper(db, paper_id, owner_id)
            if not paper.final_paper or not paper.outline or not paper.chapters:
                raise HTTPException(422, "当前还没有可增量修改的论文正文；要求已记录，可先启动完整写作流程")
            claim = await db.execute(update(Paper).where(Paper.id == paper_id, Paper.active_run_id.is_(None))
                                      .values(active_run_id=run_id, finished_at=None))
            if claim.rowcount != 1:
                raise HTTPException(409, "该论文已有任务，请直接在对话中向当前任务发送新要求")
            await save_version(db, paper, "对话修改前自动备份")
            account = await db.get(User, owner_id)
            preferences = effective_preferences(account.preferences if account else {}, paper.agent_preferences)
            report = paper.quality_report or {}
            references = list(report.get("references") or [])
            sections_content = {chapter.section_key: chapter.content for chapter in paper.chapters}
            citation_style = report.get("citation_style", "gbt")
            state = {key: getattr(paper, key) for key in
                     ("title", "topic", "keywords", "paper_type", "word_limit", "requirements", "outline")}
            state.update(run_id=run_id, paper_id=paper.id, owner_id=owner_id,
                         is_topic_clear=True, review_outline=False,
                         citation_style=citation_style, max_revisions=2, sections_content=sections_content,
                         references=references, formatted_references="", revision_count=0,
                         outline_confirmed=True, references_stale=False, agent_step=0,
                         max_agent_steps=self.settings.MAX_AGENT_STEPS, agent_decisions=[],
                         writing_round=1, polished_round=1, reflection_round=1,
                         retrieval_round=report.get("retrieval_round", 0),
                         max_retrieval_rounds=self.settings.MAX_RETRIEVAL_ROUNDS,
                         last_reflection={"decision": "finish", "summary": "当前稿件已载入。"},
                         last_action="", planned_retrieval_query="", final_paper=paper.final_paper,
                         quality_report=report, auto_review=preferences["auto_review"],
                         writing_style=preferences["writing_style"],
                         persistent_instructions=preferences["persistent_instructions"],
                         preference_memory=preferences["preference_memory"],
                         active_user_message_id=0, active_user_action="",
                         user_instruction="", user_target_sections=[], polish_targets=[],
                         pending_section_keys=[], is_followup=True)
            run = PaperRun(id=run_id, paper_id=paper_id, status="running",
                           options={"kind": "agent_followup", "initial_state": state}, events=[])
            db.add(run)
            paper.status = "writing"
            await db.commit()
        self.live_events[run_id] = []
        self.tasks[run_id] = asyncio.create_task(self._execute(run_id, state))
        return run_id

    async def _record(self, run_id, event):
        events = self.live_events[run_id]
        event = {"id": len(events) + 1, "time": utcnow().isoformat(), **event}
        events.append(event)
        if event.get("kind") != "token":
            logging.getLogger(__name__).info("run_id=%s event=%s step=%s section=%s diagnostic_id=%s",
                run_id, event.get("kind", ""), event.get("step", ""), event.get("section_key", ""),
                (event.get("diagnostic") or {}).get("diagnostic_id", ""))

    async def _flush(self, run_id, status=None, error=""):
        async with self.sessions() as db:
            run = await db.get(PaperRun, run_id)
            if not run:
                return
            run.events = list(self.live_events[run_id])
            if status:
                run.status = status
                run.error = error
            await db.commit()

    async def _execute(self, run_id, command):
        step = "workflow"
        started = time.perf_counter()
        outcome = "completed"
        paper_id = command.get("paper_id") if isinstance(command, dict) else None
        metric_details = {}
        try:
            await self._record(run_id, {"kind": "progress", "step": "start", "message": "任务已开始"})
            async for mode, chunk in self.graph.astream(command, self.config(run_id), stream_mode=["updates", "custom"]):
                if mode == "custom":
                    if chunk.get("kind") == "step_start":
                        step = chunk["step"]
                        chunk = {**chunk, "message": "开始：" + STEP_LABELS.get(step, step)}
                    await self._record(run_id, chunk)
                    if chunk.get("kind") == "step_start":
                        await self._flush(run_id)
                else:
                    for node, result in chunk.items():
                        if node == "__interrupt__":
                            continue
                        await self._record(run_id, {"kind": "progress", "step": node,
                            "message": "完成：" + STEP_LABELS.get(node, node),
                            "section_keys": list((result or {}).get("sections_content", {}))})
                    await self._flush(run_id)
            step = "save_result"
            snapshot = await self.graph.aget_state(self.config(run_id))
            state = snapshot.values
            metric_details = {"agent_steps": state.get("agent_step", 0),
                              "retrieval_rounds": state.get("retrieval_round", 0),
                              "revision_count": state.get("revision_count", 0),
                              "generated_characters": len(state.get("final_paper", ""))}
            pending = [i.value for task in snapshot.tasks for i in task.interrupts]
            async with self.sessions() as db:
                run = await db.get(PaperRun, run_id)
                paper_id = run.paper_id
                paper = await db.get(Paper, run.paper_id)
                paper.title = state.get("title", paper.title)
                await attach_references(db, paper, state.get("references", []))
                if state.get("outline"):
                    if paper.outline != state["outline"]:
                        paper.outline_revision += 1
                    await sync_outline(db, paper, state["outline"], state.get("sections_content") or None)
                if pending:
                    outcome = "waiting_for_human"
                    if state.get("references"):
                        paper.quality_report = {**(paper.quality_report or {}),
                            "retrieval": {"status": "matched", "count": len(state["references"]),
                                "references": state["references"], "message": "已从共享库检索文献，等待大纲确认"}}
                        if not paper.final_paper:
                            paper.quality_report = {**paper.quality_report, "references": state["references"]}
                    paper.status = "outline"
                    run.status = "waiting"
                    await self._record(run_id, {"kind": "interrupt", "requests": pending})
                else:
                    paper.final_paper = state.get("final_paper", "")
                    paper.quality_report = state.get("quality_report", {})
                    # 自动结构检查不能代替作者核对事实、引用和实验结果。
                    paper.status = "review"
                    paper.active_run_id = None
                    paper.finished_at = utcnow()
                    for chapter in paper.chapters:
                        if chapter.title.strip() == "摘要":
                            paper.abstract = chapter.content
                    run.status = "completed"
                    label = "Agent 增量修改完成" if run.options.get("kind") == "agent_followup" else "整篇生成完成"
                    await save_version(db, paper, label)
                    await self._record(run_id, {"kind": "done", "paper_id": paper.id, "status": paper.status})
                run.events = list(self.live_events[run_id])
                await db.commit()
        except asyncio.CancelledError:
            if run_id in self.pause_requests:
                outcome = "paused"
                await self._record(run_id, {"kind": "paused", "step": step,
                    "message": "任务已暂停；继续后将从最近检查点恢复，当前未完成步骤会重新执行"})
                await self._flush(run_id, "paused")
            else:
                outcome = "interrupted"
                await self._record(run_id, {"kind": "interrupted", "step": step,
                    "message": "任务已中断，可从检查点继续"})
                await self._flush(run_id, "interrupted", "任务已中断")
            raise
        except Exception as exc:
            outcome = "failed"
            diagnostic = failure_diagnostic(exc, self.settings, run_id=run_id, step=step)
            diagnostic["step_label"] = STEP_LABELS.get(diagnostic["step"], diagnostic["step"])
            message = diagnostic["step_label"] + "失败：" + diagnostic["message"]
            await self._record(run_id, {"kind": "error", "step": diagnostic["step"],
                "message": message, "diagnostic": diagnostic})
            try:
                await self._flush(run_id, "failed", message)
                async with self.sessions() as db:
                    failed_run = await db.get(PaperRun, run_id)
                    failed_paper = await db.get(Paper, failed_run.paper_id) if failed_run else None
                    if failed_paper:
                        failed_paper.finished_at = utcnow()
                        await db.commit()
            except Exception as persistence_error:
                # 数据库本身异常时仍保留文件日志中的原始诊断编号。
                failure_diagnostic(persistence_error, self.settings, run_id=run_id, step="save_result")
        finally:
            if self.metrics:
                self.metrics.record("workflow_run", run_id=run_id, paper_id=paper_id, status=outcome,
                                    last_step=step,
                                    duration_ms=round((time.perf_counter() - started) * 1000, 3),
                                    **metric_details)
            self.tasks.pop(run_id, None)
            self.live_events.pop(run_id, None)
            self.pause_requests.discard(run_id)

    async def resume(self, run_id, payload):
        async with self.resume_lock:
            if run_id in self.tasks:
                raise HTTPException(409, "任务正在运行")
            async with self.sessions() as db:
                run = await db.get(PaperRun, run_id)
                if run.status not in ("waiting", "paused", "failed", "interrupted"):
                    raise HTTPException(409, "当前任务不能继续")
                snapshot = await self.graph.aget_state(self.config(run_id))
                pending = [i.value for task in snapshot.tasks for i in task.interrupts]
                if pending:
                    kind = pending[0]["kind"]
                    if kind == "topic" and not payload.get("title"):
                        raise HTTPException(422, "请提供确认后的题目")
                    if kind == "outline" and not payload.get("approved", True):
                        raise HTTPException(422, "请确认大纲，或取消任务")
                    if kind == "review_preference" and payload.get("auto_review") is None:
                        raise HTTPException(422, "请选择是否允许 Agent 自动核对")
                    if kind == "outline" and payload.get("outline"):
                        paper = await db.get(Paper, run.paper_id)
                        await sync_outline(db, paper, payload["outline"])
                        paper.title = payload["outline"]["title"]
                        paper.status = "writing"
                    command = Command(resume=payload)
                else:
                    command = None if snapshot.values else run.options["initial_state"]
                self.live_events[run_id] = list(run.events)
                run.status = "running"
                run.error = ""
                paper = await db.get(Paper, run.paper_id)
                if paper:
                    paper.finished_at = None
                await db.commit()
            self.tasks[run_id] = asyncio.create_task(self._execute(run_id, command))

    async def pause(self, run_id):
        """Cancel the in-flight node while retaining the run and its durable checkpoint."""
        async with self.resume_lock:
            async with self.sessions() as db:
                run = await db.get(PaperRun, run_id)
                if not run:
                    raise HTTPException(404, "任务不存在")
                if run.status == "paused":
                    return True
                if run.status == "waiting":
                    run.status = "paused"
                    await db.commit()
                    return True
                if run.status != "running":
                    raise HTTPException(409, "只有正在生成的任务可以暂停")
                run.status = "pausing"
                await db.commit()
            task = self.tasks.get(run_id)
            if not task:
                async with self.sessions() as db:
                    run = await db.get(PaperRun, run_id)
                    run.status = "paused"
                    await db.commit()
                return True
            self.pause_requests.add(run_id)
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
            async with self.sessions() as db:
                run = await db.get(PaperRun, run_id)
                return run.status == "paused"

    async def steer(self, run_id):
        """Interrupt the current model call and route the durable user request immediately to the planner."""
        async with self.sessions() as db:
            run = await db.get(PaperRun, run_id)
            if not run:
                raise HTTPException(404, "任务不存在")
            status = run.status
        if status not in ("running", "paused", "failed", "interrupted"):
            raise HTTPException(409, "当前任务正在等待回答或已经结束，不能即时改道")
        if status == "running":
            await self.pause(run_id)
        async with self.resume_lock:
            if run_id in self.tasks:
                raise HTTPException(409, "任务正在切换到用户新要求，请稍后刷新")
            snapshot = await self.graph.aget_state(self.config(run_id))
            pending = [item.value for task in snapshot.tasks for item in task.interrupts]
            if pending:
                raise HTTPException(409, "当前 Agent 正在等待你的回答，请先回答该问题")
            await self.graph.aupdate_state(self.config(run_id), {
                "current_step": "user_intervention", "last_action": "user_intervention",
                "pending_section_keys": []}, as_node="user_intervention")
            async with self.sessions() as db:
                run = await db.get(PaperRun, run_id)
                if run.status not in ("paused", "failed", "interrupted"):
                    raise HTTPException(409, "当前任务不能接收即时要求")
                self.live_events[run_id] = list(run.events)
                await self._record(run_id, {"kind": "user_intervention", "step": "user_intervention",
                    "message": "收到用户新要求，已中断未完成步骤并立即重新规划"})
                run.status = "running"
                run.error = ""
                run.events = list(self.live_events[run_id])
                paper = await db.get(Paper, run.paper_id)
                if paper:
                    paper.finished_at = None
                await db.commit()
            self.tasks[run_id] = asyncio.create_task(self._execute(run_id, None))
        return True

    async def cancel(self, run_id):
        async with self.resume_lock:
            task = self.tasks.get(run_id)
            if task:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task
            async with self.sessions() as db:
                run = await db.get(PaperRun, run_id)
                if not run:
                    raise HTTPException(404, "任务不存在")
                if run.status == "cancelled":
                    return
                if run.status == "completed":
                    raise HTTPException(409, "任务已完成")
                run.status = "cancelled"
                run.events = [*run.events, {"id": len(run.events) + 1, "kind": "cancelled", "message": "任务已取消"}]
                paper = await db.get(Paper, run.paper_id)
                if paper.active_run_id == run_id:
                    paper.active_run_id = None
                    paper.status = "review" if paper.final_paper else "draft"
                paper.finished_at = utcnow()
                await db.execute(update(AgentMessage).where(
                    AgentMessage.paper_id == run.paper_id, AgentMessage.status == "executing")
                    .values(status="pending", completed_at=None))
                await db.commit()

    async def status(self, run_id):
        async with self.sessions() as db:
            run = await db.get(PaperRun, run_id)
            try:
                snapshot = await self.graph.aget_state(self.config(run_id))
            except Exception:
                snapshot = None
            records = self.live_events.get(run_id, run.events)
            diagnostic = next((e["diagnostic"] for e in reversed(records)
                if e.get("kind") == "error" and e.get("diagnostic")), None) if run.status == "failed" else None
            requests = [i.value for task in snapshot.tasks for i in task.interrupts] if snapshot else []
            if requests and requests[0].get("kind") == "outline":
                paper = await db.get(Paper, run.paper_id)
                if paper and paper.outline:
                    requests = [{**item, "outline": paper.outline} if item.get("kind") == "outline" else item
                                for item in requests]
            return {"id": run.id, "paper_id": run.paper_id, "status": run.status, "error": run.error,
                    "step": snapshot.values.get("current_step", "init") if snapshot else "unknown",
                    "checkpoint_readable": snapshot is not None, "diagnostic": diagnostic,
                    "requests": requests,
                    "events": [e for e in records if e.get("kind") != "token"][-500:]}

    async def diagnostics(self, run_id):
        status = await self.status(run_id)
        async with self.sessions() as db:
            run = await db.get(PaperRun, run_id)
            records = self.live_events.get(run_id, run.events)
            fields = {"id", "time", "kind", "step", "section_key", "section_keys", "message", "diagnostic",
                      "action", "rationale", "available_actions", "guardrail_applied", "decision", "summary",
                      "issues", "evidence_gaps", "target_sections"}
            events = [{k: v for k, v in e.items() if k in fields} for e in records if e.get("kind") != "token"]
        return {"run_id": run_id, "paper_id": status["paper_id"], "status": status["status"],
            "error": status["error"], "diagnostic": status["diagnostic"],
            "checkpoint_readable": status["checkpoint_readable"], "events": events,
            "note": "包含执行步骤与失败诊断，不包含生成正文、模型提示词或 API 密钥。旧版未记录的诊断不能追溯补全。"}

    async def event_snapshot(self, run_id, after=0, limit=1000):
        """Return a bounded, non-streaming event batch for responsive polling UIs."""
        async with self.sessions() as db:
            run = await db.get(PaperRun, run_id)
            if not run:
                raise HTTPException(404, "任务不存在")
            records = list(self.live_events.get(run_id, run.events))
            available = [item for item in records if item["id"] > after]
            events = available[:limit]
            last_event_id = events[-1]["id"] if events else after
            return {"events": events, "last_event_id": last_event_id,
                    "has_more": len(available) > len(events), "status": run.status}

    async def stream(self, run_id, after=0):
        idle = 0
        while True:
            async with self.sessions() as db:
                run = await db.get(PaperRun, run_id)
                if run is None:
                    yield sse("error", {"message": "任务不存在"})
                    return
                events = list(self.live_events.get(run_id, run.events))
                status = run.status
            for item in events:
                if item["id"] > after:
                    yield sse(item["kind"], item, item["id"])
                    after = item["id"]
            if status != "running":
                yield sse("end", {"status": status})
                return
            idle += 1
            if idle % 25 == 0:
                yield ": heartbeat\n\n"
            await asyncio.sleep(0.4)
