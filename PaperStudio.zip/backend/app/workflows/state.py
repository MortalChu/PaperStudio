import operator
from typing import Annotated, TypedDict


def merge_sections(left: dict, right: dict) -> dict:
    return {**left, **right}


class PaperState(TypedDict, total=False):
    run_id: str
    paper_id: int
    owner_id: int
    title: str
    topic: str
    keywords: str
    paper_type: str
    word_limit: int
    requirements: str
    is_topic_clear: bool
    review_outline: bool
    current_step: str
    last_action: str
    next_action: str
    planned_retrieval_query: str
    retrieval_query_plan: dict
    agent_step: int
    max_agent_steps: int
    agent_decisions: Annotated[list[dict], operator.add]
    topics: list[dict]
    outline: dict
    outline_confirmed: bool
    references_stale: bool
    section: dict
    sections_content: Annotated[dict, merge_sections]
    references: list[dict]
    formatted_references: str
    citation_style: str
    revision_count: int
    max_revisions: int
    writing_round: int
    polished_round: int
    reflection_round: int
    retrieval_round: int
    max_retrieval_rounds: int
    last_reflection: dict
    requires_revision: bool
    quality_report: dict
    final_paper: str
    auto_review: bool | None
    writing_style: str
    persistent_instructions: str
    preference_memory: list[str]
    active_user_message_id: int
    active_user_action: str
    user_instruction: str
    user_target_sections: list[str]
    polish_targets: list[str]
    is_followup: bool
    pending_section_keys: list[str]
