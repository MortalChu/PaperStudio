from pathlib import Path
import streamlit as st
from src.components.common import Header, Sidebar
from src.router.index import render_route
from src.api.request import APIError
from src.stores.user import logout


def render():
    css = (Path(__file__).parent / "styles/main.css").read_text(encoding="utf-8")
    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)
    Header.render()
    Sidebar.render()
    try:
        render_route()
    except APIError as exc:
        if exc.status == 401 and exc.path not in ("/api/auth/login", "/api/auth/token", "/api/auth/register"):
            logout()
            st.session_state.auth_notice = str(exc) if exc.auth_error else "请重新登录；尚未注册时请先创建账号。"
            st.rerun()
        else:
            st.error(str(exc))
            if exc.diagnostic:
                st.write(exc.diagnostic.get("action", ""))
                with st.expander("查看错误诊断", expanded=True):
                    st.json(exc.diagnostic)
    st.divider()
    st.caption("AI 辅助写作 · 内容与引用需由作者核对")
