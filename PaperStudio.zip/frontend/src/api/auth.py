from src.api.request import request


def login(username, password):
    return request("POST", "/api/auth/login", json={"username": username, "password": password})


def register(username, email, password):
    return request("POST", "/api/auth/register", json={"username": username, "email": email, "password": password})
