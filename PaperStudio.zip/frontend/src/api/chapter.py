from src.api.request import request, stream


def update(chapter_id, data):
    return request("PUT", f"/api/chapters/{chapter_id}", json=data)


def generate(chapter_id):
    return stream(f"/api/chapters/{chapter_id}/stream-generate", method="POST")


def polish(chapter_id, focus):
    return request("POST", f"/api/chapters/{chapter_id}/polish", json={"focus": focus})
