from src.api.request import request, stream


def list_papers(**params):
    return request("GET", "/api/papers/", params={"limit": 200, **params})


def trash():
    return request("GET", "/api/papers/trash", params={"limit": 200})


def restore_from_trash(paper_id):
    return request("POST", f"/api/papers/trash/{paper_id}/restore")


def purge_from_trash(paper_id):
    return request("DELETE", f"/api/papers/trash/{paper_id}/purge")


def empty_trash():
    return request("DELETE", "/api/papers/trash")


def remove(paper_id):
    return request("DELETE", f"/api/papers/{paper_id}")


def get(paper_id):
    return request("GET", f"/api/papers/{paper_id}")


def create(data):
    return request("POST", "/api/papers/", json=data)


def update(paper_id, data):
    return request("PUT", f"/api/papers/{paper_id}", json=data)


def save_outline(paper_id, outline, expected_revision, source="manual"):
    return request("PUT", f"/api/papers/{paper_id}/outline",
                   json={"outline": outline, "expected_revision": expected_revision, "source": source})


def update_word_limit(paper_id, word_limit):
    return request("PUT", f"/api/papers/{paper_id}/word-limit", json={"word_limit": word_limit}, timeout=45)


def complete_review(paper_id):
    return request("POST", f"/api/papers/{paper_id}/complete-review")


def generate(paper_id, options):
    return request("POST", f"/api/papers/{paper_id}/generate", json=options)


def events(paper_id, run_id):
    return stream(f"/api/papers/{paper_id}/runs/{run_id}/events")


def agent_messages(paper_id):
    return request("GET", f"/api/agent/{paper_id}/messages", params={"limit": 200})


def agent_chat(paper_id, message):
    return request("POST", f"/api/agent/{paper_id}/chat", json={"message": message}, timeout=300)


def agent_chat_stream(paper_id, message):
    return stream(f"/api/agent/{paper_id}/chat/stream", method="POST", body={"message": message})


def submit_agent_turn(paper_id, message):
    return request("POST", f"/api/agent/paper/{paper_id}/turns", json={"message": message})


def agent_turn(paper_id, turn_id):
    return request("GET", f"/api/agent/paper/{paper_id}/turns/{turn_id}")


def global_sessions():
    return request("GET", "/api/agent/global/sessions")


def global_capabilities():
    return request("GET", "/api/agent/global/capabilities")


def global_messages(session_id):
    return request("GET", "/api/agent/global/messages",
                   params={"session_id": session_id, "limit": 300})


def delete_global_session(session_id):
    return request("DELETE", f"/api/agent/global/sessions/{session_id}")


def submit_global_turn(message, session_id=None):
    return request("POST", "/api/agent/global/turns",
                   json={"message": message, "session_id": session_id})


def global_turn(turn_id):
    return request("GET", f"/api/agent/global/turns/{turn_id}")


def agent_preferences(paper_id):
    return request("GET", f"/api/agent/{paper_id}/preferences")


def update_agent_preferences(paper_id, values):
    return request("PUT", f"/api/agent/{paper_id}/preferences", json=values)
