from src.api.request import request


def list_references(paper_id=None, query="", skip=0, limit=50, status="all"):
    params = {"query": query, "skip": skip, "limit": limit, "status": status}
    if paper_id is not None:
        params["paper_id"] = paper_id
    return request("GET", "/api/references/", params=params)


def search(paper_id, query, top_k):
    params = {"query": query, "top_k": top_k}
    if paper_id is not None:
        params["paper_id"] = paper_id
    return request("GET", "/api/references/search", params=params)
