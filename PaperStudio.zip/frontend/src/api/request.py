import json
import os
import httpx
import streamlit as st

BASE_URL = os.getenv("API_BASE_URL", "http://127.0.0.1:8000").rstrip("/")


class APIError(Exception):
    def __init__(self, message, status=0, path="", auth_error="", diagnostic=None):
        self.status = status
        self.path = path
        self.auth_error = auth_error
        self.diagnostic = diagnostic
        super().__init__(message)


def headers():
    token = st.session_state.get("token")
    return {"Authorization": f"Bearer {token}"} if token else {}


def check(response):
    if response.is_error:
        diagnostic = None
        try:
            payload = response.json()
            detail = payload.get("detail", "请求失败")
            diagnostic = payload.get("diagnostic")
            if isinstance(detail, list):
                detail = "；".join(f"{'.'.join(map(str, d.get('loc', [])))}: {d.get('msg', '')}" for d in detail)
        except (ValueError, AttributeError):
            detail = "服务暂时无法完成请求，请稍后重试"
        raise APIError(str(detail), response.status_code, response.request.url.path,
                       response.headers.get("X-Auth-Error", ""), diagnostic)


def request(method, path, **kwargs):
    try:
        with httpx.Client(base_url=BASE_URL, headers=headers(), timeout=300) as client:
            response = client.request(method, path, **kwargs)
        check(response)
        return response.json() if response.content else None
    except httpx.ConnectTimeout as exc:
        raise APIError("连接后端超时，请检查后端服务地址、服务状态及网络。", path=path) from exc
    except httpx.TimeoutException as exc:
        if method.upper() == "GET":
            message = "读取后端结果超时，当前未能获取最新状态；这不表示后台任务已失败。"
        elif path.startswith("/api/references"):
            message = "未能及时收到提交回执，请刷新共享文献库的处理任务列表确认是否已接收，再决定是否重试。"
        else:
            message = "请求等待超时，后台操作可能仍在进行，请刷新查看结果，避免反复提交。"
        raise APIError(message, path=path) from exc
    except httpx.HTTPError as exc:
        raise APIError("无法连接后端，请确认服务已启动") from exc


def download(path):
    try:
        response = httpx.get(BASE_URL + path, headers=headers(), timeout=60)
        check(response)
        return response.content
    except httpx.HTTPError as exc:
        raise APIError("下载失败，请检查后端连接") from exc


def stream(path, method="GET", body=None):
    try:
        with httpx.Client(base_url=BASE_URL, headers=headers(), timeout=httpx.Timeout(600, connect=10)) as client:
            options = {"json": body} if body is not None else {}
            with client.stream(method, path, **options) as response:
                if response.is_error:
                    response.read()
                    check(response)
                data_lines = []
                for line in response.iter_lines():
                    if line.startswith("data:"):
                        data_lines.append(line[5:].lstrip())
                    elif not line and data_lines:
                        yield json.loads("\n".join(data_lines))
                        data_lines = []
    except httpx.HTTPError as exc:
        message = ("Agent 回复连接已断开；已经提交的要求仍会在后台处理，可刷新对话查看结果"
                   if path.startswith("/api/agent/") else
                   "进度连接已断开；整篇生成任务仍在后台，可刷新后继续查看")
        raise APIError(message, path=path) from exc
