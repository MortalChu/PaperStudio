import streamlit as st
from src.stores.editor import revision_key


def render(content, prefix, label="正文", height=400):
    return st.text_area(label, value=content, height=height, key=revision_key(prefix, content))
