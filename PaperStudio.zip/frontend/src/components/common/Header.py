import streamlit as st


def render():
    st.markdown('<div class="brand-bar"><span class="brand-mark">P</span><span class="brand-title">AI 论文写作系统</span>'
                '<span class="brand-sub">把研究思路，写成清晰的论文。</span></div>', unsafe_allow_html=True)
