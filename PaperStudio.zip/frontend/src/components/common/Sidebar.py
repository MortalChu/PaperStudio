import streamlit as st
from src.router.index import navigate
from src.stores.user import logged_in, logout
from src.api.request import request, APIError


def render():
    with st.sidebar:
        st.markdown("### PAPER STUDIO")
        st.caption("你的学术写作空间")
        st.divider()
        for label, icon in [("首页", ":material/home:"), ("Agent 助手", ":material/smart_toy:"),
                            ("我的论文", ":material/article:"), ("新建论文", ":material/add_circle:"),
                            ("写作工作台", ":material/edit_document:"),
                            ("文献管理", ":material/library_books:"), ("回收站", ":material/delete:"), ("记忆与偏好", ":material/psychology:")]:
            display_label = {"文献管理": "共享文献库", "新建论文": "新建写作任务"}.get(label, label)
            st.button(display_label, icon=icon, use_container_width=True, on_click=navigate, args=(label,),
                      type="primary" if st.session_state.get("route", "首页") == label else "secondary")
        st.divider()
        if logged_in():
            st.write(st.session_state.get("user", {}).get("username", "已登录"))
            st.button("退出登录", on_click=logout, use_container_width=True)
        else:
            st.button("登录 / 注册", on_click=navigate, args=("登录",), use_container_width=True)
        try:
            health = request("GET", "/health")
            if health["llm_mode"] == "demo":
                st.caption("写作模型：演示模板")
            else:
                st.caption(f"写作模型：{health['llm_mode']} · {health.get('llm_model', '')}")
            if health["embedding_mode"] == "hash":
                st.caption("文献索引：离线词面特征")
            else:
                st.caption(f"文献索引：语义向量 · {health.get('embedding_model', '')}")
            with st.expander("模型运行状态与切换说明"):
                if health["llm_mode"] == "demo":
                    st.info("后端目前使用演示模板生成内容，未调用真实写作模型。这是全站配置，注册或登录不会切换模型。")
                    st.caption("正式写作：修改后端 .env 的 LLM_PROVIDER，填写所选提供商的密钥和模型名，然后重启后端。")
                else:
                    st.caption("聊天模型参数已填写；尚未检测连接。" if health["llm_configured"] else "聊天模型密钥尚未配置。")
                if health["embedding_mode"] == "hash":
                    st.caption("索引采用无需 API 密钥的词面特征。要使用语义检索，请单独配置 EMBEDDING_PROVIDER、向量模型和向量服务密钥。")
                else:
                    st.caption("向量服务密钥已填写；索引能否成功以实际处理结果为准。" if health.get("embedding_configured") else "向量服务密钥尚未配置。")
        except APIError:
            st.caption("后端暂未连接")
