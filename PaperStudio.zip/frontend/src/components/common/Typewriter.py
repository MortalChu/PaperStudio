from pathlib import Path
import streamlit as st
import streamlit.components.v1 as components
from src.api.request import request, APIError

_component = components.declare_component("paper_typewriter_v8", path=str(Path(__file__).with_name("typewriter")))


def render(text, identity, complete=False, phase="", color=None, history=False):
    text = text or ""
    ack = _component(text=text, identity=identity, complete=complete, phase=phase,
                     color=color, history=history, key="typewriter_" + identity, default=None)
    if ack and identity.startswith(("global_", "paper_")):
        stage = "drained" if ack.get("drained") else "first_visible"
        metric_key = f"display_receipt_{identity}_{stage}"
        if not st.session_state.get(metric_key):
            try:
                request("POST", "/api/agent/turns/" + identity.split("_", 1)[1] + "/display",
                        json={"phase": stage}, timeout=3)
            except APIError:
                pass  # Telemetry cannot block a completed reply or cause endless UI reruns.
            st.session_state[metric_key] = True
    return bool(ack and ack.get("drained") and ack.get("length") == len(text.encode("utf-16-le")) // 2)
