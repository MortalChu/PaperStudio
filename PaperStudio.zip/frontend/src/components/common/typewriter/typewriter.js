/* Streamlit v1 protocol; each render supplies the latest incremental snapshot. */
const output = document.getElementById('text'), phase = document.getElementById('phase');
let target='', shown='', terminal=false, identity='', completion=null, timer=null, color='#B45309';
let firstShown=false;
const send=(type,extra={})=>parent.postMessage({isStreamlitMessage:true,type,...extra},'*');
function safeMarkdown(text) {
  const doc=new DOMParser().parseFromString(marked.parse(text), 'text/html');
  const allowed=new Set(['P','BR','STRONG','EM','CODE','PRE','UL','OL','LI','H1','H2','H3','H4','H5','H6','BLOCKQUOTE','HR','TABLE','THEAD','TBODY','TR','TD','TH','A','DEL']);
  function clean(node) {
    for (const child of [...node.children]) {
      if (!allowed.has(child.tagName)) {child.replaceWith(document.createTextNode(child.textContent));continue;}
      const href=child.getAttribute('href');
      for (const attr of [...child.attributes]) child.removeAttribute(attr.name);
      if(child.tagName==='A' && href && /^(https?:\/\/|#)/i.test(href)) {
        child.setAttribute('href',href);child.setAttribute('target','_blank');child.setAttribute('rel','noopener noreferrer');
      }
      clean(child);
    }
  }
  clean(doc.body);
  const walker=doc.createTreeWalker(doc.body,NodeFilter.SHOW_TEXT), nodes=[];
  while(walker.nextNode()) nodes.push(walker.currentNode);
  for(const node of nodes) {
    if(!/【待验证】|【待补充文献】/.test(node.textContent)) continue;
    const fragment=doc.createDocumentFragment();
    for(const part of node.textContent.split(/(【待验证】|【待补充文献】)/)) {
      const el=doc.createElement('span'); el.textContent=part;
      if(/^【/.test(part)) {el.style.color=color;el.style.fontWeight='700';}
      fragment.append(el);
    }
    node.replaceWith(fragment);
  }
  return doc.body.innerHTML;
}
function resize(){send('streamlit:setFrameHeight',{height:Math.ceil(document.documentElement.scrollHeight)});}
function render(){output.innerHTML=safeMarkdown(shown);phase.style.display=shown?'none':'block';resize();}
function tick(){
  timer=null;
  if(shown.length<target.length) {
    // Unicode code points: never split a surrogate pair. Exactly one point is added per tick.
    shown+=String.fromCodePoint(target.codePointAt(shown.length));
    render();
    if(!firstShown){firstShown=true;send('streamlit:setComponentValue',{value:{first_visible:true,at:Date.now()},dataType:'json'});}
    timer=setTimeout(tick,16);
  } else if(terminal && completion!==target) {
    completion=target;
    send('streamlit:setComponentValue',{value:{drained:true,length:target.length,at:Date.now()},dataType:'json'});
  }
}
window.addEventListener('message',event=>{
  if(event.source!==parent || event.data.type!=='streamlit:render')return;
  const a=event.data.args;
  if(identity!==a.identity){identity=a.identity;shown='';target='';completion=null;firstShown=false;}
  const next=String(a.text||'');
  if(!next.startsWith(shown)) {
    // A revised attempt gets its own identity; tolerate a corrected prefix without duplicate text.
    let i=0;while(i<shown.length && shown[i]===next[i])i++;shown=shown.slice(0,i);
  }
  target=next; terminal=!!a.complete; color=/^#[0-9a-f]{6}$/i.test(a.color)?a.color:'#B45309';
  phase.textContent=a.phase||'';
  if(a.history){shown=target;}
  render();
  if(!timer)timer=setTimeout(tick,16);
});
new ResizeObserver(resize).observe(document.body);
send('streamlit:componentReady',{apiVersion:1});resize();
