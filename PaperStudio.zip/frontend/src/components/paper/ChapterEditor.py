import streamlit as st


def render(manuscript):
    if not manuscript["chapters"]:
        st.info("生成或保存大纲后，章节将在这里出现。")
        return
    chapters = {c["id"]: c for c in manuscript["chapters"]}
    selected = st.selectbox("选择章节", list(chapters), format_func=lambda i: chapters[i]["title"],
                            key=f"chapter_choice_{manuscript['id']}")
    current = chapters[selected]
    st.caption(" · ".join(current["points"]))
    st.markdown(current["content"] or "本章尚未生成正文。")
    st.caption("重写、扩写、润色或删除章节请直接在 Agent 对话中提出。")
