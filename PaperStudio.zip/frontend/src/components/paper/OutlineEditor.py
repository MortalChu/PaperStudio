import json
import time

import streamlit as st

from src.api import paper
from src.api.request import APIError, request


def _parse(text):
    try:
        return json.loads(text), ""
    except json.JSONDecodeError as exc:
        return None, f"大纲格式不正确：第 {exc.lineno} 行第 {exc.colno} 列，请检查引号和逗号。"


def _save(paper_id, text, revision, source):
    data, error = _parse(text)
    if error:
        return None, error
    try:
        return paper.save_outline(paper_id, data, revision, source), ""
    except APIError as exc:
        return None, str(exc)


@st.fragment(run_every=1)
def _autosave(paper_id, widget_key, revision, locked):
    dirty = st.session_state.get(f"outline_dirty_{paper_id}")
    if locked or not dirty or dirty.get("widget_key") != widget_key:
        return
    remaining = 5 - (time.monotonic() - dirty["changed_at"])
    if remaining > 0:
        st.caption(f"● 尚未保存 · 停止修改后约 {max(1, int(remaining + .99))} 秒自动保存")
        return
    result, error = _save(paper_id, st.session_state.get(widget_key, ""), revision, "auto")
    if error:
        st.session_state[f"outline_save_notice_{paper_id}"] = ("error", error)
        st.session_state.pop(f"outline_dirty_{paper_id}", None)
        st.rerun()
    st.session_state[f"outline_save_notice_{paper_id}"] = (
        "success", "✓ 已自动保存 " + time.strftime("%H:%M:%S"))
    st.session_state.pop(f"outline_dirty_{paper_id}", None)
    st.rerun()


def render(manuscript):
    paper_id = manuscript["id"]
    run_status = None
    if manuscript.get("active_run_id"):
        try:
            run_status = request("GET", f"/api/papers/{paper_id}/runs/{manuscript['active_run_id']}",
                                 timeout=15).get("status")
        except APIError:
            run_status = "running"
    locked = run_status in ("running", "pausing")
    notice = st.session_state.pop(f"outline_save_notice_{paper_id}", None)
    if notice:
        st.success(notice[1]) if notice[0] == "success" else st.error(notice[1])
    if locked:
        st.warning("当前写作任务正在运行，暂时不能编辑大纲。请先在 Agent 对话中发送“暂停当前任务”，"
                   "后端确认任务已暂停后即可编辑。")
    if not manuscript["outline"]:
        st.info("当前还没有大纲。请在 Agent 对话中要求“生成论文大纲”或“开始完整写作”。")
        return
    st.caption("可以直接修改标题、章节、要点、目标字数和 subsections。点击“保存大纲”立即保存；"
               "停止修改5秒后也会自动保存。")
    revision = manuscript.get("outline_revision", 0)
    widget_key = f"outline_editor_{paper_id}_{revision}"
    original = json.dumps(manuscript["outline"], ensure_ascii=False, indent=2)
    if widget_key not in st.session_state:
        st.session_state[widget_key] = original
    updated = st.text_area("大纲 JSON", height=460, key=widget_key, disabled=locked)
    dirty_key = f"outline_dirty_{paper_id}"
    if not locked and updated != original:
        current = st.session_state.get(dirty_key)
        if not current or current.get("text") != updated:
            st.session_state[dirty_key] = {
                "text": updated, "changed_at": time.monotonic(), "widget_key": widget_key}
    if st.button("保存大纲", type="primary", disabled=locked or updated == original,
                 key=f"save_outline_{paper_id}_{revision}"):
        result, error = _save(paper_id, updated, revision, "manual")
        if error:
            st.error(error)
        else:
            st.session_state.pop(dirty_key, None)
            st.session_state[f"outline_save_notice_{paper_id}"] = (
                "success", "✓ 已手动保存 " + time.strftime("%H:%M:%S"))
            st.rerun()
    if not locked and st.session_state.get(dirty_key):
        _autosave(paper_id, widget_key, revision, locked)
