import streamlit as st
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from src.components.paper.PaperList import STATUS


def _format_time(value, empty="尚未结束"):
    if not value:
        return empty
    parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%d %H:%M")


def render(manuscript):
    st.title(manuscript["title"])
    st.caption(f"{STATUS.get(manuscript['status'], manuscript['status'])} · "
               f"{manuscript['topic'] or '研究方向未设置'}")
    created = _format_time(manuscript.get("created_at"), "时间未知")
    finished = _format_time(manuscript.get("finished_at"))
    st.caption(f"任务创建：{created} · 任务结束：{finished}")
    cols = st.columns(3)
    cols[0].metric("章节", len(manuscript["chapters"]))
    cols[1].metric("参考文献", len(manuscript["references"]))
    cols[2].metric("目标字数", f"{manuscript['word_limit']:,}")
    with st.expander("论文信息与写作要求"):
        st.write("**研究方向：** " + (manuscript["topic"] or "未设置"))
        st.write("**关键词：** " + (manuscript["keywords"] or "未设置"))
        st.write("**研究材料与写作要求：**")
        st.write(manuscript["requirements"] or "未设置")
        st.caption("题目、方向、关键词、目标字数和写作要求的修改统一通过上方 Agent 对话完成。")
