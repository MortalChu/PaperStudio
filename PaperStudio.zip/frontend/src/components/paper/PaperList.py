import streamlit as st
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from src.api import paper
from src.router.index import navigate
from src.stores.paper import select_paper

STATUS = {"draft": "草稿", "outline": "大纲阶段", "writing": "撰写中",
          "review": "初稿待人工核对", "completed": "已人工核对"}


def format_time(value, empty="尚未结束"):
    if not value:
        return empty
    parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%d %H:%M")


def render():
    st.title("我的论文")
    receipt = st.session_state.get("paper_list_receipt")
    if receipt:
        from src.components.common.Typewriter import render as typewriter
        with st.chat_message("assistant"):
            drained = typewriter(receipt["content"], "receipt_" + receipt["id"], complete=True,
                                 history=st.session_state.get("receipt_done_" + receipt["id"], False))
        if drained:
            st.session_state["receipt_done_" + receipt["id"]] = True
    st.caption("可以直接新建、打开或删除论文，也可以让 Agent 助手执行相同操作。")
    st.button("新建论文任务", type="primary", on_click=navigate, args=("新建论文",))
    selected = st.selectbox("状态筛选", ["all", *STATUS], format_func=lambda x: "全部" if x == "all" else STATUS[x])
    page = st.number_input("页码", min_value=1, value=1, step=1)
    papers = paper.list_papers(skip=(page-1)*20, limit=20, **({"status": selected} if selected != "all" else {}))
    if not papers:
        st.info("此页暂无论文。可以点击上方“新建论文任务”，也可以通过 Agent 对话创建。")
        return
    for item in papers:
        with st.container(border=True):
            left, right = st.columns([5, 1])
            left.subheader(item["title"])
            right.caption(STATUS.get(item["status"], item["status"]))
            created = format_time(item.get("created_at"), "时间未知")
            finished = format_time(item.get("finished_at"))
            st.caption(f"{item['topic'] or '未设置研究方向'} · 创建于 {created} · 任务结束：{finished}")
            st.caption(f"任务编号 #{item['id']}")
            st.button("打开论文", key=f"open_paper_{item['id']}", type="primary",
                      on_click=select_paper, args=(item["id"],))
            with st.expander("删除这篇论文"):
                confirmed = st.checkbox("确认移入回收站", key=f"confirm_delete_paper_{item['id']}")
                st.caption("如果论文正在生成，删除时会先停止当前任务。论文内容可从回收站恢复。")
                if st.button("移入回收站", key=f"delete_paper_{item['id']}",
                             disabled=not confirmed):
                    paper.remove(item["id"])
                    if st.session_state.get("paper_id") == item["id"]:
                        st.session_state.pop("paper_id", None)
                    st.success("论文已移入回收站。")
                    st.rerun()
