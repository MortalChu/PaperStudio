import streamlit as st
from src.api.request import request, download


def show_result(result):
    if isinstance(result, dict) and result.get("operation"):
        ids = st.session_state.get("library_job_ids", [])
        st.session_state.library_job_ids = list(dict.fromkeys([result["id"], *ids]))[:20]
        st.session_state.library_notice = "已提交后台处理，请在上方“上传与索引处理任务”查看进度。"
    else:
        st.session_state.library_notice = result
    st.rerun()


def render_index_error(ref):
    if ref.get("index_status") != "failed":
        return
    error = ref.get("index_error") or {}
    st.error(error.get("message", "旧版没有记录失败原因，请点击重试获取诊断信息。"))
    if error.get("diagnostic_id"):
        stage = {"embedding": "生成向量", "storage": "读写向量库", "document": "读取资料",
                 "read_pdf": "读取 PDF", "metadata": "识别书目信息"}.get(error.get("stage"), "索引处理")
        st.caption(f"失败阶段：{stage} · 错误类型：{error.get('error_type', '')} · 诊断编号：{error['diagnostic_id']}")


def render(references, prefix="library", read_only=False, empty_message=None):
    if st.session_state.get("library_notice"):
        notice = st.session_state.pop("library_notice")
        if isinstance(notice, dict):
            show = st.success if notice["index_status"] == "indexed" else st.warning
            show(notice.get("message", "处理已结束"))
        else:
            st.info(notice)
    if not references:
        st.info(empty_message or "暂无文献。可先到共享文献库上传 PDF；若已保存资料，请等待索引完成并重新检索。")
    user_id = st.session_state.get("user", {}).get("id")
    for ref in references:
        can_edit = not read_only and ref.get("owner_id") == user_id
        status = {"indexed": "可用于写作", "pending": "等待索引", "failed": "索引失败"}.get(ref["index_status"], ref["index_status"])
        with st.expander(f"{ref['title']} · {status} · {ref.get('year') or '年份待核对'}"):
            st.write(f"作者：{ref['authors'] or '待核对'}")
            st.write(f"来源：{ref['journal'] or '待核对'}")
            st.caption("索引状态：" + {"indexed": "可检索", "pending": "待建立", "failed": "失败，可重试"}.get(ref["index_status"], ref["index_status"]))
            render_index_error(ref)
            st.caption("信息状态：" + {"auto_extracted": "已自动识别，请在正式引用前核对", "needs_review": "部分信息待核对", "manual": "已手动录入 / 核对"}.get(ref.get("metadata_status"), "待核对"))
            if ref.get("doi"):
                st.write("DOI：" + ref["doi"])
            if ref.get("abstract"):
                st.write(ref["abstract"])
            if ref.get("metadata_sources"):
                if st.checkbox("查看信息识别依据", key=f"{prefix}_evidence_{ref['id']}"):
                    labels = {"title": "题名", "authors": "作者", "journal": "来源", "year": "年份", "doi": "DOI", "abstract": "摘要", "volume": "卷", "issue": "期", "pages": "页码"}
                    for field, source in ref["metadata_sources"].items():
                        st.caption(labels.get(field, field) + (f" · PDF 第 {source['page']} 页" if source.get("page") else ""))
                        st.text(source.get("quote", ""))
            style = st.selectbox("引用格式", ["gbt", "apa", "mla"], key=f"{prefix}_style_{ref['id']}",
                        format_func=lambda x: {"gbt": "GB/T 7714（期刊条目）", "apa": "APA", "mla": "MLA"}[x])
            if st.button("生成引用文本", key=f"{prefix}_cite_{ref['id']}"):
                citation = request("GET", f"/api/references/{ref['id']}/citation", params={"style": style})
                st.code(citation["citation"], language=None)
            left, right = st.columns(2)
            label = "重新构建索引" if ref["index_status"] == "indexed" else "重试 / 构建索引"
            if left.button(label, key=f"{prefix}_reindex_{ref['id']}", disabled=read_only):
                show_result(request("POST", f"/api/references/{ref['id']}/reindex"))
            if ref.get("filename") and right.button("获取原始 PDF", key=f"{prefix}_file_{ref['id']}"):
                content = download(f"/api/references/{ref['id']}/file")
                st.download_button("下载 PDF", content, ref["filename"], "application/pdf", key=f"{prefix}_download_{ref['id']}")
            if can_edit:
                with st.popover("修正或补充识别结果"):
                    with st.form(f"{prefix}_metadata_{ref['id']}"):
                        data = {}
                        for field, label in (("title", "题名"), ("authors", "作者"), ("journal", "期刊 / 来源"),
                                             ("volume", "卷"), ("issue", "期"), ("pages", "页码"), ("doi", "DOI"), ("url", "文献网址")):
                            data[field] = st.text_input(label, ref.get(field, ""))
                        year = st.text_input("发表年份", str(ref["year"] or ""))
                        data["abstract"] = st.text_area("摘要", ref["abstract"])
                        if st.form_submit_button("保存核对结果"):
                            if year and not year.isdigit():
                                st.error("年份应为数字")
                            else:
                                data["year"] = int(year) if year else None
                                show_result(request("PUT", f"/api/references/{ref['id']}", json=data))
                if ref.get("filename"):
                    recognize = st.checkbox("重新识别将替换当前书目信息", key=f"{prefix}_recognize_check_{ref['id']}")
                    if st.button("重新从 PDF 自动识别", key=f"{prefix}_recognize_{ref['id']}", disabled=not recognize):
                        with st.spinner("正在提交识别任务…"):
                            show_result(request("POST", f"/api/references/{ref['id']}/extract-metadata"))
                confirm = st.checkbox("确认从共享库删除（已被任务使用的文献不可删除）", key=f"{prefix}_remove_check_{ref['id']}")
                if st.button("删除文献", key=f"{prefix}_remove_{ref['id']}", disabled=not confirm):
                    request("DELETE", f"/api/references/{ref['id']}")
                    st.rerun()
            elif not read_only:
                st.caption("此文献由其他账号上传，可检索和阅读；信息修正与删除由上传者操作。")
