import streamlit as st
from src.api import reference


def render(paper_id, prefix="search"):
    with st.form(f"{prefix}_{paper_id}"):
        query = st.text_input("检索问题", placeholder="例如：哪些材料讨论了检索结果的可靠性？")
        top_k = st.slider("返回片段数", 1, 20, 5)
        submitted = st.form_submit_button("检索文献")
    if submitted:
        hits = reference.search(paper_id, query, top_k)
        if not hits:
            st.info("暂无达到相似度阈值的片段。请检查共享库索引状态，或调整检索词、补充相关资料。")
        for index, hit in enumerate(hits):
            with st.container(border=True):
                st.markdown(f"**{index + 1}. {hit['title']}**")
                st.caption(f"来源页码：{hit['page'] or '元数据 / 摘要'} · 相似度：{hit['score']:.3f}")
                st.write(hit["excerpt"])
