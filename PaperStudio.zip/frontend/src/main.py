import sys
from pathlib import Path
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.App import render  # noqa: E402

st.set_page_config(page_title="AI 论文写作系统", page_icon="✍️", layout="wide", initial_sidebar_state="expanded")
render()
