import streamlit as st


def navigate(page):
    st.session_state.route = page


def render_route():
    from src.stores.user import logged_in
    from src.views import AgentConsole, Home, Login, PaperCreate, PaperEdit, ReferenceManage, Trash, Memory
    from src.components.paper import PaperList
    route = st.session_state.get("route", "首页")
    pages = {"首页": Home.render, "登录": Login.render, "Agent 助手": AgentConsole.render,
             "新建论文": PaperCreate.render, "我的论文": PaperList.render,
             "写作工作台": PaperEdit.render, "文献管理": ReferenceManage.render, "回收站": Trash.render, "记忆与偏好": Memory.render}
    if route not in ("首页", "登录") and not logged_in():
        Login.render()
    else:
        pages.get(route, Home.render)()
