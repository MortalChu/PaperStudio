import hashlib


def revision_key(prefix, content):
    return f"{prefix}_{hashlib.sha256(content.encode()).hexdigest()[:12]}"
