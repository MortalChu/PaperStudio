import streamlit as st


def select_paper(paper_id):
    st.session_state.paper_id = paper_id
    st.session_state.route = "写作工作台"


def current_id():
    return st.session_state.get("paper_id")


def open_references(paper_id):
    """打开指定写作任务的文献页，避免误选其他任务的文献库。"""
    st.session_state.paper_id = paper_id
    st.session_state.reference_paper_id = paper_id
    st.session_state.route = "文献管理"
