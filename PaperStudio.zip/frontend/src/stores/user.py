import streamlit as st


def save_login(data):
    # A login always opens a fresh empty global chat. Durable sessions remain in history.
    st.session_state.pop("global_agent_session_id", None)
    st.session_state.pop("global_agent_turn_id", None)
    st.session_state.pop("global_agent_notice", None)
    st.session_state.token = data["access_token"]
    st.session_state.user = data["user"]


def logout():
    for key in list(st.session_state.keys()):
        del st.session_state[key]
    st.session_state.route = "登录"


def logged_in():
    return bool(st.session_state.get("token"))
