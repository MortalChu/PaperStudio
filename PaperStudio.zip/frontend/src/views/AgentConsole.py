from datetime import datetime
from zoneinfo import ZoneInfo

import streamlit as st

from src.api import paper
from src.components.common.Typewriter import render as typewriter
from src.api.request import APIError, request


def _local_time(value):
    if not value:
        return None
    parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        from datetime import timezone
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(ZoneInfo("Asia/Shanghai"))


def _message_list(records, active=None):
    active_assistant = active.get("assistant_message_id") if active else None
    for message in records:
        if active_assistant and message["id"] == active_assistant:
            continue
        with st.chat_message("user" if message["role"] == "user" else "assistant"):
            st.markdown(message["content"])
            details = message.get("details") or {}
            trace = details.get("agent_trace") or []
            observations = details.get("observations") or []
            if message["role"] == "assistant" and (trace or observations):
                with st.expander("查看本轮 Agent 的计划、工具与反思证据"):
                    for item in trace:
                        if item.get("stage") == "plan":
                            tools = "、".join(item.get("tools") or []) or "无工具"
                            st.write(f"规划：{item.get('summary') or '已完成能力选择'}（{tools}）")
                        elif item.get("stage") == "verification":
                            st.write(f"执行验证：{item.get('summary') or '已核对执行结果'}")
                        else:
                            st.write(f"反思：{item.get('summary') or '已核对工具结果'}")
                    for item in observations:
                        mark = "✅" if item.get("ok") else "⚠️"
                        st.write(f"{mark} {item.get('tool')}：{item.get('message')}")
    if active:
        with st.chat_message("assistant"):
            return typewriter(active.get("content") or active.get("error") or "",
                              "global_" + active["id"],
                              complete=active.get("status") in ("completed", "failed", "interrupted"),
                              phase=active.get("phase") or "Agent 正在理解你的要求…")
    return True


def _transcript_box(records, active=None):
    with st.container(height=480, border=False):
        if not records and not active:
            st.info("这是一个空白新会话。发送第一条消息后才会保存到历史会话。")
        return _message_list(records, active)


def _static_transcript(session_id):
    records = paper.global_messages(session_id) if session_id else []
    _transcript_box(records)


@st.fragment(run_every=.2)
def _polling_transcript(turn_id, session_id):
    try:
        active = paper.global_turn(turn_id)
    except APIError as exc:
        if exc.status != 404:
            raise
        st.session_state.pop("global_agent_turn_id", None)
        st.session_state.global_agent_notice = ("error", "对话状态已丢失，可能是后端刚刚重启。")
        st.rerun()
        return
    drained = _transcript_box(paper.global_messages(session_id), active)
    if drained and active.get("status") in ("completed", "failed", "interrupted"):
        target = active.get("paper_target_id")
        operation = active.get("operation")
        st.session_state.pop("global_agent_turn_id", None)
        if active.get("status") != "completed":
            st.session_state.global_agent_notice = (
                "error", active.get("error") or "Agent 本轮执行未完成。")
        if target and operation in ("create", "select"):
            st.session_state.paper_id = target
            st.session_state.route = "写作工作台"
        st.rerun()


def _new_session():
    st.session_state.pop("global_agent_session_id", None)
    st.session_state.pop("global_agent_turn_id", None)


def _reset_if_program_reloaded():
    instance_id = request("GET", "/health").get("instance_id")
    previous = st.session_state.get("global_agent_backend_instance")
    if previous and instance_id and previous != instance_id:
        _new_session()
    st.session_state.global_agent_backend_instance = instance_id


def _continue_session(session_id):
    st.session_state.global_agent_session_id = session_id
    st.session_state.pop("global_agent_turn_id", None)


def _delete_session(session_id, current_session_id):
    paper.delete_global_session(session_id)
    if session_id == current_session_id:
        _new_session()
    st.session_state.global_agent_notice = ("info", "历史会话已永久删除。")


def _history_list(current_session_id, active=False):
    st.subheader("历史会话")
    sessions = paper.global_sessions()
    if not sessions:
        st.caption("暂无历史会话。空白且未交互的新会话不会保存。")
        return
    current_date = None
    for item in sessions:
        updated = _local_time(item["updated_at"])
        date_label = updated.strftime("%Y年%m月%d日") if updated else "时间未知"
        if date_label != current_date:
            st.markdown(f"### {date_label}")
            current_date = date_label
        with st.container(border=True):
            st.markdown(f"**{item['title']}**")
            st.caption(
                f"最近交互：{updated.strftime('%H:%M:%S') if updated else '未知'} · "
                f"共 {item['message_count']} 条消息")
            if item.get("last_user_message"):
                preview = item["last_user_message"].replace("\n", " ").strip()
                st.write(preview[:180] + ("…" if len(preview) > 180 else ""))
            if item["id"] == current_session_id:
                st.caption("当前会话")
            else:
                st.button("查看并继续", key=f"continue_global_session_{item['id']}",
                          on_click=_continue_session, args=(item["id"],), disabled=active)
            confirmed = st.checkbox(
                "我确认永久删除这条历史会话",
                key=f"confirm_delete_global_session_{item['id']}",
                disabled=active and item["id"] == current_session_id)
            st.button("删除会话", key=f"delete_global_session_{item['id']}",
                      on_click=_delete_session, args=(item["id"], current_session_id),
                      disabled=not confirmed or (active and item["id"] == current_session_id))


def _submit_prompt():
    prompt = st.session_state.get("global_agent_input", "")
    if not prompt:
        return
    try:
        result = paper.submit_global_turn(prompt, st.session_state.get("global_agent_session_id"))
        st.session_state.global_agent_session_id = result["session_id"]
        st.session_state.global_agent_turn_id = result["turn_id"]
    except APIError as exc:
        st.session_state.global_agent_notice = ("error", str(exc))


def render():
    _reset_if_program_reloaded()
    st.title("Agent 助手")
    st.caption("每次程序重新加载或重新登录后从空白会话开始；已有内容保存在下方历史会话中。")
    with st.expander("查看 Agent 当前可以实际执行的工具"):
        capabilities = paper.global_capabilities()
        st.caption("只有列在这里的操作才会进入执行阶段；其他请求会明确回答当前无法执行。")
        for item in capabilities:
            marker = "（破坏性操作）" if item.get("destructive") else ""
            st.write(f"• `{item['name']}` {marker}：{item['description']}")
    active_turn_id = st.session_state.get("global_agent_turn_id")
    st.button("新建会话", on_click=_new_session, disabled=bool(active_turn_id),
              help="本轮回复结束后可以新建会话" if active_turn_id else None)
    notice = st.session_state.pop("global_agent_notice", None)
    if notice:
        st.error(notice[1]) if notice[0] == "error" else st.info(notice[1])
    session_id = st.session_state.get("global_agent_session_id")
    with st.container(border=True):
        if active_turn_id and session_id:
            _polling_transcript(active_turn_id, session_id)
        else:
            _static_transcript(session_id)
        st.chat_input(
            "询问论文状态或时间、创建或打开论文，也可以设置长期写作偏好",
            key="global_agent_input", on_submit=_submit_prompt)
    st.divider()
    _history_list(session_id, active=bool(active_turn_id))
