import streamlit as st
from src.router.index import navigate


def render():
    st.markdown('<section class="hero"><div class="eyebrow">RESEARCH · WRITE · REFINE</div>'
                '<h1>从一个想法，<br>到一篇完整的初稿。</h1>'
                '<p>梳理选题、组织证据、逐章写作。<br>让你把精力留给研究本身。</p></section>', unsafe_allow_html=True)
    st.button("开始一篇新论文 →", type="primary", on_click=navigate, args=("新建论文",))
    st.button("先构建共享文献库", on_click=navigate, args=("文献管理",))
    st.write("")
    items = [("01", "建立共享文献库", "上传 PDF，自动识别文献信息并建立索引。多个账号、多个任务持续复用。"),
             ("02", "创建研究任务", "确定题目与关键词，系统自动检索共享库中的相关文献。"),
             ("03", "依据文献开展写作", "根据检索到的资料生成大纲，确认后逐章撰写并标注引用。"),
             ("04", "逐步完善初稿", "编辑、润色和核对引用，保留每一步的历史版本。")]
    cols = st.columns(2)
    for i, (number, title, description) in enumerate(items):
        with cols[i % 2], st.container(border=True):
            st.caption(number)
            st.subheader(title)
            st.write(description)
