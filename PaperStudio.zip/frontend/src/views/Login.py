import streamlit as st
from src.api import auth
from src.api.request import APIError
from src.stores.user import save_login


def render():
    st.title("登录或创建账号")
    st.caption("登录后管理论文、文献和历史版本。")
    if st.session_state.get("auth_notice"):
        st.warning(st.session_state.pop("auth_notice"))
    login, register = st.tabs(["登录", "创建账号"])
    with login, st.form("login"):
        username = st.text_input("用户名", key="login_username")
        password = st.text_input("密码", type="password", key="login_password")
        if st.form_submit_button("登录", type="primary"):
            try:
                data = auth.login(username, password)
            except APIError as exc:
                st.error("用户名或密码错误。如果尚未注册，请切换到“创建账号”。" if exc.status == 401 else str(exc))
            else:
                save_login(data)
                st.session_state.route = "我的论文"
                st.rerun()
    with register, st.form("register"):
        username = st.text_input("用户名（至少 3 个字符）", key="register_username")
        email = st.text_input("邮箱")
        password = st.text_input("密码（至少 8 个字符）", type="password", key="register_password")
        confirm = st.text_input("再次输入密码", type="password")
        if st.form_submit_button("注册并登录", type="primary"):
            if password != confirm:
                st.error("两次密码不一致")
            else:
                try:
                    auth.register(username, email, password)
                except APIError as exc:
                    st.error(str(exc))
                else:
                    try:
                        data = auth.login(username, password)
                    except APIError:
                        st.warning("账号已创建，但自动登录未完成。请切换到“登录”重试，无需重复注册。")
                    else:
                        save_login(data)
                        st.session_state.route = "我的论文"
                        st.rerun()
