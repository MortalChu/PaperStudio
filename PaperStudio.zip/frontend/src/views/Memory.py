import streamlit as st
from src.api.request import request, APIError


def render():
    st.title("记忆与偏好")
    st.caption("账号记忆跨论文使用；论文要求仅影响对应论文。删除后不再用于后续执行，不会删除聊天和已有正文。")
    entries = request("GET", "/api/agent/memories")
    if not entries:
        st.info("暂无已保存的记忆。你可以在对话中告诉 Agent 希望记住什么。")
    for item in entries:
        with st.container(border=True):
            st.write(item["content"])
            st.caption(("账号长期记忆" if item["scope"] == "account" else "论文：" + item["paper_title"]) +
                       " · " + item["source"] + " · 更新：" + (item.get("updated_at") or "旧版未记录"))
            if st.button("删除这条记忆", key=f"forget_{item['scope']}_{item['paper_id']}_{item['id']}"):
                params = {"paper_id": item["paper_id"]} if item["scope"] == "paper" else {}
                request("DELETE", "/api/agent/memories/" + item["id"], params=params)
                st.rerun()
