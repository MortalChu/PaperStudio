import streamlit as st
from src.api import paper
from src.api.request import request
from src.stores.paper import select_paper
from src.router.index import navigate


def render():
    st.title("新建论文写作任务")
    st.caption("共享文献库 → 新建写作任务 → 自动检索相关文献 → 确认大纲 → 撰写论文。")
    stats = request("GET", "/api/references/stats")
    st.info(f"知识库有 {stats['indexed']} 篇可用于写作的文献，另有 {stats['pending']} 篇资料的索引待处理。任务创建后会自动检索可用文献。")
    if not stats["indexed"]:
        st.warning("当前没有可检索文献。可以先保存写作任务，但生成大纲和正文前需要完成共享库入库。")
    st.button("打开共享文献库", on_click=navigate, args=("文献管理",))
    with st.expander("还没有题目？获取选题建议"):
        with st.form("topics"):
            field = st.text_input("研究领域", placeholder="例如：人工智能辅助教育")
            keywords = st.text_input("研究关键词", placeholder="例如：学习反馈、可靠性")
            requirements = st.text_area("选题要求", height=80)
            if st.form_submit_button("推荐选题"):
                with st.spinner("正在梳理选题方向…"):
                    st.session_state.suggestions = request("POST", "/api/papers/topics", json={
                        "field": field, "keywords": keywords, "requirements": requirements})["topics"]
        for index, item in enumerate(st.session_state.get("suggestions", [])):
            with st.container(border=True):
                st.markdown(f"**{item['title']}**")
                st.write("研究价值：" + item["value"])
                st.write("创新假设：" + item["innovation"])
                st.caption("可行性：" + item["feasibility"])
                if st.button("采用这个题目", key=f"use_topic_{index}"):
                    st.session_state.create_title = item["title"]
    with st.form("create_paper"):
        title = st.text_input("论文标题", key="create_title", placeholder="至少 5 个字符")
        topic = st.text_input("研究方向", placeholder="例如：检索增强生成")
        keywords = st.text_input("关键词", placeholder="用逗号分隔")
        left, right = st.columns(2)
        kind = left.selectbox("论文类型", ["research", "review", "application"],
                              format_func=lambda x: {"research": "研究论文", "review": "文献综述", "application": "应用研究"}[x])
        words = right.number_input("目标字数", min_value=1000, max_value=30000, value=5000, step=500)
        requirements = st.text_area("研究材料与写作要求", placeholder="填写研究假设、已有数据、方法约束或特殊要求。")
        if st.form_submit_button("创建任务并检索文献", type="primary"):
            with st.spinner("正在创建任务并检索共享文献库…"):
                result = paper.create({"title": title, "topic": topic, "keywords": keywords,
                                    "paper_type": kind, "word_limit": words, "requirements": requirements})
            select_paper(result["id"])
            st.rerun()
