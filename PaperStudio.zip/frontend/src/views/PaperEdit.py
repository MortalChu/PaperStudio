import json
import html
import re
import streamlit as st
from src.api import paper
from src.components.common.Typewriter import render as typewriter
from src.api.request import APIError, request
from src.stores.paper import current_id, open_references
from src.components.paper import PaperDetail, OutlineEditor, ChapterEditor
from src.components.common.Editor import render as editor
from src.views.ReferenceManage import render_library


DEFAULT_PREFERENCES = {"auto_review": False, "annotation_color": "#B45309",
    "collapse_quality_issues": True, "collapse_agent_trace": True,
    "writing_style": "", "persistent_instructions": "", "preference_memory": []}


def display_preferences(manuscript):
    result = {**DEFAULT_PREFERENCES, **(manuscript.get("agent_preferences") or {})}
    if not isinstance(result.get("auto_review"), bool):
        result["auto_review"] = False
    return result


def annotated_markdown(content, color, target=st):
    """Render model text safely while coloring only known evidence-gap markers."""
    color = color.upper() if re.fullmatch(r"#[0-9A-Fa-f]{6}", str(color or "")) else "#B45309"
    safe = html.escape(content or "", quote=False)
    for marker in ("【待验证】", "【待补充文献】"):
        safe = safe.replace(marker, f'<span style="color:{color};font-weight:700">{marker}</span>')
    target.markdown(safe, unsafe_allow_html=True)


def failure_details(diagnostic):
    st.error(f"{diagnostic.get('step_label') or diagnostic.get('step', '执行步骤')}失败：{diagnostic['message']}")
    st.write(diagnostic.get("action", ""))
    details = ["错误类型：" + diagnostic.get("error_type", "未知"),
               "诊断编号：" + diagnostic.get("diagnostic_id", "")]
    if diagnostic.get("http_status"):
        details.append("模型接口 HTTP 状态码：" + str(diagnostic["http_status"]))
    if diagnostic.get("section_key"):
        details.append("章节编号：" + diagnostic["section_key"])
    st.caption(" ｜ ".join(details))
    if diagnostic.get("model"):
        label = "向量服务" if diagnostic.get("service") == "embedding" else "写作服务"
        st.caption(f"{label}：{diagnostic.get('provider', '')} · {diagnostic['model']} · {diagnostic.get('endpoint_host', '')}")
    if diagnostic.get("provider_code") or diagnostic.get("parameter"):
        st.caption(f"供应商错误码：{diagnostic.get('provider_code') or '未提供'} ｜ 错误参数：{diagnostic.get('parameter') or '未提供'}")
    if diagnostic.get("provider_request_id"):
        st.caption("供应商请求编号：" + diagnostic["provider_request_id"])
    if diagnostic.get("validation_fields"):
        st.write("未通过结构校验的字段：")
        st.json(diagnostic["validation_fields"])


def outline_sections(outline):
    result = []

    def visit(items, prefix=""):
        for index, item in enumerate(items or []):
            key = f"{prefix}{index + 1}"
            result.append({"key": key, "title": item.get("title") or f"章节 {key}"})
            visit(item.get("subsections", []), key + ".")

    visit((outline or {}).get("sections", []))
    return result


def render_workflow_progress(events, status, outline, preferences):
    completed_nodes = {event.get("step") for event in events if event.get("kind") == "progress"}
    completed_sections = {key for event in events if event.get("kind") == "progress"
                          for key in event.get("section_keys", [])}
    latest_start = next((event for event in reversed(events) if event.get("kind") == "step_start" and (
        (event.get("step") == "write_section" and event.get("section_key") not in completed_sections) or
        (event.get("step") != "write_section" and event.get("step") not in completed_nodes))), {})
    active_step = latest_start.get("step", "")
    active_section = latest_start.get("section_key", "")
    sections = outline_sections(outline)
    stages = [
        ("topic", "分析并确定题目", "analyze_topic" in completed_nodes),
        ("planning", "自主规划与工具选择", "plan_next" in completed_nodes),
        ("references", "检索共享文献", "add_references" in completed_nodes),
        ("outline", "生成论文大纲", "generate_outline" in completed_nodes),
        ("confirm", "确认论文大纲", "confirm_outline" in completed_nodes),
        ("refresh", "按确认后的题目更新证据", "refresh_references" in completed_nodes),
    ]
    stages.extend(("section:" + section["key"], "生成：" + section["title"], section["key"] in completed_sections)
                  for section in sections)
    stages.append(("polish", "润色生成的章节", "polish_paper" in completed_nodes))
    if preferences.get("auto_review", False):
        stages.append(("quality", "按需反思结构、引用与证据缺口", "quality_check" in completed_nodes))
    stages.append(("save", "保存初稿与历史版本", any(event.get("kind") == "done" for event in events)))
    active_id = {"analyze_topic": "topic", "recommend_topic": "topic", "confirm_topic": "topic",
                 "plan_next": "planning",
                 "add_references": "references", "generate_outline": "outline", "confirm_outline": "confirm",
                 "confirm_review": "review_choice", "refresh_references": "refresh",
                 "polish_paper": "polish", "quality_check": "quality",
                 "finalize": "save", "save_result": "save"}.get(
                     active_step, "section:" + active_section if active_step == "write_section" else "")
    if status.get("status") == "waiting" and status.get("requests"):
        request_kind = status["requests"][0].get("kind")
        active_id = {"outline": "confirm", "review_preference": "review_choice"}.get(request_kind, "topic")
    if status.get("diagnostic"):
        failed_step = status["diagnostic"].get("step", "")
        active_id = {"write_section": "section:" + status["diagnostic"].get("section_key", "")}.get(
            failed_step, {"add_references": "references", "generate_outline": "outline",
            "confirm_outline": "confirm", "refresh_references": "refresh", "polish_paper": "polish",
            "quality_check": "quality", "plan_next": "planning", "finalize": "save",
            "save_result": "save"}.get(failed_step, active_id))
    completed = sum(1 for _, _, done in stages if done)
    if status.get("status") == "completed":
        completed = len(stages)
    current_label = next((label for identifier, label, _ in stages if identifier == active_id), "准备工作流")
    if active_step == "write_section" and latest_start.get("title"):
        current_label = "生成：" + latest_start["title"]
    if status.get("status") == "waiting":
        current_label = {"confirm": "等待确认大纲", "review_choice": "等待你决定是否自动核对"}.get(
            active_id, "等待确认题目")
    elif status.get("status") == "paused":
        current_label = "已暂停：" + current_label
    elif status.get("status") == "failed":
        current_label = "失败于：" + current_label
    elif status.get("status") == "interrupted":
        current_label = "已中断，可从检查点继续"
    st.progress(completed / max(len(stages), 1), text=f"进度 {completed}/{len(stages)} · {current_label}")
    with st.expander("查看全部写作步骤", expanded=status.get("status") in ("waiting", "paused", "failed")):
        for identifier, label, done in stages:
            marker = "✅" if done else "▶️" if identifier == active_id else "⬜"
            st.write(f"{marker} {label}")
    decisions = [event for event in events if event.get("kind") in ("agent_decision", "reflection")]
    if decisions:
        with st.expander("查看智能体的规划与反思记录",
                         expanded=not preferences.get("collapse_agent_trace", True)):
            for event in decisions[-20:]:
                if event.get("kind") == "agent_decision":
                    st.write(f"规划 → {event.get('action', '未知行动')}：{event.get('rationale', '')}")
                    if event.get("guardrail_applied"):
                        st.caption("本次选择触发了状态约束修正。")
                else:
                    st.write(f"反思 → {event.get('decision', '未知结论')}：{event.get('summary', '')}")
                    if event.get("issues"):
                        st.caption("发现问题：" + "；".join(event["issues"]))
                    if event.get("evidence_gaps"):
                        st.caption("证据缺口：" + "；".join(event["evidence_gaps"]))


def render_accumulated_preview(order, buffers, holder, annotation_color):
    visible = list(order)
    visible.extend(key for key, item in buffers.items()
                   if item.get("content") and not item.get("complete") and
                   not item.get("abandoned") and key not in visible)
    if not visible:
        return
    def chapter_order(buffer_key):
        item = buffers[buffer_key]
        try:
            structural_key = tuple(int(part) for part in item.get("section_key", "").split("."))
        except ValueError:
            structural_key = (10 ** 9,)
        return item.get("round", 1), structural_key, item.get("attempt", 1)

    drained = True
    with holder:
        for key in sorted(visible, key=chapter_order):
            item = buffers[key]
            if not item.get("content"):
                continue
            st.subheader(item["title"])
            done = typewriter(item["content"], item["identity"], complete=item.get("complete") or item.get("abandoned"),
                             color=annotation_color, history=item.get("history", False))
            drained = drained and done
            st.divider()
    return drained


def render_live_preview(paper_id, run_id, preferences):
    cache_key = "workflow_live_" + run_id
    cache = st.session_state.get(cache_key)
    if not cache or cache.get("version") != 4:
        cache = {"version": 4, "after": 0, "buffers": {}, "order": [],
                 "round": 0, "active": {}, "attempts": {}, "initial": True}
        st.session_state[cache_key] = cache
    # 分批追赶历史事件，避免页面长时间关闭后一次响应过大。
    for _ in range(3):
        batch = request("GET", f"/api/papers/{paper_id}/runs/{run_id}/event-snapshot",
                        params={"after": cache["after"], "limit": 1000}, timeout=20)
        for event in batch["events"]:
            kind = event.get("kind")
            if kind == "step_start" and event.get("step") == "write_sections":
                cache["round"] += 1
            elif kind == "step_start" and event.get("step") == "write_section":
                section_key = event.get("section_key", "")
                previous = cache["active"].get(section_key)
                if previous and previous.startswith("token-") and not cache["buffers"][previous].get("started"):
                    cache["buffers"][previous]["started"] = True
                    cache["after"] = max(cache["after"], event.get("id", 0))
                    continue
                if previous and not cache["buffers"][previous].get("complete"):
                    cache["buffers"][previous]["abandoned"] = True
                attempt = cache["attempts"].get(section_key, 0) + 1
                cache["attempts"][section_key] = attempt
                buffer_key = f"{event['id']}:{section_key}"
                cache["buffers"][buffer_key] = {"section_key": section_key,
                    "title": event.get("title") or f"章节 {section_key}",
                    "round": max(cache["round"], 1), "attempt": attempt, "content": "", "complete": False}
                cache["active"][section_key] = buffer_key
            elif kind == "token":
                section_key = event.get("section_key", "")
                buffer_key = cache["active"].get(section_key)
                if not buffer_key:
                    attempt = cache["attempts"].get(section_key, 0) + 1
                    cache["attempts"][section_key] = attempt
                    buffer_key = f"token-{event['id']}:{section_key}"
                    cache["buffers"][buffer_key] = {"section_key": section_key,
                        "title": event.get("title") or f"章节 {section_key}",
                        "round": max(cache["round"], 1), "attempt": attempt, "content": "", "complete": False}
                    cache["active"][section_key] = buffer_key
                cache["buffers"][buffer_key]["content"] += event.get("text", "")
            elif kind == "progress" and event.get("step") == "write_section":
                for section_key in event.get("section_keys", []):
                    buffer_key = cache["active"].get(section_key)
                    if buffer_key:
                        cache["buffers"][buffer_key]["complete"] = True
                        if cache["buffers"][buffer_key]["content"] and buffer_key not in cache["order"]:
                            cache["order"].append(buffer_key)
            elif kind in ("paused", "interrupted"):
                for buffer_key in cache["active"].values():
                    if not cache["buffers"][buffer_key].get("complete"):
                        cache["buffers"][buffer_key]["abandoned"] = True
            cache["after"] = max(cache["after"], event.get("id", 0))
        if not batch.get("has_more"):
            break
    has_streaming_content = any(
        item.get("content") and not item.get("complete") and not item.get("abandoned")
        for item in cache["buffers"].values())
    if cache["order"] or has_streaming_content:
        for key, item in cache["buffers"].items():
            item["identity"] = run_id + "_" + key
            if cache.get("initial") and item.get("complete"):
                item["history"] = True
        cache["initial"] = False
        return render_accumulated_preview(cache["order"], cache["buffers"], st.container(),
                                          preferences.get("annotation_color"))
    cache["initial"] = False
    return True


def _render_active_workflow(manuscript, status):
    paper_id, run_id = manuscript["id"], manuscript["active_run_id"]
    preferences = display_preferences(manuscript)
    render_workflow_progress(status.get("events", []), status, manuscript.get("outline"), preferences)
    if status.get("diagnostic"):
        failure_details(status["diagnostic"])
    messages = {"running": "任务正在后台生成；可随时在对话中要求暂停或取消。",
                "pausing": "正在暂停当前模型步骤。",
                "paused": "任务已暂停；现在可以编辑大纲，完成后在对话中要求继续。",
                "waiting": "Agent 正在等待你的对话指令；可以编辑大纲后回复“确认大纲并继续”。",
                "failed": "任务执行失败，请查看诊断信息并通过对话决定继续或取消。",
                "interrupted": "任务已中断，可以在对话中要求从检查点继续。",
                "cancelled": "本次任务已经取消。"}
    st.info(messages.get(status["status"], status["status"]))
    return render_live_preview(paper_id, run_id, preferences)


@st.fragment(run_every=.5)
def _polling_workflow(manuscript):
    paper_id, run_id = manuscript["id"], manuscript["active_run_id"]
    try:
        status = request("GET", f"/api/papers/{paper_id}/runs/{run_id}", timeout=20)
    except APIError as exc:
        if exc.status == 404:
            return
        raise
    drained = _render_active_workflow(manuscript, status)
    if drained and status.get("status") not in ("running", "pausing"):
        st.session_state.pop(f"workflow_display_run_{paper_id}", None)
        st.rerun()


def workflow_panel(manuscript):
    paper_id = manuscript["id"]
    preferences = display_preferences(manuscript)
    if not manuscript["active_run_id"] and st.session_state.get(f"workflow_display_run_{paper_id}"):
        _polling_workflow({**manuscript, "active_run_id": st.session_state[f"workflow_display_run_{paper_id}"]})
        return
    if not manuscript["active_run_id"]:
        if manuscript.get("final_paper"):
            report = manuscript.get("quality_report") or {}
            st.success("论文初稿已经生成并保存。后续修改、核对、导出或重新生成请直接告诉 Agent。")
            cols = st.columns(3)
            cols[0].metric("已生成章节", len(manuscript.get("chapters", [])))
            cols[1].metric("正文字符", f"{report.get('character_count', len(manuscript['final_paper'])):,}")
            cols[2].metric("引用文献", len(report.get("references") or manuscript.get("references", [])))
            with st.expander("在写作流程中预览当前初稿"):
                annotated_markdown(manuscript["final_paper"][:5000], preferences.get("annotation_color"))
        else:
            st.subheader("生成论文初稿")
            st.info("请在上方对话中输入“开始完整写作”。Agent 会检索共享文献、生成大纲并等待你确认。")
        return
    run_id = manuscript["active_run_id"]
    status = request("GET", f"/api/papers/{paper_id}/runs/{run_id}", timeout=20)
    if status.get("status") in ("running", "pausing"):
        st.session_state[f"workflow_display_run_{paper_id}"] = run_id
        _polling_workflow(manuscript)
    else:
        _render_active_workflow(manuscript, status)


def _render_paper_transcript(paper_id, active=None):
    cache_key = f"paper_transcript_{paper_id}"
    try:
        records = paper.agent_messages(paper_id)
        st.session_state[cache_key] = records
    except APIError as exc:
        if exc.status != 404 or not active:
            raise
        records = st.session_state.get(cache_key, [])
    active_user_seen = False
    active_assistant = active.get("assistant_message_id") if active else None
    with st.container(height=480, border=False):
        if not records and not active:
            st.info("还没有对话。你可以直接要求 Agent 开始写作、修改信息、检索、暂停或继续任务。")
        for message in records:
            if active and message["role"] == "user" and message["content"] == active.get("prompt"):
                active_user_seen = True
            if active_assistant and message["id"] == active_assistant:
                continue
            with st.chat_message("user" if message["role"] == "user" else "assistant"):
                st.markdown(message["content"])
                details = message.get("details") or {}
                trace = details.get("agent_trace") or []
                observations = details.get("observations") or []
                if message["role"] == "assistant" and (trace or observations):
                    with st.expander("查看本轮 Agent 的计划、工具与反思证据"):
                        for item in trace:
                            label = {"plan": "规划", "verification": "执行验证"}.get(item.get("stage"), "反思")
                            st.write(f"{label}：{item.get('summary') or '已完成'}")
                        for item in observations:
                            mark = "✅" if item.get("ok") else "⚠️"
                            st.write(f"{mark} {item.get('tool')}：{item.get('message')}")
        if active and not active_user_seen:
            with st.chat_message("user"):
                st.markdown(active.get("prompt", ""))
        if active:
            with st.chat_message("assistant"):
                return typewriter(active.get("content") or active.get("error") or "",
                    "paper_" + active["id"],
                    complete=active.get("status") in ("completed", "failed", "interrupted"),
                    phase=active.get("phase") or "Agent 正在理解你的要求…")
    return True

@st.fragment(run_every=.3)
def _polling_paper_transcript(paper_id, turn_id):
    try:
        active = paper.agent_turn(paper_id, turn_id)
    except APIError as exc:
        if exc.status != 404:
            raise
        st.session_state.pop(f"paper_agent_turn_{paper_id}", None)
        st.session_state[f"paper_agent_notice_{paper_id}"] = (
            "error", "对话状态已丢失，可能是后端刚刚重启。")
        st.rerun()
        return
    if active.get("status") == "completed" and active.get("operation") == "delete":
        _leave_deleted_paper(paper_id, active)
        return
    drained = _render_paper_transcript(paper_id, active)
    if drained and active.get("status") in ("completed", "failed", "interrupted"):
        st.session_state.pop(f"paper_agent_turn_{paper_id}", None)
        if active.get("status") != "completed":
            st.session_state[f"paper_agent_notice_{paper_id}"] = (
                "error", active.get("error") or "Agent 本轮执行未完成。")
        if active.get("operation") == "delete":
            st.session_state.pop("paper_id", None)
            st.session_state.route = "我的论文"
        st.rerun()


def _leave_deleted_paper(paper_id, active):
    st.session_state.paper_list_receipt = {"id": active["id"], "content": active.get("content") or "论文已移入回收站。"}
    st.session_state.pop(f"paper_agent_turn_{paper_id}", None)
    st.session_state.pop(f"workflow_display_run_{paper_id}", None)
    st.session_state.pop("paper_id", None)
    st.session_state.route = "我的论文"
    st.rerun()


def _submit_paper_prompt(paper_id):
    prompt = st.session_state.get(f"paper_agent_chat_{paper_id}", "")
    if not prompt:
        return
    try:
        result = paper.submit_agent_turn(paper_id, prompt)
        st.session_state[f"paper_agent_turn_{paper_id}"] = result["turn_id"]
    except APIError as exc:
        st.session_state[f"paper_agent_notice_{paper_id}"] = ("error", str(exc))


def agent_panel(manuscript):
    paper_id = manuscript["id"]
    preferences = display_preferences(manuscript)
    st.subheader("与论文 Agent 持续协作")
    notice = st.session_state.pop(f"paper_agent_notice_{paper_id}", None)
    if notice:
        st.error(notice[1]) if notice[0] == "error" else st.info(notice[1])
    st.write("直接描述你想改变的内容或行为。Agent 会保留本论文上下文，并选择定向修改、补充检索、按需核对或偏好设置工具。")
    st.caption("偏好来自自由对话，不限于预设选项；系统会把持续性要求提炼为本论文或账号的自然语言记忆。")
    if manuscript.get("active_run_id"):
        st.info("当前有任务在执行。提交新的内容要求后，Agent 会中断当前未完成的模型步骤并立即重新规划；已经完成的章节和检查点会保留。")
    st.caption("默认不执行自动核对；需要时可直接在对话中开启。示例：重写第 2 章并强调方法局限；补充检索弱监督小目标检测文献；本论文需要自动核对；"
               "把【待验证】改成红色；把质量问题折叠；以后都采用简洁的学术写作风格。")

    with st.expander("Agent 从对话中记住了什么"):
        review_label = "允许自动核对" if preferences.get("auto_review", False) else "不进行自动核对"
        st.caption("自动核对：" + review_label)
        memories = preferences.get("preference_memory") or []
        if memories:
            for item in memories:
                st.write("• " + item)
        else:
            st.caption("尚未形成长期偏好。只有对话中表达的持续性要求才会记录在这里。")

    with st.container(border=True):
        turn_id = st.session_state.get(f"paper_agent_turn_{paper_id}")
        if turn_id:
            active = paper.agent_turn(paper_id, turn_id)
            if active.get("operation") == "delete" and active.get("status") == "completed":
                _leave_deleted_paper(paper_id, active)
            else:
                _polling_paper_transcript(paper_id, turn_id)
        else:
            _render_paper_transcript(paper_id)
        st.chat_input("告诉 Agent 你要执行的操作或希望如何改进论文",
                      key=f"paper_agent_chat_{paper_id}",
                      on_submit=_submit_paper_prompt, args=(paper_id,))

def versions_panel(manuscript):
    paper_id = manuscript["id"]
    st.caption("版本包含题目、大纲、正文和当时的引用列表。需要保存或恢复版本时，请在 Agent 对话中说明。")
    versions = request("GET", f"/api/papers/{paper_id}/versions")
    if not versions:
        st.info("暂无历史版本")
        return
    for version in versions:
        st.write(f"#{version['id']} · {version['label']} · {str(version['created_at'])[:16].replace('T', ' ')}")


def render():
    paper_id = current_id()
    if not paper_id:
        st.title("写作工作台")
        st.info("当前没有选中的论文。请进入侧边栏“Agent 助手”，通过对话新建或打开论文任务。")
        return
    try:
        manuscript = paper.get(paper_id)
    except APIError as exc:
        if exc.status != 404:
            raise
        turn_id = st.session_state.get(f"paper_agent_turn_{paper_id}")
        if turn_id:
            _polling_paper_transcript(paper_id, turn_id)
        else:
            st.session_state.pop("paper_id", None)
            st.session_state.route = "我的论文"
            st.rerun()
        return
    PaperDetail.render(manuscript)
    workspace, outline, chapters, references, history, full = st.tabs(
        ["Agent 对话与写作", "大纲编辑", "章节编辑", "文献与证据", "历史版本", "全文预览"])
    with workspace:
        agent_panel(manuscript)
        st.divider()
        st.subheader("写作流程")
        workflow_panel(manuscript)
    with outline:
        OutlineEditor.render(manuscript)
    with chapters:
        ChapterEditor.render(manuscript)
    with references:
        st.subheader("本任务的参考文献与检索依据")
        render_library(manuscript, f"paper_refs_{paper_id}")
    with history:
        versions_panel(manuscript)
    with full:
        report = manuscript["quality_report"]
        preferences = display_preferences(manuscript)
        findings = [("error", item) for item in report.get("issues", [])]
        findings.extend(("warning", item) for item in report.get("warnings", []))
        if findings:
            with st.expander(f"质量核对提示（{len(findings)} 条）",
                             expanded=not preferences.get("collapse_quality_issues", True)):
                for kind, message in findings:
                    st.error(message) if kind == "error" else st.warning(message)
        if manuscript["final_paper"]:
            annotated_markdown(manuscript["final_paper"], preferences.get("annotation_color"))
            st.caption("需要导出时，请在 Agent 对话中说明格式。")
        else:
            st.info("开始撰写后，将在此汇总全文。")

