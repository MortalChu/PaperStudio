import streamlit as st
from src.api import reference
from src.api.request import request, APIError
from src.components.reference import ReferenceList, ReferenceSearch


def remember_job(job):
    ids = st.session_state.get("library_job_ids", [])
    st.session_state.library_job_ids = list(dict.fromkeys([job["id"], *ids]))[:20]


def _render_jobs_content():
    st.subheader("上传与索引处理任务")
    st.caption("显示共享库所选页的任务及最早的 20 项进行中任务。接收成功只表示已排队；可关闭页面，之后回来查看。")
    with st.expander("查看更早的处理记录"):
        page = st.number_input("任务记录页码（每页 20 项，最新记录在第 1 页）", min_value=1, value=1, step=1, key="library_jobs_page")
    try:
        recent = request("GET", "/api/references/jobs", params={"skip": (page - 1) * 20, "limit": 20}, timeout=15)
        active = request("GET", "/api/references/jobs", params={"status": "active", "limit": 20}, timeout=15)
        jobs = {job["id"]: job for job in [*active, *recent]}
        for job_id in st.session_state.get("library_job_ids", []):
            if job_id not in jobs:
                try:
                    jobs[job_id] = request("GET", f"/api/references/jobs/{job_id}", timeout=15)
                except APIError as exc:
                    if exc.status != 404:
                        raise
    except APIError as exc:
        st.warning("暂时无法获取处理进度：" + str(exc))
        return
    previous = st.session_state.get("library_job_states", {})
    current = {job_id: job["status"] for job_id, job in jobs.items()}
    st.session_state.library_job_states = current
    if any(previous.get(job_id) in ("queued", "running") and status in ("completed", "failed")
           for job_id, status in current.items()):
        st.rerun()  # 更新任务状态之外的统计数字和可用文献列表。
    if not jobs:
        st.caption("尚无上传或索引任务。")
        return
    labels = {"queued": "排队等待", "read_pdf": "读取 PDF / 准备文本", "metadata": "识别书目信息",
              "embedding": "生成文本向量", "storage": "写入向量索引", "done": "处理完成", "document": "准备文本"}
    ordered = sorted(jobs.values(), key=lambda job: (job["status"] not in ("queued", "running"), job["created_at"]))
    for job in ordered:
        status = {"queued": "排队中", "running": "处理中", "completed": "本次处理完成", "failed": "本次处理失败"}[job["status"]]
        with st.expander(f"{job['filename']} · {status}", expanded=job["status"] in ("running", "failed")):
            st.caption(f"任务编号：{job['id']} · 阶段：{labels.get(job['stage'], job['stage'])}")
            if job["duplicate"]:
                st.caption("检测到相同资料，复用已有文献记录。")
            if job["status"] in ("queued", "running"):
                if job["progress_total"]:
                    done, total = job["progress_done"], job["progress_total"]
                    st.progress(min(done / total, 1.0), text=f"{labels.get(job['stage'], '处理片段')}：{done} / {total} 个片段")
                else:
                    st.info("文件已接收，等待后台处理。" if job["status"] == "queued" else "正在处理；耗时取决于 PDF 长度和模型响应速度。")
            elif job["status"] == "failed":
                ReferenceList.render_index_error({"index_status": "failed", "index_error": job["error"]})
                st.caption("失败资料已保留，修正原因后可重试；损坏文件或扫描件需要修复 / OCR 后重新上传。")
                st.caption("修复配置或文档后，可在“Agent 助手”中输入“重试失败索引”。")
            if job["reference_id"] and job["status"] in ("completed", "failed"):
                try:
                    ref = request("GET", f"/api/references/{job['reference_id']}", timeout=15)
                except APIError as exc:
                    if exc.status == 404:
                        st.caption("对应文献已移除。")
                    else:
                        st.warning("暂时无法读取文献当前状态：" + str(exc))
                    continue
                if ref["index_status"] == "indexed":
                    st.success("文献当前索引可用，可以检索和写作。")
                elif job["status"] == "completed":
                    st.info("这是历史完成记录；文献当前正在重建或需要重试，请以文献实时状态为准。")
                st.write(f"题名：{ref['title']} ｜ 作者：{ref['authors'] or '待核对'} ｜ 来源：{ref['journal'] or '待核对'} ｜ 年份：{ref['year'] or '待核对'}")


@st.fragment(run_every="3s")
def _polling_jobs():
    _render_jobs_content()


def render_jobs(poll=False):
    if poll:
        _polling_jobs()
    else:
        _render_jobs_content()


def render_library(manuscript, prefix="refs"):
    st.caption("以下是此任务检索到或历史使用过的文献。共享库中的文献可供不同用户、不同任务复用。")
    report = manuscript.get("quality_report") or {}
    retrieval = report.get("retrieval", {})
    if retrieval.get("message"):
        st.info(retrieval["message"])
    st.caption("需要补充或重新检索时，请在 Agent 对话中提出；共享文献库可从侧边栏打开。")
    if manuscript.get("final_paper"):
        st.caption("重新检索不会改动已有正文与引用编号；整篇重新生成时才使用新的文献结果。")
    ReferenceList.render(manuscript.get("references", []), prefix, read_only=True)
    evidence = retrieval.get("references") or report.get("references", [])
    if evidence:
        with st.expander("查看最近一次检索的写作依据"):
            for item in evidence:
                st.markdown(f"**[{item.get('citation_number', '?')}] {item['title']}**")
                st.write(item.get("excerpt", ""))
    st.subheader("在整个共享库中检索片段")
    ReferenceSearch.render(manuscript["id"], prefix + "_search")


def render():
    st.title("共享文献库")
    st.caption("先积累文献，再创建写作任务。系统根据题目与关键词自动检索，所有账号复用同一份文献索引。")
    stats = request("GET", "/api/references/stats")
    columns = st.columns(4)
    for column, label, key in zip(columns, ["已保存资料", "可用于写作", "等待索引", "索引失败"],
                                  ["total", "indexed", "awaiting", "failed"]):
        column.metric(label, stats[key])
    st.caption(f"只有索引成功的资料属于可检索知识库。待处理资料保留供重试，不参与 AI 写作；另有 {stats['needs_review']} 篇资料的书目信息待核对。")
    rebuild = stats["rebuild"]
    if rebuild["status"] == "running":
        st.info(f"后台处理中 {rebuild['running']} 项，排队中 {rebuild['queued']} 项。下方处理任务每 3 秒更新进度。")
    elif rebuild["status"] == "failed":
        st.warning("后台队列发生异常，请检查下方诊断及后端日志。恢复后重启后端可继续处理。")
        ReferenceList.render_index_error({"index_status": "failed", "index_error": rebuild.get("error", {})})
    if stats["embedding_mode"] == "hash":
        st.info("当前使用离线词面匹配；正式语义检索请在后端配置真实向量模型。")
    st.caption("本库中的文献及原始 PDF 对同一部署实例的所有已登录账号可见；写作任务仍由各自账号管理。")
    if stats["pending"]:
        st.caption("需要重试失败或待建索引时，请在“Agent 助手”中输入“重试失败索引”。")
    with st.container(border=True):
        st.subheader("上传参考资料，识别信息并构建索引")
        st.caption("无需填写题名、作者或期刊。系统读取 PDF 信息与正文，模型辅助提取有原文依据的字段；识别不全时标为待核对。扫描件请先进行 OCR。")
        st.caption("文件接收后返回处理任务，识别与索引在后台进行；可在下方查看进度。索引完成后才可用于写作。关闭页面不会取消处理。")
        with st.form("shared_pdf_upload", clear_on_submit=True):
            files = st.file_uploader("选择参考文献 PDF（可多选）", type=["pdf"], accept_multiple_files=True)
            submitted = st.form_submit_button("自动识别并建立共享索引", type="primary")
        if submitted:
            if not files:
                st.error("请选择 PDF 文件")
            else:
                errors = []
                for file in files:
                    with st.spinner(f"正在接收文件：{file.name}"):
                        try:
                            job = request("POST", "/api/references/upload",
                                files={"file": (file.name, file.getvalue(), "application/pdf")})
                            remember_job(job)
                        except APIError as exc:
                            if exc.status == 401:
                                raise
                            errors.append(f"{file.name}：{exc}")
                st.session_state.library_submission_errors = errors
                st.rerun()
    for error in st.session_state.get("library_submission_errors", []):
        st.error(error)
    if st.session_state.get("library_submission_errors") and st.button("收起提交提示"):
        st.session_state.pop("library_submission_errors", None)
        st.rerun()
    render_jobs(poll=rebuild["status"] == "running")
    with st.expander("没有 PDF？手动录入摘要"):
        with st.form("shared_abstract"):
            title = st.text_input("文献题名")
            abstract = st.text_area("摘要正文", height=150)
            authors = st.text_input("作者（可选）")
            journal = st.text_input("期刊或来源（可选）")
            if st.form_submit_button("保存摘要并构建索引"):
                result = request("POST", "/api/references/", json={"title": title, "abstract": abstract,
                                  "authors": authors, "journal": journal})
                remember_job(result)
                st.rerun()
    st.caption("创建、打开和切换论文任务请使用侧边栏“Agent 助手”。")
    st.divider()
    st.subheader("知识库与待处理资料")
    selection = st.radio("查看范围", ["可用于写作", "待处理资料（不可检索）", "全部已保存资料"], horizontal=True, key="library_scope")
    status = {"可用于写作": "indexed", "待处理资料（不可检索）": "unavailable", "全部已保存资料": "all"}[selection]
    query = st.text_input("按题名筛选", key="library_title_query")
    page = st.number_input("页码（每页 20 篇）", min_value=1, value=1, step=1, key="library_page_" + status)
    refs = reference.list_references(query=query, skip=(page - 1) * 20, limit=20, status=status)
    ReferenceList.render(refs, "shared_library", empty_message="当前范围暂无资料。索引失败的资料请在“待处理资料”中查看原因或重试。")
    st.divider()
    st.subheader("检索共享文献片段")
    ReferenceSearch.render(None, "shared_search")

