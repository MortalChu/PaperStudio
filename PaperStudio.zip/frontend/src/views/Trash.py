import streamlit as st

from src.api import paper
from src.components.paper.PaperList import STATUS


def render():
    st.title("回收站")
    st.caption("删除的论文会保留在这里，直到恢复或明确要求永久删除。恢复论文不会恢复已经停止的后台任务，共享文献和向量索引不会被删除。")
    records = paper.trash()
    if not records:
        st.info("回收站为空。")
        return
    with st.container(border=True):
        st.warning("清空回收站会永久删除其中的全部论文及其任务记录，删除后无法恢复。")
        clear_confirmed = st.checkbox(
            "我确认永久删除回收站中的全部论文",
            key="confirm_empty_paper_trash")
        if st.button("清空回收站", key="empty_paper_trash", disabled=not clear_confirmed):
            result = paper.empty_trash()
            st.success(result.get("message") or "回收站已清空。")
            st.rerun()
    for item in records:
        with st.container(border=True):
            left, right = st.columns([5, 1])
            left.subheader(item["title"])
            right.caption(STATUS.get(item.get("deleted_from_status"), item.get("deleted_from_status") or "论文"))
            deleted_at = str(item.get("deleted_at") or "")[:16].replace("T", " ")
            st.caption(f"删除于 {deleted_at} · 恢复前不会出现在论文列表中")
            if st.button("恢复论文", key=f"restore_deleted_paper_{item['id']}", type="primary"):
                paper.restore_from_trash(item["id"])
                st.success("论文已恢复。")
                st.rerun()
            confirmed = st.checkbox(
                f"我确认永久删除《{item['title']}》",
                key=f"confirm_purge_deleted_paper_{item['id']}")
            if st.button("彻底删除", key=f"purge_deleted_paper_{item['id']}",
                         disabled=not confirmed):
                paper.purge_from_trash(item["id"])
                st.success(f"《{item['title']}》已永久删除。")
                st.rerun()
