﻿param([Parameter(Mandatory=$true)][string]$ProjectRoot)
$ErrorActionPreference = "Stop"
$packageRoot = $PSScriptRoot
$resolvedProject = (Resolve-Path -LiteralPath $ProjectRoot).Path.TrimEnd('\','/')
if (-not (Test-Path -LiteralPath (Join-Path $resolvedProject 'backend\app\main.py'))) {
    throw '目标目录不是兼容的 Paper Studio 项目。'
}
$manifest = Get-Content -LiteralPath (Join-Path $packageRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$operations = @()
foreach ($entry in $manifest.files) {
    $relative = $entry.path.Replace('/', '\')
    if ([IO.Path]::IsPathRooted($relative) -or ($relative.Split('\') -contains '..')) { throw '非法的包内路径' }
    $source = [IO.Path]::GetFullPath((Join-Path $packageRoot $relative))
    $target = [IO.Path]::GetFullPath((Join-Path $resolvedProject $relative))
    if (-not $source.StartsWith($packageRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or
        -not $target.StartsWith($resolvedProject + '\', [StringComparison]::OrdinalIgnoreCase)) { throw '路径越界' }
    if (-not (Test-Path -LiteralPath $source)) { throw "缺少文件：$relative" }
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $entry.sha256) { throw "文件校验失败：$relative" }
    $operations += [PSCustomObject]@{Relative=$relative;Source=$source;Target=$target;Existed=(Test-Path -LiteralPath $target)}
}
$backupRoot = Join-Path $resolvedProject ('_patch_backups\agent-console-v8-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
foreach ($item in $operations) {
    if ($item.Existed) {
        $backup = Join-Path $backupRoot $item.Relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $backup) -Force | Out-Null
        Copy-Item -LiteralPath $item.Target -Destination $backup -Force
    }
}
$operations | Select-Object Relative,Existed | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $backupRoot 'files.json') -Encoding UTF8
foreach ($item in $operations) {
    New-Item -ItemType Directory -Path (Split-Path -Parent $item.Target) -Force | Out-Null
    Copy-Item -LiteralPath $item.Source -Destination $item.Target -Force
}
Write-Host "v8 已安装。代码备份：$backupRoot"
Write-Host '请按原方式启动程序，并刷新浏览器。首次启动会转换旧版记忆格式。'
