import argparse
import hashlib
import json
import math
import re
import statistics
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "backend"))

from app.metrics import MetricsRecorder  # noqa: E402
from app.rag.ranking import bm25_rank, reciprocal_rank_fusion  # noqa: E402


def feature_vector(text, dimensions=384):
    vector = [0.0] * dimensions
    clean = re.sub(r"\s+", "", text.casefold())
    tokens = re.findall(r"[a-z0-9]+", text.casefold()) + [clean[index:index + 2]
                                                           for index in range(len(clean) - 1)]
    for token in tokens:
        digest = hashlib.sha256(token.encode()).digest()
        vector[int.from_bytes(digest[:4], "big") % dimensions] += 1.0
    norm = math.sqrt(sum(value * value for value in vector)) or 1.0
    return [value / norm for value in vector]


class OfflineEvaluationIndex:
    """Dependency-free mirror of the hash-vector/BM25/RRF retrieval path used for CI evaluation."""

    def __init__(self, documents, dense_weight, lexical_weight):
        self.documents = [{"chunk_id": f"eval-{item['id']}", "reference_id": item["id"],
                           "page": 1, "text": item["title"] + "\n" + item["text"]}
                          for item in documents]
        self.vectors = {item["chunk_id"]: feature_vector(item["text"]) for item in self.documents}
        self.dense_weight, self.lexical_weight = dense_weight, lexical_weight

    def dense_search(self, query, top_k):
        query_vector = feature_vector(query)
        results = []
        for item in self.documents:
            score = sum(left * right for left, right in zip(query_vector, self.vectors[item["chunk_id"]]))
            results.append({**item, "dense_score": score, "score": score, "retrieval_method": "dense"})
        return sorted(results, key=lambda item: item["score"], reverse=True)[:top_k]

    def lexical_search(self, query, top_k):
        return [{**item, "score": item["lexical_score"], "retrieval_method": "bm25"}
                for item in bm25_rank(query, self.documents, top_k)]

    def hybrid_search(self, query, top_k):
        fused = reciprocal_rank_fusion([(self.dense_search(query, top_k), self.dense_weight),
                                        (self.lexical_search(query, top_k), self.lexical_weight)])
        return [{**item, "score": item["fusion_score"], "retrieval_method": "hybrid_rrf"}
                for item in fused[:top_k]]


def percentile(values, percentile_value):
    if not values:
        return 0.0
    ordered = sorted(values)
    index = max(0, math.ceil(percentile_value / 100 * len(ordered)) - 1)
    return ordered[index]


def ranked_reference_ids(items, top_k):
    result = []
    for item in items:
        reference_id = int(item["reference_id"])
        if reference_id not in result:
            result.append(reference_id)
        if len(result) >= top_k:
            break
    return result


def case_metrics(retrieved, relevant, top_k):
    relevant = set(relevant)
    gains = [1 if reference_id in relevant else 0 for reference_id in retrieved[:top_k]]
    recall = sum(gains) / len(relevant) if relevant else 0.0
    precision = sum(gains) / top_k
    first = next((index for index, gain in enumerate(gains, 1) if gain), None)
    dcg = sum(gain / math.log2(index + 1) for index, gain in enumerate(gains, 1))
    ideal = sum(1 / math.log2(index + 1) for index in range(1, min(len(relevant), top_k) + 1))
    return {"hit": float(bool(sum(gains))), "recall": recall, "precision": precision,
            "reciprocal_rank": 1 / first if first else 0.0, "ndcg": dcg / ideal if ideal else 0.0}


def evaluate_method(store, cases, method, top_k):
    details, latencies = [], []
    search = {"dense": store.dense_search, "bm25": store.lexical_search,
              "hybrid": store.hybrid_search}[method]
    for case in cases:
        started = time.perf_counter()
        items = search(case["query"], max(top_k * 4, 20))
        latency = (time.perf_counter() - started) * 1000
        retrieved = ranked_reference_ids(items, top_k)
        metrics = case_metrics(retrieved, case["relevant_document_ids"], top_k)
        details.append({"case_id": case["id"], "retrieved_document_ids": retrieved,
                        "relevant_document_ids": case["relevant_document_ids"],
                        "latency_ms": round(latency, 3), **{key: round(value, 6) for key, value in metrics.items()}})
        latencies.append(latency)
    keys = ("hit", "recall", "precision", "reciprocal_rank", "ndcg")
    summary = {key: round(statistics.fmean(item[key] for item in details), 6) for key in keys}
    summary.update({"mean_latency_ms": round(statistics.fmean(latencies), 3),
                    "p95_latency_ms": round(percentile(latencies, 95), 3), "case_count": len(details)})
    return {"summary": summary, "cases": details}


def main():
    parser = argparse.ArgumentParser(description="运行 Paper Studio 离线检索评测并记录 JSONL 指标。")
    parser.add_argument("--dataset", type=Path, default=PROJECT_ROOT / "evaluation" / "retrieval_dataset.json")
    parser.add_argument("--output", type=Path, default=PROJECT_ROOT / "evaluation" / "results" / "latest.json")
    parser.add_argument("--metrics-log", type=Path, default=PROJECT_ROOT / "backend" / "data" / "logs" / "metrics.jsonl")
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--dense-weight", type=float, default=0.65)
    parser.add_argument("--lexical-weight", type=float, default=0.35)
    args = parser.parse_args()
    dataset = json.loads(args.dataset.read_text(encoding="utf-8"))
    index_started = time.perf_counter()
    store = OfflineEvaluationIndex(dataset["documents"], args.dense_weight, args.lexical_weight)
    index_duration = (time.perf_counter() - index_started) * 1000
    total_chunks = len(store.documents)
    methods = {method: evaluate_method(store, dataset["cases"], method, args.top_k)
               for method in ("dense", "bm25", "hybrid")}

    result = {"evaluated_at": datetime.now(timezone.utc).isoformat(),
              "dataset": {"name": dataset["name"], "version": dataset["version"],
                          "document_count": len(dataset["documents"]), "case_count": len(dataset["cases"]),
                          "synthetic": True},
              "configuration": {"embedding_provider": "hash", "top_k": args.top_k,
                                "dense_weight": args.dense_weight,
                                "lexical_weight": args.lexical_weight},
              "engineering": {"index_duration_ms": round(index_duration, 3), "indexed_chunks": total_chunks},
              "methods": methods}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    recorder = MetricsRecorder(args.metrics_log)
    recorder.record("evaluation_run", dataset=dataset["name"], dataset_version=dataset["version"],
                    top_k=args.top_k, document_count=len(dataset["documents"]), case_count=len(dataset["cases"]),
                    index_duration_ms=round(index_duration, 3), indexed_chunks=total_chunks,
                    results={method: data["summary"] for method, data in methods.items()},
                    result_file=str(args.output.resolve()))
    print(json.dumps({"result_file": str(args.output.resolve()), "metrics_log": str(args.metrics_log.resolve()),
                      "summaries": {method: data["summary"] for method, data in methods.items()}},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
