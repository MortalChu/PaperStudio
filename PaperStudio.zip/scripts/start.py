"""Start both services and stop child processes together with Ctrl+C."""
import argparse
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import threading
import time
import tomllib
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parents[1]
OUTPUT_LOCK = threading.Lock()


def output(label, message):
    with OUTPUT_LOCK:
        print(f"[{label}] {message}", flush=True)


def forward_output(process, label):
    # Windows 隐藏子进程窗口时，不能依赖其自动继承父控制台。
    # 持续读取管道，避免输出积满后阻塞后端；标准错误也合并到同一管道。
    with process.stdout:
        for line in process.stdout:
            try:
                output(label, line.rstrip("\r\n"))
            except (OSError, ValueError):
                # 父终端输出被关闭时仍排空子进程管道，避免服务卡住。
                continue


def launch_service(label, arguments, directory, extra_env=None):
    env = {**os.environ, **(extra_env or {}), "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8"}
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    process = subprocess.Popen([sys.executable, "-u", *arguments], cwd=directory, env=env,
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace", bufsize=1, creationflags=flags)
    reader = threading.Thread(target=forward_output, args=(process, label), daemon=True,
                              name=f"{label}-output")
    reader.start()
    output("启动", f"{label}进程 PID={process.pid}，输出已接入当前终端。")
    return process, reader


def check_port(port):
    with socket.socket() as sock:
        try:
            sock.bind(("127.0.0.1", port))
        except OSError as exc:
            raise SystemExit(f"Port {port} is in use. Select another port with --api-port / --ui-port.") from exc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--api-port", type=int, default=8000)
    parser.add_argument("--ui-port", type=int, default=8501)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    check_port(args.api_port)
    check_port(args.ui_port)
    envfile = ROOT / "backend/.env"
    if not envfile.exists():
        shutil.copyfile(ROOT / "backend/.env.example", envfile)
    processes = []
    readers = []
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    try:
        process, reader = launch_service("后端", ["-m", "uvicorn", "app.main:app", "--host", "127.0.0.1",
                "--port", str(args.api_port), "--workers", "1"], ROOT / "backend")
        processes.append(process)
        readers.append(reader)
        for _ in range(120):
            if processes[0].poll() is not None:
                raise SystemExit(f"后端启动失败，退出码 {processes[0].returncode}；请查看 [后端] 输出。")
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{args.api_port}/health", timeout=1):
                    break
            except OSError:
                time.sleep(.5)
        else:
            raise SystemExit("Backend startup timed out.")
        env = {"API_BASE_URL": f"http://127.0.0.1:{args.api_port}"}
        # 从项目配置显式传入主题，防止启动环境中的同名变量覆盖项目配色。
        with (ROOT / "frontend/.streamlit/config.toml").open("rb") as config_file:
            theme = tomllib.load(config_file)["theme"]
        theme_args = [part for name, value in theme.items() for part in (f"--theme.{name}", str(value))]
        process, reader = launch_service("前端", ["-m", "streamlit", "run", "src/main.py",
            "--server.port", str(args.ui_port), "--server.address", "127.0.0.1", "--server.headless", "true", *theme_args],
            ROOT / "frontend", env)
        processes.append(process)
        readers.append(reader)
        output("启动", f"UI: http://127.0.0.1:{args.ui_port} | API docs: http://127.0.0.1:{args.api_port}/docs")
        if not args.no_browser:
            webbrowser.open(f"http://127.0.0.1:{args.ui_port}")
        while all(p.poll() is None for p in processes):
            time.sleep(.5)
        exited = next((label, p.returncode) for label, p in zip(("后端", "前端"), processes) if p.poll() is not None)
        raise SystemExit(f"{exited[0]}服务已退出，退出码 {exited[1]}；请查看对应的终端输出。")
    except KeyboardInterrupt:
        output("启动", "正在停止前后端服务…")
    finally:
        for process in reversed(processes):
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)
        for reader in readers:
            reader.join(timeout=2)


if __name__ == "__main__":
    main()
