param([int]$ApiPort = 8000, [int]$UiPort = 8501)
$ErrorActionPreference = 'Stop'
$ProjectPython = Join-Path $PSScriptRoot '.venv/Scripts/python.exe'
& $ProjectPython (Join-Path $PSScriptRoot 'scripts/start.py') --api-port $ApiPort --ui-port $UiPort
