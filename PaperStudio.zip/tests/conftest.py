import pytest
from fastapi.testclient import TestClient
from app.config import Settings
from app.main import create_app


@pytest.fixture
def cfg(tmp_path):
    return Settings(_env_file=None, DATA_DIR=tmp_path, DATABASE_URL=f"sqlite+aiosqlite:///{tmp_path.as_posix()}/test.db",
                    VECTOR_DB_PATH=tmp_path / "chroma", CHECKPOINT_PATH=tmp_path / "checkpoint.sqlite",
                    METRICS_LOG_PATH=tmp_path / "logs" / "metrics.jsonl",
                    LLM_PROVIDER="demo", EMBEDDING_PROVIDER="hash", SECRET_KEY="t" * 48)


@pytest.fixture
def client(cfg):
    with TestClient(create_app(cfg)) as client:
        yield client


def account(client, name="researcher"):
    response = client.post("/api/auth/register", json={"username": name, "email": name + "@example.com", "password": "testing-pass-123"})
    assert response.status_code == 201, response.text
    response = client.post("/api/auth/login", json={"username": name, "password": "testing-pass-123"})
    assert response.status_code == 200, response.text
    return {"Authorization": "Bearer " + response.json()["access_token"]}


@pytest.fixture
def headers(client):
    return account(client)
