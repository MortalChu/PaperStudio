import json

from app.metrics import MetricsRecorder
from app.rag.ranking import bm25_rank, reciprocal_rank_fusion


def test_bm25_and_rank_fusion_recover_complementary_candidates():
    documents = [
        {"chunk_id": "a", "reference_id": 1, "text": "BM25 稀疏检索适合精确术语"},
        {"chunk_id": "b", "reference_id": 2, "text": "语义向量用于同义表达召回"},
    ]
    lexical = bm25_rank("BM25 精确术语", documents, 2)
    assert lexical[0]["reference_id"] == 1
    dense = [{**documents[1], "dense_score": 0.9, "score": 0.9},
             {**documents[0], "dense_score": 0.5, "score": 0.5}]
    fused = reciprocal_rank_fusion([(dense, 0.65), (lexical, 0.35)])
    assert {item["reference_id"] for item in fused} == {1, 2}
    assert all(0 < item["fusion_score"] <= 1 for item in fused)


def test_metrics_recorder_writes_independent_jsonl(tmp_path):
    path = tmp_path / "logs" / "metrics.jsonl"
    recorder = MetricsRecorder(path)
    recorder.record("evaluation_run", recall_at_5=0.8, latency_ms=12.5)
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["event"] == "evaluation_run"
    assert payload["recall_at_5"] == 0.8
