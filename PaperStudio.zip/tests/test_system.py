import time
from fastapi.testclient import TestClient
from app.main import create_app
from conftest import account


def wait_reference_job(client, headers, response, expected="completed"):
    if not isinstance(response, dict):
        assert response.status_code == 202, response.text
        response = response.json()
    for _ in range(1000):
        result = client.get(f"/api/references/jobs/{response['id']}", headers=headers)
        assert result.status_code == 200, result.text
        job = result.json()
        if job["status"] in ("completed", "failed"):
            assert job["status"] == expected, job
            return job
        time.sleep(.02)
    raise AssertionError("reference job did not finish")


def saved_reference(client, headers, response, expected="completed"):
    job = wait_reference_job(client, headers, response, expected)
    result = client.get(f"/api/references/{job['reference_id']}", headers=headers)
    assert result.status_code == 200, result.text
    return {**result.json(), "duplicate": job["duplicate"]}


def paper(client, headers, **changes):
    response = client.post("/api/papers/", headers=headers, json={"title": "检索增强生成的可靠性研究", "topic": "人工智能",
                                "keywords": "检索增强,可靠性", "word_limit": 2000, **changes})
    assert response.status_code == 201, response.text
    return response.json()


def wait_run(client, headers, paper_id, run_id):
    for _ in range(500):
        response = client.get(f"/api/papers/{paper_id}/runs/{run_id}", headers=headers)
        assert response.status_code == 200, response.text
        data = response.json()
        if data["status"] == "waiting" and data.get("requests") and \
                data["requests"][0].get("kind") == "review_preference":
            resumed = client.post(f"/api/papers/{paper_id}/runs/{run_id}/resume",
                                  headers=headers, json={"auto_review": True})
            assert resumed.status_code == 202, resumed.text
            continue
        if data["status"] != "running":
            assert data["status"] != "failed", data
            return data
        time.sleep(.02)
    raise AssertionError("workflow did not finish")


def wait_global_turn(client, headers, message):
    response = client.post("/api/agent/global/turns", headers=headers, json={"message": message})
    assert response.status_code == 202, response.text
    turn_id = response.json()["turn_id"]
    for _ in range(500):
        state = client.get(f"/api/agent/global/turns/{turn_id}", headers=headers)
        assert state.status_code == 200, state.text
        if state.json()["status"] in ("completed", "failed", "interrupted"):
            return state.json()
        time.sleep(.02)
    raise AssertionError("global agent turn did not finish")


def test_health_and_access_control(client, headers):
    health = client.get("/health").json()
    assert health["versions"]["langchain"] == "1.3.18"
    assert health["versions"]["langgraph"] == "1.2.11"
    assert health["retrieval_mode"] == "hybrid"
    assert health["agent_mode"] == "autonomous_plan_act_observe_reflect"
    assert client.get("/api/papers/").status_code == 401
    p = paper(client, headers)
    other = account(client, "other_user")
    assert client.get(f"/api/papers/{p['id']}", headers=other).status_code == 404
    assert client.get("/api/papers/", headers=other).json() == []
    assert client.post("/api/auth/login", json={"username": "researcher", "password": "wrong"}).status_code == 401


def test_global_agent_lists_natural_language_question(client, headers):
    first = paper(client, headers, title="第一篇已有论文任务")
    second = paper(client, headers, title="第二篇已有论文任务")
    result = wait_global_turn(client, headers, "我当前已存在的论文任务有哪些？它们分别是什么状态？")
    assert result["status"] == "completed" and result["operation"] == "list"
    assert first["title"] in result["content"] and second["title"] in result["content"]
    assert "草稿" in result["content"]
    sessions = client.get("/api/agent/global/sessions", headers=headers).json()
    assert len(sessions) == 1 and sessions[0]["message_count"] == 2
    messages = client.get("/api/agent/global/messages", headers=headers,
                          params={"session_id": result["session_id"]}).json()
    assert [item["role"] for item in messages] == ["user", "assistant"]


def test_global_agent_really_empties_trash_before_reporting_success(client, headers):
    first = paper(client, headers, title="等待永久删除的第一篇论文")
    second = paper(client, headers, title="等待永久删除的第二篇论文")
    assert client.delete(f"/api/papers/{first['id']}", headers=headers).status_code == 204
    assert client.delete(f"/api/papers/{second['id']}", headers=headers).status_code == 204
    assert len(client.get("/api/papers/trash", headers=headers).json()) == 2

    status = wait_global_turn(client, headers, "回收站清空了吗？")
    assert status["operation"] == "trash_status" and "2 篇" in status["content"]
    assert len(client.get("/api/papers/trash", headers=headers).json()) == 2
    result = wait_global_turn(client, headers, "请清空回收站")
    assert result["status"] == "completed" and result["operation"] == "purge_trash"
    assert "永久删除 2 篇" in result["content"]
    assert client.get("/api/papers/trash", headers=headers).json() == []
    assert client.get(f"/api/papers/{first['id']}", headers=headers).status_code == 404
    assert client.get(f"/api/papers/{second['id']}", headers=headers).status_code == 404


def test_agent_capabilities_and_trace_are_grounded(client, headers):
    capabilities = client.get("/api/agent/global/capabilities", headers=headers)
    assert capabilities.status_code == 200
    names = {item["name"] for item in capabilities.json()}
    assert {"list_papers", "empty_trash", "pause_task", "revise_paper", "set_preferences"} <= names
    assert next(item for item in capabilities.json() if item["name"] == "empty_trash")["destructive"] is True

    paper(client, headers, title="用于验证自主智能体轨迹的论文")
    result = wait_global_turn(client, headers, "列出我的全部论文及状态")
    assert result["operation"] == "list"
    messages = client.get("/api/agent/global/messages", headers=headers,
                          params={"session_id": result["session_id"]}).json()
    details = messages[-1]["details"]
    assert details["agent_trace"][0]["stage"] == "plan"
    assert any(item["stage"] == "verification" for item in details["agent_trace"])
    assert details["observations"][0]["tool"] == "list_papers"
    assert details["observations"][0]["ok"] is True


def test_unsupported_operation_never_claims_it_is_processing(client, headers):
    result = wait_global_turn(client, headers, "请替我预订明天去上海的机票")
    assert result["status"] == "completed"
    assert "无法执行" in result["content"]
    assert "正在处理" not in result["content"]
    assert "已经执行" not in result["content"]


def test_autonomous_loop_can_reflect_and_choose_a_second_tool():
    import asyncio
    from app.services.agent_runtime import AutonomousAgentLoop, ToolRegistry, ToolSpec

    executed = []

    async def first(arguments):
        executed.append(("inspect", arguments))
        return {"message": "已读取状态", "needs_fix": True}

    async def second(arguments):
        executed.append(("fix", arguments))
        return {"message": "已完成修复"}

    class Planner:
        async def plan(self, data):
            return {"goal": "检查后按需修复", "response_mode": "tool",
                    "tool_calls": [{"name": "inspect", "arguments": {}, "purpose": "检查"}],
                    "decision_summary": "先检查实际状态"}

        async def reflect(self, data):
            if len(data["observations"]) == 1:
                return {"goal_satisfied": False, "requires_user_input": False,
                        "next_tool_calls": [{"name": "fix", "arguments": {"mode": "safe"},
                                             "purpose": "根据观察修复"}],
                        "reflection_summary": "检查结果表明还需要修复"}
            return {"goal_satisfied": True, "requires_user_input": False,
                    "next_tool_calls": [], "reflection_summary": "目标已经满足"}

    registry = ToolRegistry()
    registry.register(ToolSpec("inspect", "读取状态", {"type": "object", "properties": {}}, first))
    registry.register(ToolSpec("fix", "执行修复", {"type": "object", "properties": {
        "mode": {"type": "string"}}, "required": ["mode"]}, second))
    result = asyncio.run(AutonomousAgentLoop(Planner(), registry).run({"message": "检查并修复"}))
    assert [name for name, _ in executed] == ["inspect", "fix"]
    assert result["reflection"]["goal_satisfied"] is True
    assert [item["stage"] for item in result["trace"]] == ["plan", "reflect", "reflect"]


def test_manual_permanent_delete_and_empty_trash(client, headers):
    first = paper(client, headers, title="手动彻底删除的论文")
    second = paper(client, headers, title="手动清空回收站的论文")
    for item in (first, second):
        assert client.delete(f"/api/papers/{item['id']}", headers=headers).status_code == 204
    purged = client.delete(f"/api/papers/trash/{first['id']}/purge", headers=headers)
    assert purged.status_code == 204
    remaining = client.get("/api/papers/trash", headers=headers).json()
    assert [item["id"] for item in remaining] == [second["id"]]
    cleared = client.delete("/api/papers/trash", headers=headers)
    assert cleared.status_code == 200
    assert cleared.json()["deleted_count"] == 1
    assert client.get("/api/papers/trash", headers=headers).json() == []


def test_global_history_session_can_be_permanently_deleted(client, headers):
    result = wait_global_turn(client, headers, "列出我当前的论文")
    session_id = result["session_id"]
    assert client.get("/api/agent/global/messages", headers=headers,
                      params={"session_id": session_id}).status_code == 200
    deleted = client.delete(f"/api/agent/global/sessions/{session_id}", headers=headers)
    assert deleted.status_code == 204, deleted.text
    assert client.get("/api/agent/global/sessions", headers=headers).json() == []
    assert client.get("/api/agent/global/messages", headers=headers,
                      params={"session_id": session_id}).status_code == 404


def test_login_errors_are_distinct_from_expired_sessions(client, cfg):
    import jwt
    missing = client.post("/api/auth/login", json={"username": "never_registered", "password": "unused-password"})
    assert missing.status_code == 401
    assert missing.headers["X-Auth-Error"] == "credentials_invalid"
    assert "过期" not in missing.json()["detail"]
    anonymous = client.get("/api/papers/")
    assert anonymous.headers["X-Auth-Error"] == "login_required"
    expired = jwt.encode({"sub": "1", "exp": int(time.time()) - 60}, cfg.SECRET_KEY, algorithm="HS256")
    result = client.get("/api/papers/", headers={"Authorization": "Bearer " + expired})
    assert result.headers["X-Auth-Error"] == "session_expired"


def test_failed_index_is_pending_material_and_bulk_retry_skips_ready(client, headers, monkeypatch):
    from app.rag.vector_store import IndexBuildError
    ready = saved_reference(client, headers, client.post("/api/references/", headers=headers,
        json={"title": "检索增强可用资料", "abstract": "检索增强可用资料的正文与研究方法。"}))
    store = client.app.state.vector_store
    build = store.add_reference

    class ProviderError(Exception):
        status_code = 401

    def fail(*args):
        raise IndexBuildError("embedding", ProviderError("secret-must-not-appear"))

    monkeypatch.setattr(store, "add_reference", fail)
    response = client.post("/api/references/", headers=headers,
        json={"title": "索引失败资料", "abstract": "索引失败资料暂存以便之后恢复处理。"})
    assert response.status_code == 202
    failed = saved_reference(client, headers, response, expected="failed")
    assert failed["index_status"] == "failed"
    assert failed["index_error"]["code"] == "embedding_auth"
    assert "secret-must-not-appear" not in str(failed)
    stats = client.get("/api/references/stats", headers=headers).json()
    assert stats["total"] == 2 and stats["indexed"] == 1 and stats["failed"] == 1
    usable = client.get("/api/references/?status=indexed", headers=headers).json()
    assert [ref["id"] for ref in usable] == [ready["id"]]
    persisted = client.get(f"/api/references/{failed['id']}", headers=headers).json()
    assert persisted["index_error"] == failed["index_error"]
    hits = client.get("/api/references/search", headers=headers, params={"query": "索引失败资料"}).json()
    assert all(hit["id"] != failed["id"] for hit in hits)
    rebuilt = []

    def record_build(reference, pages, progress=None):
        rebuilt.append(reference["id"])
        return build(reference, pages, progress)

    monkeypatch.setattr(store, "add_reference", record_build)
    assert client.post("/api/references/reindex-all", headers=headers).status_code == 202
    for _ in range(500):
        if client.get("/api/references/stats", headers=headers).json()["rebuild"]["status"] != "running":
            break
        time.sleep(.02)
    current = client.get(f"/api/references/{failed['id']}", headers=headers).json()
    assert current["index_status"] == "indexed" and current["index_error"] == {}
    assert rebuilt == [failed["id"]]


def test_index_diagnostics_migration_preserves_existing_rows():
    from sqlalchemy import create_engine, text
    from app.services.reference_service import migrate_index_diagnostics
    engine = create_engine("sqlite://")
    try:
        with engine.begin() as connection:
            connection.execute(text("CREATE TABLE library_references (id INTEGER PRIMARY KEY)"))
            connection.execute(text("INSERT INTO library_references (id) VALUES (7)"))
            migrate_index_diagnostics(connection)
            migrate_index_diagnostics(connection)
            row = connection.execute(text("SELECT id, index_error FROM library_references")).one()
            assert tuple(row) == (7, "{}")
    finally:
        engine.dispose()


def test_agent_preference_migration_is_additive_and_idempotent():
    from sqlalchemy import create_engine, inspect, text
    from app.services.agent_service import migrate_agent_storage
    engine = create_engine("sqlite://")
    try:
        with engine.begin() as connection:
            connection.execute(text("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT)"))
            connection.execute(text("CREATE TABLE papers (id INTEGER PRIMARY KEY, title TEXT)"))
            connection.execute(text("INSERT INTO users (id, username) VALUES (1, 'legacy')"))
            connection.execute(text("INSERT INTO papers (id, title) VALUES (2, 'legacy paper')"))
            connection.execute(text("INSERT INTO users (id, username) VALUES (1, 'old-user')"))
            connection.execute(text("INSERT INTO papers (id, title) VALUES (2, 'old-paper')"))
            migrate_agent_storage(connection)
            migrate_agent_storage(connection)
            assert "preferences" in {item["name"] for item in inspect(connection).get_columns("users")}
            assert "agent_preferences" in {item["name"] for item in inspect(connection).get_columns("papers")}
            assert connection.execute(text("SELECT preferences FROM users WHERE id=1")).scalar() == "{}"
            assert connection.execute(text("SELECT agent_preferences FROM papers WHERE id=2")).scalar() == "{}"
    finally:
        engine.dispose()


def test_paper_console_migration_is_additive_and_idempotent():
    from sqlalchemy import create_engine, inspect, text
    from app.services.paper_service import migrate_paper_console
    engine = create_engine("sqlite://")
    try:
        with engine.begin() as connection:
            connection.execute(text("CREATE TABLE papers (id INTEGER PRIMARY KEY, title TEXT)"))
            connection.execute(text("INSERT INTO papers (id, title) VALUES (2, 'legacy paper')"))
            migrate_paper_console(connection)
            migrate_paper_console(connection)
            columns = {item["name"] for item in inspect(connection).get_columns("papers")}
            assert {"outline_revision", "deleted_at", "deleted_from_status", "purge_after",
                    "finished_at"} <= columns
            row = connection.execute(text(
                "SELECT id, outline_revision, deleted_at, deleted_from_status FROM papers WHERE id=2")).one()
            assert tuple(row) == (2, 0, None, "")
    finally:
        engine.dispose()


def test_global_session_migration_preserves_legacy_messages():
    from sqlalchemy import create_engine, inspect, text
    from app.services.paper_service import migrate_global_agent_sessions
    engine = create_engine("sqlite://")
    try:
        with engine.begin() as connection:
            connection.execute(text("""CREATE TABLE global_agent_sessions (
                id INTEGER PRIMARY KEY, user_id INTEGER, title TEXT,
                created_at DATETIME, updated_at DATETIME)"""))
            connection.execute(text("""CREATE TABLE global_agent_messages (
                id INTEGER PRIMARY KEY, user_id INTEGER, role TEXT, content TEXT,
                status TEXT, action TEXT, details JSON, created_at DATETIME, completed_at DATETIME)"""))
            connection.execute(text("""INSERT INTO global_agent_messages
                (id,user_id,role,content,status,action,details,created_at)
                VALUES (1,7,'user','旧问题','completed','none','{}','2026-09-01 01:00:00'),
                       (2,7,'assistant','旧回答','completed','respond','{}','2026-09-01 01:01:00')"""))
            migrate_global_agent_sessions(connection)
            migrate_global_agent_sessions(connection)
            assert "session_id" in {item["name"] for item in inspect(connection).get_columns(
                "global_agent_messages")}
            assert connection.execute(text("SELECT count(*) FROM global_agent_sessions")).scalar() == 1
            assert connection.execute(text(
                "SELECT count(*) FROM global_agent_messages WHERE session_id IS NOT NULL")).scalar() == 2
    finally:
        engine.dispose()


def test_outline_manual_save_soft_delete_and_restore(client, headers):
    p = paper(client, headers)
    outline = {"title": "可直接编辑并保存的论文大纲", "sections": [{
        "title": "引言", "points": ["研究背景", "问题定义"],
        "word_count": 500, "subsections": []}]}
    saved = client.put(f"/api/papers/{p['id']}/outline", headers=headers,
                       json={"outline": outline, "expected_revision": 0, "source": "manual"})
    assert saved.status_code == 200, saved.text
    assert saved.json()["outline"] == outline and saved.json()["outline_revision"] == 1
    stale = client.put(f"/api/papers/{p['id']}/outline", headers=headers,
                       json={"outline": outline, "expected_revision": 0, "source": "auto"})
    assert stale.status_code == 409

    changed = client.post(f"/api/agent/{p['id']}/chat", headers=headers,
                          json={"message": "把目标字数改为 3000 字"})
    assert changed.status_code == 200, changed.text
    assert changed.json()["operation"] == "update"
    assert client.get(f"/api/papers/{p['id']}", headers=headers).json()["word_limit"] == 3000

    removed = client.post(f"/api/agent/{p['id']}/chat", headers=headers,
                          json={"message": "删除当前论文"})
    assert removed.status_code == 200, removed.text
    assert removed.json()["operation"] == "delete"
    assert client.get(f"/api/papers/{p['id']}", headers=headers).status_code == 404
    recycled = client.get("/api/papers/trash", headers=headers).json()
    assert [item["id"] for item in recycled] == [p["id"]]
    restored = client.post(f"/api/papers/trash/{p['id']}/restore", headers=headers)
    assert restored.status_code == 200, restored.text
    assert restored.json()["outline"] == outline and restored.json()["active_run_id"] is None


def test_full_workflow_versions_and_sse(client, headers, cfg):
    p = paper(client, headers)
    review = client.post(f"/api/agent/{p['id']}/chat", headers=headers,
                         json={"message": "本论文需要自动核对"})
    assert review.status_code == 200, review.text
    assert review.json()["preferences"]["auto_review"] is True
    ref = client.post("/api/references/", headers=headers, json={"paper_id": p["id"], "title": "检索增强可靠性测试材料",
                      "authors": "测试作者", "year": 2025, "abstract": "检索增强生成通过引用可核验的文献改善回答的可追溯性。"})
    ref = saved_reference(client, headers, ref)
    result = client.get("/api/references/search", headers=headers, params={"paper_id": p["id"], "query": "检索增强"})
    assert result.status_code == 200, result.text
    assert result.json()[0]["id"] == ref["id"]
    assert result.json()[0]["retrieval_method"] == "hybrid_rrf"
    response = client.post(f"/api/papers/{p['id']}/generate", headers=headers, json={"review_outline": False})
    assert response.status_code == 202, response.text
    run_id = response.json()["run_id"]
    finished = wait_run(client, headers, p["id"], run_id)
    assert finished["status"] == "completed"
    assert any(event.get("kind") == "agent_decision" for event in finished["events"])
    assert any(event.get("kind") == "reflection" for event in finished["events"])
    p = client.get(f"/api/papers/{p['id']}", headers=headers).json()
    assert len(p["chapters"]) == 7
    assert all(c["content"] for c in p["chapters"])
    section_starts = [event.get("section_key") for event in finished["events"]
                      if event.get("kind") == "step_start" and event.get("step") == "write_section"]
    assert section_starts == [chapter["section_key"] for chapter in p["chapters"]]
    assert "参考文献" in p["final_paper"] and "[1]" in p["final_paper"]
    assert p["status"] == "review"  # demo never claims scholarly validation
    assert p["finished_at"] is not None
    assert p["active_run_id"] is None
    assert p["quality_report"]["reflection"]["decision"] == "finish"
    metric_events = [__import__("json").loads(line) for line in cfg.METRICS_LOG_PATH.read_text(encoding="utf-8").splitlines()]
    assert any(item["event"] == "retrieval" for item in metric_events)
    assert any(item["event"] == "workflow_node" and item["node"] == "plan_next" for item in metric_events)
    reviewed = client.post(f"/api/papers/{p['id']}/complete-review", headers=headers)
    assert reviewed.status_code == 200, reviewed.text
    p = reviewed.json()
    assert p["status"] == "completed" and p["quality_report"]["human_reviewed"] is True
    protected = client.post(f"/api/papers/{p['id']}/generate", headers=headers, json={"review_outline": False})
    assert protected.status_code == 422
    assert "明确确认重新生成" in protected.json()["detail"]
    assert client.get(f"/api/papers/{p['id']}", headers=headers).json()["final_paper"] == p["final_paper"]
    stream = client.get(f"/api/papers/{p['id']}/runs/{run_id}/events", headers=headers)
    assert "event: token" in stream.text and "event: done" in stream.text
    last = client.get(f"/api/papers/{p['id']}/runs/{run_id}/events?after=999999", headers=headers)
    assert "event: token" not in last.text and "event: end" in last.text
    versions = client.get(f"/api/papers/{p['id']}/versions", headers=headers).json()
    final_version = versions[0]["id"]
    chapter = p["chapters"][0]
    update = client.put(f"/api/chapters/{chapter['id']}", headers=headers, json={"content": "人工修改的内容"})
    assert update.status_code == 200, update.text
    assert "人工修改的内容" in client.get(f"/api/papers/{p['id']}/export", headers=headers).text
    restored = client.post(f"/api/papers/{p['id']}/versions/{final_version}/restore", headers=headers)
    assert restored.status_code == 200, restored.text
    assert restored.json()["final_paper"] == p["final_paper"]
    assert restored.json()["chapters"][0]["content"] == chapter["content"]
    assert client.delete(f"/api/papers/{p['id']}", headers=headers).status_code == 204
    assert client.get("/api/references/", headers=headers).json()[0]["id"] == ref["id"]


def test_conversational_preferences_and_targeted_revision(client, headers):
    p = paper(client, headers)
    greeting = client.get(f"/api/agent/{p['id']}/messages", headers=headers).json()
    assert greeting == []
    assert p["agent_preferences"]["auto_review"] is False
    streamed = client.post(f"/api/agent/{p['id']}/chat/stream", headers=headers,
        json={"message": "本论文保持简洁表达"})
    assert streamed.status_code == 200, streamed.text
    assert '"kind": "accepted"' in streamed.text
    assert '"kind": "token"' in streamed.text
    assert '"kind": "done"' in streamed.text
    streamed_messages = client.get(f"/api/agent/{p['id']}/messages", headers=headers).json()
    assert any(item["role"] == "user" and item["content"] == "本论文保持简洁表达"
               for item in streamed_messages)
    assert streamed_messages[-1]["role"] == "assistant" and streamed_messages[-1]["content"]
    configured = client.post(f"/api/agent/{p['id']}/chat", headers=headers,
        json={"message": "本论文不需要核对，把【待验证】标记改成红色，把质量问题折叠"})
    assert configured.status_code == 200, configured.text
    configured = configured.json()
    assert configured["operation"] == "none"
    assert configured["preferences"]["auto_review"] is False
    assert configured["preferences"]["annotation_color"] == "#C62828"
    assert configured["preferences"]["collapse_quality_issues"] is True

    remembered = client.post(f"/api/agent/{p['id']}/chat", headers=headers,
        json={"message": "以后都采用简洁的学术写作风格，记住这个偏好"})
    assert remembered.status_code == 200, remembered.text
    account_preferences = client.get("/api/auth/preferences", headers=headers).json()
    assert "简洁" in account_preferences["writing_style"]
    inherited = paper(client, headers, title="新账号偏好继承到后续创建的论文任务")
    assert "简洁" in inherited["agent_preferences"]["writing_style"]

    saved_reference(client, headers, client.post("/api/references/", headers=headers,
        json={"title": "对话式论文智能体检索与定向修改测试文献",
              "abstract": "论文智能体通过检索、持续对话和定向章节修改改善写作过程。"}))
    started = client.post(f"/api/papers/{p['id']}/generate", headers=headers,
                          json={"review_outline": False})
    run_id = started.json()["run_id"]
    finished = wait_run(client, headers, p["id"], run_id)
    assert finished["status"] == "completed"
    assert not any(event.get("kind") == "reflection" for event in finished["events"])

    followup = client.post(f"/api/agent/{p['id']}/chat", headers=headers,
        json={"message": "重写第2章，强调方法的适用边界"})
    assert followup.status_code == 200, followup.text
    followup_run = followup.json()["run_id"]
    assert followup_run
    revised = wait_run(client, headers, p["id"], followup_run)
    section_starts = {event.get("section_key") for event in revised["events"]
                      if event.get("kind") == "step_start" and event.get("step") == "write_section"}
    assert section_starts == {"2"}
    conversation = client.get(f"/api/agent/{p['id']}/messages", headers=headers).json()
    request_turn = next(item for item in conversation if item["content"].startswith("重写第2章"))
    assert request_turn["status"] == "completed"
    assert client.get(f"/api/papers/{p['id']}/versions", headers=headers).json()[0]["label"] == "Agent 增量修改完成"


def test_active_word_limit_update_pauses_without_releasing_paper(client, headers, monkeypatch):
    import asyncio
    from langchain_core.runnables import RunnableLambda
    import app.agents.base_agent as base_agent
    from app.utils.llm import demo_response

    async def delayed_model(prompt):
        await asyncio.sleep(30)
        return demo_response(prompt)

    # Agent 在首次使用时才创建模型，因此可以稳定地把大纲节点保持在运行状态。
    monkeypatch.setattr(base_agent, "get_llm", lambda settings, temperature=0.4: RunnableLambda(delayed_model))
    p = paper(client, headers)
    saved_reference(client, headers, client.post("/api/references/", headers=headers,
        json={"title": "检索增强生成可靠性暂停任务测试文献",
              "abstract": "检索增强生成可靠性研究资料，用于测试论文工作流暂停、检查点保留和恢复控制。"}))
    started = client.post(f"/api/papers/{p['id']}/generate", headers=headers, json={"review_outline": False})
    assert started.status_code == 202, started.text
    run_id = started.json()["run_id"]
    path = f"/api/papers/{p['id']}/runs/{run_id}"
    for _ in range(500):
        status = client.get(path, headers=headers).json()
        if any(event.get("kind") == "step_start" and event.get("step") == "generate_outline"
               for event in status["events"]):
            break
        time.sleep(.02)
    else:
        raise AssertionError("outline node did not start")
    changed = client.put(f"/api/papers/{p['id']}/word-limit", headers=headers, json={"word_limit": 3500})
    assert changed.status_code == 200 and changed.json()["paused"] is True, changed.text
    status = client.get(path, headers=headers).json()
    assert status["status"] == "paused" and status["checkpoint_readable"] is True
    detail = client.get(f"/api/papers/{p['id']}", headers=headers).json()
    assert detail["active_run_id"] == run_id and detail["word_limit"] == 3500
    snapshot = client.get(path + "/event-snapshot", headers=headers).json()
    assert any(event.get("kind") == "paused" for event in snapshot["events"])
    assert client.post(path + "/cancel", headers=headers).status_code == 200
    assert client.get(f"/api/papers/{p['id']}", headers=headers).json()["active_run_id"] is None


def test_interrupt_survives_restart(cfg):
    with TestClient(create_app(cfg)) as client:
        headers = account(client)
        saved_reference(client, headers, client.post("/api/references/", headers=headers, json={"title": "用户确认的具体研究题目：检索增强生成研究",
            "abstract": "人工智能与检索增强的可靠性研究。本文探讨用户确认的具体研究题目，通过检索参考文献支持写作。"}))
        p = paper(client, headers)
        response = client.post(f"/api/papers/{p['id']}/generate", headers=headers, json={"is_topic_clear": False})
        run_id = response.json()["run_id"]
        status = wait_run(client, headers, p["id"], run_id)
        assert status["requests"][0]["kind"] == "topic"
    with TestClient(create_app(cfg)) as client:
        path = f"/api/papers/{p['id']}/runs/{run_id}"
        assert client.post(path + "/resume", headers=headers, json={}).status_code == 422
        assert client.post(path + "/resume", headers=headers, json={"title": "用户确认的具体研究题目"}).status_code == 202
        status = wait_run(client, headers, p["id"], run_id)
        assert status["requests"][0]["kind"] == "outline"
        changed = client.put(f"/api/papers/{p['id']}/word-limit", headers=headers, json={"word_limit": 3000})
        assert changed.status_code == 200 and changed.json()["run_status"] == "waiting"
        status = client.get(path, headers=headers).json()
        assert sum(section["word_count"] for section in status["requests"][0]["outline"]["sections"]) == 3000
        outline = status["requests"][0]["outline"]
        outline["sections"] = outline["sections"][:2]
        outline["sections"][1]["subsections"] = [{"title": "问题定义", "points": ["任务边界"], "word_count": 300}]
        assert client.put(f"/api/papers/{p['id']}", headers=headers, json={"title": "不应覆盖运行任务的标题"}).status_code == 409
        resumed = client.post(path + "/resume", headers=headers, json={"outline": outline})
        assert resumed.status_code == 202
        # 确认内容在后台撰写开始前就写入业务库，页面重新打开不会显示旧大纲。
        confirmed = client.get(f"/api/papers/{p['id']}", headers=headers).json()
        assert confirmed["outline"] == outline
        assert client.post(path + "/resume", headers=headers, json={"outline": outline}).status_code == 409
        assert wait_run(client, headers, p["id"], run_id)["status"] == "completed"
        result = client.get(f"/api/papers/{p['id']}", headers=headers).json()
        assert result["title"] == "用户确认的具体研究题目"
        assert len(result["chapters"]) == 3
        assert result["chapters"][2]["parent_id"] == result["chapters"][1]["id"]


def test_shared_library_and_private_tasks(client, headers):
    p = paper(client, headers)
    other = account(client, "second_user")
    data = {"title": "检索增强生成的可靠性研究", "abstract": "检索增强生成的可靠性研究，利用共享文献资料支持人工智能写作，提供可追溯的引用。"}
    uploaded = client.post("/api/references/", headers=headers, json=data)
    ref = saved_reference(client, headers, uploaded)
    p2 = paper(client, other)
    detail = client.get(f"/api/papers/{p2['id']}", headers=other).json()
    assert detail["references"][0]["id"] == ref["id"]  # 创建任务时自动关联其他用户上传的共享文献。
    assert client.get("/api/references/search", headers=other, params={"query": data["title"]}).json()[0]["id"] == ref["id"]
    assert client.get("/api/references/search", headers=other, params={"paper_id": p["id"], "query": data["title"]}).status_code == 404
    duplicate = saved_reference(client, other, client.post("/api/references/", headers=other, json=data))
    assert duplicate["duplicate"] and duplicate["id"] == ref["id"]
    assert client.delete(f"/api/references/{ref['id']}", headers=other).status_code == 403
    assert client.delete(f"/api/references/{ref['id']}", headers=headers).status_code == 409
    bad = client.post("/api/references/upload", headers=headers, data={"paper_id": p["id"], "title": "伪装文件"},
                      files={"file": ("fake.pdf", b"not a pdf", "application/pdf")})
    assert bad.status_code == 422
    malformed = client.put(f"/api/papers/{p['id']}", headers=headers, json={"outline": {"title": "无章节", "sections": []}})
    assert malformed.status_code == 422


def test_empty_library_does_not_generate_outline(client, headers):
    p = paper(client, headers)
    result = client.post(f"/api/papers/{p['id']}/outline", headers=headers)
    assert result.status_code == 422
    assert "共享库" in result.json()["detail"]


def test_pdf_metadata_without_manual_fields_and_dedup(client, headers):
    from io import BytesIO
    from pypdf import PdfWriter
    from pypdf.generic import DictionaryObject, NameObject, DecodedStreamObject
    writer = PdfWriter()
    page = writer.add_blank_page(width=612, height=792)
    font = DictionaryObject({NameObject("/Type"): NameObject("/Font"), NameObject("/Subtype"): NameObject("/Type1"),
                             NameObject("/BaseFont"): NameObject("/Helvetica")})
    page[NameObject("/Resources")] = DictionaryObject({NameObject("/Font"): DictionaryObject({NameObject("/F1"): font})})
    content = DecodedStreamObject()
    content.set_data(b"BT /F1 12 Tf 72 720 Td (Shared Retrieval Research) Tj 0 -20 Td (Authors: Alice Smith) Tj "
        b"0 -20 Td (Journal: Example Research) Tj 0 -20 Td (Published: 2025) Tj "
        b"0 -20 Td (Abstract: This study examines shared retrieval for evidence based writing and reliable citations.) Tj ET")
    page[NameObject("/Contents")] = content
    writer.add_metadata({"/Title": "Shared Retrieval Research", "/Author": "Alice Smith"})
    stream = BytesIO()
    writer.write(stream)
    pdf = stream.getvalue()
    result = client.post("/api/references/upload", headers=headers, files={"file": ("research.pdf", pdf, "application/pdf")})
    ref = saved_reference(client, headers, result)
    assert ref["title"] == "Shared Retrieval Research" and ref["authors"] == "Alice Smith"
    assert ref["journal"] == "Example Research" and ref["year"] == 2025
    other = account(client, "library_reader")
    duplicate = saved_reference(client, other, client.post("/api/references/upload", headers=other,
        files={"file": ("renamed.pdf", pdf, "application/pdf")}))
    assert duplicate["duplicate"] and duplicate["id"] == ref["id"]
    assert client.get(f"/api/references/{ref['id']}/file", headers=other).content == pdf


def test_legacy_library_migration_is_repeatable_and_preserves_sources(cfg):
    import sqlite3
    with TestClient(create_app(cfg)) as client:
        headers = account(client)
        p = paper(client, headers)
    with sqlite3.connect(cfg.DATABASE_URL.split("///", 1)[1]) as db:
        db.execute("DELETE FROM library_migrations WHERE name = 'shared_library_v2'")
        db.execute('CREATE TABLE "references" (id INTEGER PRIMARY KEY, owner_id INTEGER, paper_id INTEGER, '
                   'title TEXT, authors TEXT, abstract TEXT, full_text TEXT, file_path TEXT)')
        for reference_id in (1, 2):
            db.execute('INSERT INTO "references" VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                (reference_id, 1, p["id"], "检索增强共享文献", "原作者", "原摘要", "检索增强共享文献原始正文", ""))
    with TestClient(create_app(cfg)) as client:
        migrated = client.get("/api/references/", headers=headers).json()
        assert len(migrated) == 1 and migrated[0]["authors"] == "原作者"
        refs = client.get(f"/api/papers/{p['id']}", headers=headers).json()["references"]
        assert len(refs) == 1 and refs[0]["id"] == migrated[0]["id"]
        new = saved_reference(client, headers, client.post("/api/references/", headers=headers,
            json={"title": "新的共享文献", "abstract": "新文献的不同正文"}))
        assert new["id"] > 2  # 不能复用旧检查点中可能出现的重复文献编号。
        assert client.delete(f"/api/papers/{p['id']}", headers=headers).status_code == 204
    with TestClient(create_app(cfg)) as client:
        assert len(client.get("/api/references/", headers=headers).json()) == 2


def test_upload_returns_receipt_while_pdf_processing_is_blocked(client, headers, monkeypatch):
    import threading
    from app.services import reference_service
    entered, release = threading.Event(), threading.Event()

    def blocked_extract(content):
        entered.set()
        assert release.wait(5), "test must release PDF processing"
        return [{"page": 1, "text": "Shared retrieval evidence for writing."}]

    async def metadata(*args):
        from app.schemas.paper import ReferenceMetadata
        return ReferenceMetadata(title="Shared retrieval evidence").model_dump(), {}, "needs_review"

    monkeypatch.setattr(reference_service, "extract_pdf", blocked_extract)
    monkeypatch.setattr(reference_service, "extract_metadata", metadata)
    pdf = b"%PDF-fake-for-mocked-parser"
    try:
        receipt = client.post("/api/references/upload", headers=headers,
            files={"file": ("slow.pdf", pdf, "application/pdf")})
        assert receipt.status_code == 202, receipt.text
        assert entered.wait(2)
        job = client.get(f"/api/references/jobs/{receipt.json()['id']}", headers=headers).json()
        assert job["status"] == "running" and job["stage"] == "read_pdf"
        # 原先同一把全局锁会阻塞下一次上传；现在重复文件直接复用任务收据。
        duplicate = client.post("/api/references/upload", headers=headers,
            files={"file": ("renamed.pdf", pdf, "application/pdf")})
        assert duplicate.status_code == 202 and duplicate.json()["id"] == job["id"]
        assert client.get("/api/references/stats", headers=headers).status_code == 200
        assert client.get("/api/references/", headers=headers).json() == []
        assert not any(key in job for key in ("file_path", "file_hash", "paper_id"))
    finally:
        release.set()
    ref = saved_reference(client, headers, receipt)
    assert ref["index_status"] == "indexed"
    assert len(client.get("/api/references/", headers=headers).json()) == 1


def test_embedding_progress_and_retry_receipt(client, headers, monkeypatch):
    import threading
    from app.rag.vector_store import IndexBuildError
    entered, release = threading.Event(), threading.Event()
    store = client.app.state.vector_store
    build = store.add_reference

    def blocked_failure(reference, pages, progress=None):
        progress("embedding", 16, 32)
        entered.set()
        assert release.wait(5)
        raise IndexBuildError("embedding", TimeoutError("private-provider-detail"))

    monkeypatch.setattr(store, "add_reference", blocked_failure)
    try:
        receipt = client.post("/api/references/", headers=headers,
            json={"title": "向量进度与重试", "abstract": "用于验证向量进度、失败诊断和重试的资料。"})
        assert receipt.status_code == 202
        assert entered.wait(2)
        job = client.get(f"/api/references/jobs/{receipt.json()['id']}", headers=headers).json()
        assert (job["stage"], job["progress_done"], job["progress_total"]) == ("embedding", 16, 32)
        assert client.get("/api/references/stats", headers=headers).json()["indexed"] == 0
        assert client.delete(f"/api/references/{job['reference_id']}", headers=headers).status_code == 409
    finally:
        release.set()
    failed = wait_reference_job(client, headers, receipt, expected="failed")
    assert failed["error"]["code"] == "index_timeout"
    assert "private-provider-detail" not in str(failed)
    monkeypatch.setattr(store, "add_reference", build)
    retry = client.post(f"/api/references/jobs/{failed['id']}/retry", headers=headers)
    assert retry.status_code == 202 and retry.json()["id"] == failed["id"]
    assert saved_reference(client, headers, retry)["index_status"] == "indexed"


def test_persistent_library_job_is_recovered_on_restart(cfg):
    import sqlite3
    from uuid import uuid4
    with TestClient(create_app(cfg)) as client:
        headers = account(client)
        ref = saved_reference(client, headers, client.post("/api/references/", headers=headers,
            json={"title": "可恢复的持久索引任务", "abstract": "重启后继续构建共享文献索引。"}))
    job_id = str(uuid4())
    with sqlite3.connect(cfg.DATABASE_URL.split("///", 1)[1]) as db:
        db.execute("UPDATE library_references SET index_status = 'pending' WHERE id = ?", (ref["id"],))
        db.execute("INSERT INTO reference_jobs (id, owner_id, reference_id, operation, status, stage, filename, "
            "file_path, file_hash, duplicate, progress_done, progress_total, error, created_at, updated_at) "
            "VALUES (?, ?, ?, 'reindex', 'running', 'embedding', '恢复测试', '', '', 0, 16, 32, '{}', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
            (job_id, ref["owner_id"], ref["id"]))
    with TestClient(create_app(cfg)) as client:
        result = wait_reference_job(client, headers, {"id": job_id})
        assert result["reference_id"] == ref["id"]
        assert client.get(f"/api/references/{ref['id']}", headers=headers).json()["index_status"] == "indexed"


def test_workflow_failure_has_diagnostics_and_private_download(client, headers, monkeypatch, cfg):
    from app.agents.outline_agent import OutlineAgent
    from app.utils.helpers import ProcessingError
    saved_reference(client, headers, client.post("/api/references/", headers=headers,
        json={"title": "检索增强生成可靠性", "abstract": "检索增强生成的可靠性研究与人工智能参考文献。"}))
    manuscript = paper(client, headers)

    class ProviderError(Exception):
        status_code = 401
        body = {"error": {"code": "invalid_api_key", "message": "must-not-leak-provider-body"}}
        request_id = "request-test-401"

    async def fail_outline(self, inputs):
        raise ProcessingError(ProviderError("must-not-leak-exception"), service="chat", agent="outline")

    monkeypatch.setattr(OutlineAgent, "execute", fail_outline)
    response = client.post(f"/api/papers/{manuscript['id']}/generate", headers=headers, json={})
    run_id = response.json()["run_id"]
    path = f"/api/papers/{manuscript['id']}/runs/{run_id}"
    for _ in range(500):
        status = client.get(path, headers=headers).json()
        if status["status"] != "running":
            break
        time.sleep(.02)
    assert status["status"] == "failed", status
    diagnostic = status["diagnostic"]
    assert diagnostic["step"] == "generate_outline"
    assert diagnostic["service"] == "chat" and diagnostic["agent"] == "outline"
    assert diagnostic["http_status"] == 401 and diagnostic["code"] == "model_auth"
    assert diagnostic["provider_code"] == "invalid_api_key"
    assert diagnostic["provider_request_id"] == "request-test-401"
    report = client.get(path + "/diagnostics", headers=headers)
    assert report.status_code == 200
    assert report.json()["diagnostic"]["diagnostic_id"] == diagnostic["diagnostic_id"]
    assert all(e["kind"] != "token" for e in report.json()["events"])
    assert "must-not-leak" not in report.text
    other = account(client, "diagnostics_other_user")
    assert client.get(path + "/diagnostics", headers=other).status_code == 404
    log = (cfg.DATA_DIR / "logs" / "agent.log").read_text(encoding="utf-8")
    assert run_id in log and diagnostic["diagnostic_id"] in log
    assert "ProviderError" in log and "generate_outline" in log
    assert "must-not-leak-provider-body" not in log


def test_model_error_api_does_not_log_user_out(client, headers, monkeypatch):
    from app.agents.outline_agent import OutlineAgent
    from app.utils.helpers import ProcessingError
    saved_reference(client, headers, client.post("/api/references/", headers=headers,
        json={"title": "检索增强生成可靠性", "abstract": "检索增强生成的可靠性研究与人工智能参考文献。"}))
    manuscript = paper(client, headers)

    class ProviderError(Exception):
        status_code = 401

    async def failed(self, inputs):
        raise ProcessingError(ProviderError(), service="chat", agent="outline")

    monkeypatch.setattr(OutlineAgent, "execute", failed)
    response = client.post(f"/api/papers/{manuscript['id']}/outline", headers=headers)
    assert response.status_code == 502
    assert response.json()["diagnostic"]["http_status"] == 401
    assert client.get("/api/auth/me", headers=headers).status_code == 200


def test_diagnostic_keeps_structured_validation_fields_without_model_text(cfg):
    from app.utils.helpers import ProcessingError, StructuredOutputError, failure_diagnostic
    error = StructuredOutputError([{"field": "sections.0.word_count", "type": "int_parsing"}])
    diagnostic = failure_diagnostic(ProcessingError(error, service="chat", agent="outline"), cfg,
                                    step="generate_outline", run_id="diagnostic-test")
    assert diagnostic["code"] == "model_output_invalid"
    assert diagnostic["validation_fields"][0]["field"] == "sections.0.word_count"
