import asyncio
import json
import time
from types import SimpleNamespace

import pytest
from conftest import account
from app.services.agent_runtime import AutonomousAgentLoop, ToolRegistry, ToolSpec
from app.services.agent_service import (merge_preferences, memory_entries, preference_storage,
                                       effective_preferences, migrate_memory_entries)


def create_paper(client, headers, title="测试论文任务创建与删除"):
    response = client.post('/api/papers/', headers=headers, json={'title': title, 'word_limit': 1000})
    assert response.status_code == 201, response.text
    return response.json()


def turn(client, headers, message, paper_id=None, session_id=None):
    path = f'/api/agent/paper/{paper_id}/turns' if paper_id else '/api/agent/global/turns'
    data = {'message': message}
    if session_id:
        data['session_id'] = session_id
    accepted = client.post(path, headers=headers, json=data)
    assert accepted.status_code == 202, accepted.text
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        response = client.get(path + '/' + accepted.json()['turn_id'], headers=headers)
        assert response.status_code == 200, response.text
        state = response.json()
        if state['status'] in ('completed', 'failed', 'interrupted'):
            return state
        time.sleep(.01)
    pytest.fail('turn did not finish')


def test_memory_scopes_delete_and_login(client, headers):
    state = turn(client, headers, '以后采用简洁的写作风格')
    assert state['status'] == 'completed', state
    entries = client.get('/api/agent/memories', headers=headers).json()
    assert len(entries) == 1
    entry = entries[0]
    assert entry['scope'] == 'account' and entry['id'] and entry['created_at']
    p = create_paper(client, headers)
    assert '简洁' in client.get(f"/api/agent/{p['id']}/preferences", headers=headers).json()['writing_style']
    other = account(client, 'memory_other')
    assert client.delete('/api/agent/memories/'+entry['id'], headers=other).status_code == 404
    assert client.delete('/api/agent/memories/'+entry['id'], headers=headers).status_code == 204
    prefs = client.get(f"/api/agent/{p['id']}/preferences", headers=headers).json()
    assert prefs['writing_style'] == '' and prefs['preference_memory'] == []
    assert client.get('/api/agent/global/sessions', headers=headers).json()
    login = client.post('/api/auth/login', json={'username':'researcher', 'password':'testing-pass-123'})
    headers = {'Authorization':'Bearer '+login.json()['access_token']}
    p2 = create_paper(client, headers, '新建论文不恢复已删除的记忆')
    assert client.get(f"/api/agent/{p2['id']}/preferences", headers=headers).json()['writing_style'] == ''
    response = client.put(f"/api/agent/{p['id']}/preferences", headers=headers,
                          json={'writing_style': '详尽', 'preference_memory': ['本篇详细描述实验']})
    assert response.status_code == 200
    assert client.get('/api/auth/preferences', headers=headers).json()['writing_style'] == ''
    paper_entry = client.get('/api/agent/memories', headers=headers).json()[0]
    assert client.delete('/api/agent/memories/'+paper_entry['id'], headers=other,
                         params={'paper_id': p['id']}).status_code == 404
    assert client.delete('/api/agent/memories/'+paper_entry['id'], headers=headers,
                         params={'paper_id': p['id']}).status_code == 204


def test_preference_precedence_and_forgetting_no_fallback():
    account_pref = merge_preferences({}, {'writing_style': '简洁'})
    local = merge_preferences({}, {'writing_style': '详细'})
    assert effective_preferences(account_pref, local)['writing_style'] == '详细'
    updated = merge_preferences(local, {'writing_style': '中等'})
    assert len(memory_entries(updated)) == 1
    assert effective_preferences({}, preference_storage([]))['writing_style'] == ''


@pytest.mark.asyncio
async def test_direct_control_and_semantic_single_step_skip_reflection():
    calls=[]
    async def handler(args): calls.append(args); return {'message':'已暂停', 'run_status':'paused'}
    class Planner:
        async def plan(self, data):
            return {'goal':'操作', 'single_step':True, 'tool_calls':[{'name':'pause_task','arguments':{}}]}
        async def reflect(self, data): raise AssertionError('unnecessary reflection')
    registry = ToolRegistry().register(ToolSpec('pause_task','pause',{'properties':{'paper_id':{}}},handler)).with_defaults(paper_id=1)
    result = await AutonomousAgentLoop(Planner(),registry).run({'message':'暂停任务','focused_paper':{'id':1}})
    assert result['timings']['fast_control'] and calls == [{'paper_id':1}]
    result = await AutonomousAgentLoop(Planner(),registry).run({'message':'请暂时停止这篇论文'})
    assert not result['timings']['fast_control'] and result['observations'][0]['ok']
    assert AutonomousAgentLoop.control_plan({'message':'不要暂停任务','focused_paper':{'id':1}}) is None
    assert AutonomousAgentLoop.control_plan({'message':'暂停任务了吗？','focused_paper':{'id':1}}) is None


@pytest.mark.asyncio
async def test_explicit_target_wins_and_partial_failure_is_preserved():
    seen=[]
    async def ok(args): seen.append(args); return {'message':'已停止'}
    async def fail(args): raise ValueError('删除失败')
    registry=ToolRegistry().with_defaults(paper_id=1)
    registry.register(ToolSpec('stop','stop',{'properties':{'title':{},'paper_id':{}}},ok))
    registry.register(ToolSpec('delete','delete',{'properties':{}},fail))
    registry.register(ToolSpec('later','later',{'properties':{}},ok))
    class Planner:
        async def plan(self,data): return {'goal':'停止删除', 'tool_calls':[
            {'name':'stop','arguments':{'title':'另一篇'}}, {'name':'delete'}, {'name':'later'}]}
        async def reflect(self,data): raise RuntimeError('model unavailable')
    result=await AutonomousAgentLoop(Planner(),registry).run({'message':'停止删除'})
    assert seen == [{'title':'另一篇'}]
    assert [o['ok'] for o in result['observations']] == [True,False]
    assert result['reflection']['requires_user_input']


@pytest.mark.parametrize('run_status', [None, 'waiting', 'paused', 'running', 'completed'])
def test_delete_from_paper_turn_during_every_state(client, headers, run_status):
    p=create_paper(client,headers)
    run_id='delete-test-'+str(p['id'])
    async def setup():
        from app.models.paper import Paper,PaperRun
        async with client.app.state.database.sessions() as db:
            paper=await db.get(Paper,p['id'])
            if run_status:
                paper.active_run_id=run_id
                paper.status='outline'
                db.add(PaperRun(id=run_id,paper_id=p['id'],status=run_status,options={},events=[]))
            await db.commit()
        if run_status=='running':
            async def pending(): await asyncio.Event().wait()
            task=asyncio.create_task(pending())
            client.app.state.workflow.tasks[run_id]=task
    client.portal.call(setup)
    result=turn(client,headers,'暂停并删除本次任务',p['id'])
    assert result['status']=='completed', result
    assert result['operation']=='delete'
    assert '回收站' in result['content']
    assert client.get(f"/api/papers/{p['id']}",headers=headers).status_code==404
    assert any(item['id']==p['id'] for item in client.get('/api/papers/trash',headers=headers).json())
    # Deleted-paper turn receipt remains accessible; refresh must not depend on messages endpoint.
    assert client.get(f"/api/agent/paper/{p['id']}/turns/{result['id']}",headers=headers).status_code==200
    assert client.delete(f"/api/papers/{p['id']}",headers=headers).status_code==204


def test_character_stream_available_before_model_finishes(client, headers, monkeypatch):
    from app.agents.conversation_response_agent import ConversationResponseAgent
    async def streamed(self, data):
        yield '最初一段'
        await asyncio.sleep(.4)
        yield '最后一段'
    monkeypatch.setattr(ConversationResponseAgent,'stream_reply',streamed)
    accepted=client.post('/api/agent/global/turns',headers=headers,json={'message':'你好'}).json()
    path='/api/agent/global/turns/'+accepted['turn_id']
    partial=False
    for _ in range(100):
        state=client.get(path,headers=headers).json()
        if state['content']=='最初一段' and state['status']!='completed': partial=True
        if state['status']=='completed': break
        time.sleep(.015)
    assert partial and state['content']=='最初一段最后一段'
    events=[json.loads(line) for line in client.app.state.settings.METRICS_LOG_PATH.read_text(encoding='utf-8').splitlines()]
    metric=next(e for e in events if e['event']=='agent_latency')
    assert metric['total_ms']>=350 and metric['first_content_ms']<metric['total_ms']
    assert metric['model_calls']==0


def test_pending_prompt_and_assistant_are_separate(client, headers, monkeypatch):
    from app.agents.autonomous_agent import AutonomousAgent
    async def slow(self,data):
        await asyncio.sleep(.3)
        return {'goal':'问答','response_mode':'answer','tool_calls':[]}
    monkeypatch.setattr(AutonomousAgent,'plan',slow)
    p=create_paper(client,headers)
    client.post(f"/api/agent/paper/{p['id']}/turns",headers=headers,json={'message':'请解释这个问题'})
    messages=client.get(f"/api/agent/{p['id']}/messages",headers=headers).json()
    assert messages[0]['role']=='user' and messages[0]['content']=='请解释这个问题'
    assert messages[1]['role']=='assistant'


def test_real_checkpoint_confirm_stream_pause_delete(client, headers, monkeypatch):
    from app.agents.reference_agent import ReferenceAgent
    from app.agents.writer_agent import WriterAgent
    async def refs(self,data):
        return {'formatted':['[1] 测试来源'],'query_plan':{},'references':[{'id':0,'title':'测试来源','authors':'测试','year':2026,
            'citation_number':1,'excerpt':'只用于验证流程的合成来源','formatted':'[1] 测试来源'}]}
    async def slow(self,data):
        yield '已经开始输出，但章节还没写完。'
        await asyncio.sleep(10)
        yield '不应该在暂停后写回。'
    monkeypatch.setattr(ReferenceAgent,'execute',refs)
    monkeypatch.setattr(WriterAgent,'stream_execute',slow)
    p=create_paper(client,headers)
    started=turn(client,headers,'开始写作',p['id'])
    assert started['status']=='completed',started
    run_path=f"/api/papers/{p['id']}/runs/{started['run_id']}"
    for _ in range(200):
        state=client.get(run_path,headers=headers).json()
        if state['status']=='waiting':break
        assert state['status']!='failed',state
        time.sleep(.015)
    assert state['requests'][0]['kind']=='outline',state
    confirmed=turn(client,headers,'确认大纲',p['id'])
    assert confirmed['status']=='completed',confirmed
    for _ in range(200):
        events=client.get(run_path+'/event-snapshot',headers=headers).json()['events']
        if any(e.get('kind')=='token' for e in events):break
        time.sleep(.015)
    assert any(e.get('kind')=='token' for e in events)
    assert not any(e.get('kind')=='progress' and e.get('step')=='write_section' for e in events)
    paused=turn(client,headers,'暂停任务',p['id'])
    assert paused['status']=='completed'
    assert client.get(run_path,headers=headers).json()['status']=='paused'
    deleted=turn(client,headers,'暂停并删除本次任务',p['id'])
    assert deleted['operation']=='delete' and deleted['status']=='completed',deleted
    async def check():
        from app.models.paper import Paper,PaperRun
        async with client.app.state.database.sessions() as db:
            item=await db.get(Paper,p['id'])
            run=await db.get(PaperRun,started['run_id'])
            assert item.deleted_at and item.active_run_id is None and run.status=='cancelled'
    client.portal.call(check)


def test_legacy_memory_migration_does_not_restore_deleted_entry(client, headers):
    p=create_paper(client,headers)
    async def legacy():
        from app.models.user import User
        from app.models.paper import Paper
        async with client.app.state.database.sessions() as db:
            user=await db.get(User,1)
            paper=await db.get(Paper,p['id'])
            old={'writing_style':'旧版简洁偏好','preference_memory':['以后简洁写作']}
            user.preferences=old
            paper.agent_preferences={**old,'annotation_color':'#FF0000'}
            await db.commit()
        await migrate_memory_entries(client.app.state.database.sessions)
    client.portal.call(legacy)
    entries=client.get('/api/agent/memories',headers=headers).json()
    assert len([e for e in entries if e['scope']=='paper'])==1
    for e in entries:
        if e['scope']=='account':
            assert client.delete('/api/agent/memories/'+e['id'],headers=headers).status_code==204
    client.portal.call(migrate_memory_entries,client.app.state.database.sessions)
    prefs=client.get(f"/api/agent/{p['id']}/preferences",headers=headers).json()
    assert prefs['writing_style']=='' and prefs['preference_memory']==[]
    assert prefs['annotation_color']=='#FF0000'


@pytest.mark.asyncio
async def test_usage_telemetry_counts_reported_tokens_and_marks_missing_usage():
    from app.services.agent_telemetry import begin_turn, call_config
    data=begin_turn()
    callback=call_config()['callbacks'][0]
    callback.on_chat_model_start({},[],run_id='one')
    message=SimpleNamespace(usage_metadata={'input_tokens':123,'output_tokens':17})
    callback.on_llm_end(SimpleNamespace(generations=[[SimpleNamespace(message=message)]],llm_output={}),run_id='one')
    assert data['calls']==1 and data['input_tokens']==123 and data['output_tokens']==17
    callback.on_chat_model_start({},[],run_id='two')
    callback.on_llm_end(SimpleNamespace(generations=[],llm_output={}),run_id='two')
    assert data['calls']==2 and not data['usage_known']
    async def background():return call_config()
    assert await asyncio.create_task(background())=={}
